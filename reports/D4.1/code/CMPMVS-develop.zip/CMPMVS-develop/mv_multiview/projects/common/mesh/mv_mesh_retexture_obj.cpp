#include "mv_mesh_retexture_obj.h"

#include "delaunaycut/mv_delaunay_GC.h"
#include "stdafx.h"

mv_mesh_retexture_obj::mv_mesh_retexture_obj(multiviewParams* _mp, mv_prematch_cams* _pc, const std::string& origMeshObjAsciiFileName, const std::string& objAsciiFileName)
{
    mp = _mp;
    pc = _pc;
    o3d = new mv_output3D(mp);

    meObj.textureSide = mp->mip->_ini.get<int>("retextureFromObjAscii.objTextureSide", 1024);
    meOrig.textureSide = mp->mip->_ini.get<int>("retextureFromObjAscii.origTextureSide", 1024);

    meOrig.me = new mv_mesh();
    meOrig.me->loadFromObjAscii(meOrig.nmtls, &(meOrig.trisMtlIds), &(meOrig.normals), &(meOrig.trisNormalsIds),
                                &(meOrig.uvCoords), &(meOrig.trisUvIds), origMeshObjAsciiFileName);

    if(meOrig.normals->empty())
    {
        delete meOrig.normals;
        meOrig.normals = meOrig.me->computeNormalsForPts();
        delete meOrig.trisNormalsIds;
        meOrig.trisNormalsIds = new staticVector<voxel>(meOrig.me->tris->size());
        for(int i = 0; i < meOrig.me->tris->size(); i++)
        {
            meOrig.trisNormalsIds->push_back(
                voxel((*meOrig.me->tris)[i].i[0], (*meOrig.me->tris)[i].i[1], (*meOrig.me->tris)[i].i[2]));
        }
    }

    meObj.me = nullptr;
    if(!objAsciiFileName.empty())
    {
        meObj.me = new mv_mesh();
        meObj.me->loadFromObjAscii(meObj.nmtls, &(meObj.trisMtlIds), &(meObj.normals), &(meObj.trisNormalsIds),
                                   &(meObj.uvCoords), &(meObj.trisUvIds), objAsciiFileName);
    }

    // o3d->saveMvMeshToWrl(meObj.me,objAsciiFileName+".wrl");
}

mv_mesh_retexture_obj::~mv_mesh_retexture_obj()
{
    delete o3d;
}

staticVector<int>* mv_mesh_retexture_obj::getMeObjTriangleNearestMeOrigTriangles(
    point3d* objTriPts, staticVector<voxel>* meOrigTrisNeighTris, int meObjTtriId, int meOrigNearestTtriId)
{
    // if (mp->verbose) printf("getMeObjTriangleNearestMeOrigTriangles\n");

    if(meOrigNearestTtriId == -1)
    {
        return nullptr;
    }

    point3d ocg = meObj.me->computeTriangleCenterOfGravity(meObjTtriId);
    point3d origTriN = meObj.me->computeTriangleNormal(meObjTtriId);
    double ocgMaxPtDist = 0.0;
    for(int k = 0; k < 3; k++)
    {
        ocgMaxPtDist = std::max(ocgMaxPtDist, (ocg - (*meObj.me->pts)[(*meObj.me->tris)[meObjTtriId].i[k]]).size());
    }

    staticVector<int>* toProces = new staticVector<int>(meOrig.me->tris->size());
    mv_bites_array* processed = new mv_bites_array(meOrig.me->tris->size());

    staticVector<int>* out = new staticVector<int>(meOrig.me->tris->size());

    toProces->push_back(meOrigNearestTtriId);
    processed->setbit(meOrigNearestTtriId, true);
    out->push_back(meOrigNearestTtriId);

    while(toProces->size() > 0)
    {
        int idTri = toProces->pop();
        for(int k = 0; k < 3; k++)
        {
            int nIdTri = (*meOrigTrisNeighTris)[idTri].m[k];
            if((nIdTri > -1) && (!processed->getbit(nIdTri)))
            {
                bool doAdd = false;
                for(int k1 = 0; k1 < 3; k1++)
                {
                    // point3d origTriPt = meOrig.me->computeTriangleCenterOfGravity(nIdTri);
                    point3d origTriPt = (*meOrig.me->pts)[(*meOrig.me->tris)[nIdTri].i[k1]];
                    point3d lpi;
                    point2d objBaryc = getLineTriangleIntersectBarycCoords(&lpi, &objTriPts[0], &objTriPts[1],
                                                                           &objTriPts[2], &origTriPt, &origTriN);
                    float dist = (origTriPt - lpi).size();

                    float kthr = 0.2;
                    objBaryc = (objBaryc + point2d(kthr, kthr)) / (1.0f + kthr * 3.0f);

                    if(((ocg - origTriPt).size() < ocgMaxPtDist) &&
                       //(dist<origCgDistNearestCg*2.0f)&&
                       (dist < ocgMaxPtDist) && (isPointInTriangle(objBaryc)))
                    {
                        doAdd = true;
                    }
                }

                if(doAdd)
                {
                    toProces->push_back(nIdTri);
                    processed->setbit(nIdTri, true);
                    out->push_back(nIdTri);
                }
            }
        }
    }

    // if (mp->verbose) printf("found %i  done...\n",out->size());

    delete toProces;
    delete processed;
    return out;
}

staticVector<point2d>* mv_mesh_retexture_obj::getObjTexturePixelsForObjTriangleIdInTriBarycCoord(point2d* pixs)
{
    // if (mp->verbose) printf("getObjTexturePixelsForObjTriangleIdInTriBarycCoord\n");

    pixel LU, RD;
    LU.x = (int)(std::min(std::min(pixs[0].x, pixs[1].x), pixs[2].x));
    LU.y = (int)(std::min(std::min(pixs[0].y, pixs[1].y), pixs[2].y));
    RD.x = (int)(std::max(std::max(pixs[0].x, pixs[1].x), pixs[2].x)) + 1;
    RD.y = (int)(std::max(std::max(pixs[0].y, pixs[1].y), pixs[2].y)) + 1;

    staticVector<point2d>* out = new staticVector<point2d>((RD.x - LU.x + 1) * (RD.y - LU.y + 1));
    for(int y = LU.y; y <= RD.y; y++)
    {
        for(int x = LU.x; x <= RD.x; x++)
        {
            point2d pix = point2d(x + 0.5f, y + 0.5f);
            point2d pixBarycUv = computeBarycentricCoordinates(pixs[0], pixs[1], pixs[2], pix);
            if(isPointInTriangle(pixBarycUv))
            {
                out->push_back(pixBarycUv);
                // if (mp->verbose) printf("%i %i -> %f %f\n",x,y,pixBarycUv.x,pixBarycUv.y);
            }
        }
    }
    // if (mp->verbose) printf("done...\n");
    return out;
}

staticVector<orientedPoint>* mv_mesh_retexture_obj::getObjOrientedPointsForObjTriTexturePixels(
    point3d* triPts, point3d* normPts, staticVector<point2d>* objTriTexturePixels)
{
    // if (mp->verbose) printf("getObjOrientedPointsForObjTriTexturePixels\n");
    // printf("n0 %f %f %f\n", normPts[0].x, normPts[0].y, normPts[0].z);
    // printf("n1 %f %f %f\n", normPts[1].x, normPts[1].y, normPts[1].z);
    // printf("n2 %f %f %f\n", normPts[2].x, normPts[2].y, normPts[2].z);

    staticVector<orientedPoint>* out = new staticVector<orientedPoint>(objTriTexturePixels->size());
    for(int i = 0; i < objTriTexturePixels->size(); i++)
    {
        point2d pixBarycUv = (*objTriTexturePixels)[i];
        point3d P = triPts[0] + (triPts[2] - triPts[0]) * pixBarycUv.x + (triPts[1] - triPts[0]) * pixBarycUv.y;
        point3d n = normPts[0] + (normPts[2] - normPts[0]) * pixBarycUv.x + (normPts[1] - normPts[0]) * pixBarycUv.y;
        orientedPoint op;
        op.n = n.normalize();
        op.p = P;
        out->push_back(op);
        // if (mp->verbose) printf("%f %f %f, %f %f %f\n",P.x,P.y,P.z,n.x,n.y,n.z);
    }

    // if (mp->verbose) printf("done...\n");
    return out;
}

staticVector<mv_mesh_retexture_obj::retexPixels>* mv_mesh_retexture_obj::getRetexturePixels()
{
    if(mp->verbose)
        std::cout << "getRetexturePixels" << std::endl;
    staticVector<retexPixels>* out = new staticVector<retexPixels>(meObj.textureSide * meObj.textureSide);

    if(mp->verbose)
        std::cout << "getNearestMe2TriIdsForMe1Tris" << std::endl;
    mv_delaunay_GC* dgc = new mv_delaunay_GC(mp, pc);
    dgc->initTetrahedralizationFromMeshTrianglesCenter(meOrig.me, true);
    staticVector<int>* nearestOrigTriIdsForObjTris = dgc->getNearestTrisFromMeshTris(meObj.me);
    delete dgc;
    if(mp->verbose)
        std::cout << " done..." << std::endl;

    if(mp->verbose)
        std::cout << " getTrisNeighsTris" << std::endl;
    staticVector<voxel>* meOrigTrisNeighTris = meOrig.me->getTrisNeighsTris();
    if(mp->verbose)
        std::cout << " done..." << std::endl;

// long t1 = initEstimate();
#pragma omp parallel for
    for(int meObjTriId = 0; meObjTriId < meObj.me->tris->size(); meObjTriId++)
    {
        point2d objTriPixs[3];
        point3d objTriPts[3];
        point3d objNormPts[3];
        for(int k = 0; k < 3; k++)
        {
            objTriPixs[k] = (*meObj.uvCoords)[(*meObj.trisUvIds)[meObjTriId].m[k]] * meObj.textureSide;
            objTriPts[k] = (*meObj.me->pts)[(*meObj.me->tris)[meObjTriId].i[k]];
            objNormPts[k] = (*meObj.normals)[(*meObj.trisNormalsIds)[meObjTriId].m[k]];
        }

        staticVector<int>* meOrigNeighTris = getMeObjTriangleNearestMeOrigTriangles(
            objTriPts, meOrigTrisNeighTris, meObjTriId, (*nearestOrigTriIdsForObjTris)[meObjTriId]);
        if(meOrigNeighTris != nullptr)
        {
            // get texture pixels for meObj.meTriId triangle
            staticVector<point2d>* objTriTexturePixels = getObjTexturePixelsForObjTriangleIdInTriBarycCoord(objTriPixs);
            // compute oriented points for texture pixels
            staticVector<orientedPoint>* objTriOrientedPoints = getObjOrientedPointsForObjTriTexturePixels(
                objTriPts, objNormPts, objTriTexturePixels);

            /*
            {
                    mv_mesh *meTmp = new mv_mesh();
                    meTmp->tris = new staticVector<mv_mesh::triangle>(meOrigNeighTris->size()+1);
                    meTmp->pts  = new staticVector<point3d>((meOrigNeighTris->size()+1)*3);

                    mv_mesh::triangle tTmp; tTmp.alive=true;

                    for (int k=0;k<3;k++)
            {meTmp->pts->push_back((*meObj.me->pts)[(*meObj.me->tris)[meObjTriId].i[k]]);tTmp.i[k]=meTmp->pts->size()-1;};
                    meTmp->tris->push_back(tTmp);
                    for (int j=0;j<meOrigNeighTris->size();j++)
                    {
                            int origTriId = (*meOrigNeighTris)[j];
                            for (int k=0;k<3;k++)
            {meTmp->pts->push_back((*meOrig.me->pts)[(*meOrig.me->tris)[origTriId].i[k]]);tTmp.i[k]=meTmp->pts->size()-1;};
                            meTmp->tris->push_back(tTmp);
                    };

                    o3d->saveMvMeshToWrl(meTmp,objAsciiTextureFileName+num2strFourDecimal(meObjTriId)+".wrl");

                    delete meTmp;
            };
            */

            // for each oriented point
            for(int i = 0; i < objTriOrientedPoints->size(); i++)
            {
                point2d objBaryc = (*objTriTexturePixels)[i];
                float nearestPtDist = std::numeric_limits<float>::max();
                retexPixels rp;
                point3d bestlpi;
                bool ok = false;

                // compute meOrig.meTriangleId and corresponding uv of the intersection
                for(int j = 0; j < meOrigNeighTris->size(); j++)
                {
                    int origTriId = (*meOrigNeighTris)[j];
                    point2d origTriPixs[3];
                    point3d origTriPts[3];
                    point3d origNormPts[3];
                    for(int k = 0; k < 3; k++)
                    {
                        origTriPixs[k] = (*meOrig.uvCoords)[(*meOrig.trisUvIds)[origTriId].m[k]] * meOrig.textureSide;
                        origTriPts[k] = (*meOrig.me->pts)[(*meOrig.me->tris)[origTriId].i[k]];
                        origNormPts[k] = (*meOrig.normals)[(*meOrig.trisNormalsIds)[origTriId].m[k]];
                    }
                    point3d lpi;
                    point2d origBaryc = getLineTriangleIntersectBarycCoords(
                        &lpi, &origTriPts[0], &origTriPts[1], &origTriPts[2], &(*objTriOrientedPoints)[i].p,
                        &(*objTriOrientedPoints)[i].n);
                    if(isPointInTriangle(origBaryc))
                    {
                        float dist = (lpi - (*objTriOrientedPoints)[i].p).size();
                        if(dist < nearestPtDist)
                        {
                            nearestPtDist = dist;
                            rp.objTextPixel = objTriPixs[0] + (objTriPixs[2] - objTriPixs[0]) * objBaryc.x +
                                              (objTriPixs[1] - objTriPixs[0]) * objBaryc.y;
                            rp.objTextPixel.y = (float)meObj.textureSide - rp.objTextPixel.y;

                            rp.origTextPixel = origTriPixs[0] + (origTriPixs[2] - origTriPixs[0]) * origBaryc.x +
                                               (origTriPixs[1] - origTriPixs[0]) * origBaryc.y;
                            rp.origTextPixel.y = (float)meOrig.textureSide - rp.origTextPixel.y;

                            rp.origTextAtlasId = (*meOrig.trisMtlIds)[origTriId];

                            rp.normal = origNormPts[0] + (origNormPts[2] - origNormPts[0]) * origBaryc.x +
                                        (origNormPts[1] - origNormPts[0]) * origBaryc.y;
                            rp.normal = rp.normal.normalize();

                            ok = true;
                            bestlpi = lpi;
                        }
                    }
                }

                if(ok)
                {
// printf("%i, %f %f -> %f
// %f\n",rp.origTextAtlasId,rp.origTextPixel.x,rp.origTextPixel.y,rp.objTextPixel.x,rp.objTextPixel.y);
#pragma omp critical
                    {
                        out->push_back(rp);
                        // lpis->push_back(bestlpi);
                    }
                }
            }

            delete objTriOrientedPoints;
            delete objTriTexturePixels;
            delete meOrigNeighTris;
        }

        // printfEstimate(meObjTriId,meObj.me->tris->size(),t1);
    }
    // finishEstimate();

    delete meOrigTrisNeighTris;
    delete nearestOrigTriIdsForObjTris;

    // o3d->create_wrl_pts(lpis, mp, objAsciiTextureFileName + ".wrl");
    // delete lpis;

    if(mp->verbose)
        std::cout << "getRetexturePixels done" << std::endl;
    return out;
}

void mv_mesh_retexture_obj::retexture(const std::string& origTextureFilepathPrefix,
                                      const std::string& objTextureFilepath,
                                      const std::string& objNormalMapFilepath)
{
    if(mp->verbose)
        printf("mv_mesh_retexture_obj::retexture");
    staticVector<retexPixels>* retexturePixels = getRetexturePixels();

    int bandType = 0;
    mv_images_cache ic(mp, bandType, true);
    cuda_plane_sweeping cps(mp->CUDADeviceNo, &ic, mp, pc, 1);

    std::cout << "Build new textures" << std::endl;
    {
        IplImage* bmpObj = cvCreateImage(cvSize(meObj.textureSide, meObj.textureSide), IPL_DEPTH_8U, 3);

        for(int atlasId = 0; atlasId < meOrig.nmtls; atlasId++)
        {
            staticVector<retexPixels>* retextureAtlasPixels = new staticVector<retexPixels>(retexturePixels->size());
            for(int i = 0; i < retexturePixels->size(); i++)
            {
                if((*retexturePixels)[i].origTextAtlasId == atlasId)
                {
                    retextureAtlasPixels->push_back((*retexturePixels)[i]);
                }
            }
            std::string origAsciiTextureFileName = origTextureFilepathPrefix + num2str(atlasId) + ".png";
            IplImage* bmpOrig = cvLoadImage(origAsciiTextureFileName.c_str());
            cps.retexture(retextureAtlasPixels, bmpObj, bmpOrig);
            delete retextureAtlasPixels;
            cvReleaseImage(&bmpOrig);
        }
        cps.colorExtractionPushPull(bmpObj);

        if(cvSaveImage(objTextureFilepath.c_str(), bmpObj) == 0)
            printf("Could not save: %s\n", objTextureFilepath.c_str());
        cvReleaseImage(&bmpObj);
    }

    std::cout << "Build normal map" << std::endl;
    {
        IplImage* bmpObjNormalMap = cvCreateImage(cvSize(meObj.textureSide, meObj.textureSide), IPL_DEPTH_8U, 3);
        cps.retextureComputeNormalMap(retexturePixels, bmpObjNormalMap);
        cps.colorExtractionPushPull(bmpObjNormalMap);

        if(cvSaveImage(objNormalMapFilepath.c_str(), bmpObjNormalMap) == 0)
            printf("Could not save: %s\n", objNormalMapFilepath.c_str());
        cvReleaseImage(&bmpObjNormalMap);
    }

    delete retexturePixels;

    if(mp->verbose)
        printf("mv_mesh_retexture_obj::retexture done");
}

void mv_mesh_retexture_obj::retexturePushPull()
{
    int bandType = 0;
    mv_images_cache* ic = new mv_images_cache(mp, bandType, true);
    cuda_plane_sweeping* cps = new cuda_plane_sweeping(mp->CUDADeviceNo, ic, mp, pc, 1);

    std::string objAsciiTextureFileName =
        mp->mip->_ini.get<std::string>("retextureFromObjAscii.objAsciiTextureFileName", "");
    IplImage* bmpObj = cvLoadImage(objAsciiTextureFileName.c_str());
    cps->colorExtractionPushPull(bmpObj);
    delete ic;
    delete cps;

    objAsciiTextureFileName = objAsciiTextureFileName + "PushPull.png";
    if(cvSaveImage(objAsciiTextureFileName.c_str(), bmpObj) == 0)
        printf("Could not save: %s\n", objAsciiTextureFileName.c_str());
    cvReleaseImage(&bmpObj);
}

void mv_mesh_retexture_obj::groupTexturesToOneFileToObj()
{

    int newTextureSide = mp->mip->_ini.get<int>("retextureFromObjAscii.groupedTextureSide", meOrig.textureSide);

    int natlases = meOrig.nmtls;
    int textureSide = meOrig.textureSide;
    int gridSideSize = 1;
    while(gridSideSize * gridSideSize < natlases)
    {
        gridSideSize++;
    }

    float scale = (float)(gridSideSize * textureSide) / (float)newTextureSide;
    int partScaledSide = (int)((float)textureSide / scale);
    newTextureSide = gridSideSize * partScaledSide;

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // join texture files
    IplImage* bmpo =
        cvCreateImage(cvSize(gridSideSize * partScaledSide, gridSideSize * partScaledSide), IPL_DEPTH_8U, 3);
    const auto origAsciiTextureFileNamePrefix =
        mp->mip->_ini.get<std::string>("retextureFromObjAscii.origAsciiTextureFileNamePrefix", "");
    for(int gy = 0; gy < gridSideSize; gy++)
    {
        for(int gx = 0; gx < gridSideSize; gx++)
        {
            int atlasId = gy * gridSideSize + gx;
            if(atlasId < natlases)
            {
                std::string textureFileName = origAsciiTextureFileNamePrefix + num2str(atlasId) + ".png";
                IplImage* bmp = cvLoadImage(textureFileName.c_str());

                IplImage* bmpr = cvCreateImage(cvSize(partScaledSide, partScaledSide), IPL_DEPTH_8U, 3);
                cvResize(bmp, bmpr);

                for(int y = 0; y < partScaledSide; y++)
                {
                    for(int x = 0; x < partScaledSide; x++)
                    {
                        CvScalar c;
                        c = cvGet2D(bmpr, y, x);
                        int xn = gx * partScaledSide + x;
                        int yn = gy * partScaledSide + y;
                        cvSet2D(bmpo, yn, xn, c);
                    }
                }
                cvReleaseImage(&bmp);
                cvReleaseImage(&bmpr);
            }
        }
    }

    const auto origMeshGroupedObjAsciiTextureDirName =
        mp->mip->_ini.get<std::string>("retextureFromObjAscii.origMeshGroupedObjAsciiTextureDirName", "");
    const auto origMeshGroupedObjAsciiTextureName =
        mp->mip->_ini.get<std::string>("retextureFromObjAscii.origMeshGroupedObjAsciiTextureName", "");
    const auto origMeshGroupedObjAsciiTextureFileName =
        origMeshGroupedObjAsciiTextureDirName + origMeshGroupedObjAsciiTextureName;
    if(cvSaveImage(origMeshGroupedObjAsciiTextureFileName.c_str(), bmpo) == 0)
        printf("Could not save: %s\n", origMeshGroupedObjAsciiTextureFileName.c_str());

    cvReleaseImage(&bmpo);

    if(mp->verbose)
        printf("computing atlas id for uv coords");
    staticVector<int>* uvCoordsMtlIds = new staticVector<int>(meOrig.uvCoords->size());
    uvCoordsMtlIds->resize_with(meOrig.uvCoords->size(), -1);
    for(int i = 0; i < meOrig.trisUvIds->size(); i++)
    {
        int mtlId = (*meOrig.trisMtlIds)[i];
        for(int k = 0; k < 3; k++)
        {
            int uvId = (*meOrig.trisUvIds)[i].m[k];
            if((uvId >= 0) && (uvId < meOrig.uvCoords->size()))
            {
                (*uvCoordsMtlIds)[uvId] = mtlId;
            }
            else
            {
                printf("WARNING Wrong uv id %i (%i,%i)\n", uvId, 0, meOrig.uvCoords->size());
            }
        }
    }
    if(mp->verbose)
        printf(" ... done\n");

    // change uv coordinates
    if(mp->verbose)
        printf("changing uv coords");
    for(int i = 0; i < meOrig.uvCoords->size(); i++)
    {
        int atlasId = (*uvCoordsMtlIds)[i];
        if(atlasId > -1)
        {
            int gx = atlasId % gridSideSize;
            int gy = atlasId / gridSideSize;

            point2d pix = (*meOrig.uvCoords)[i];
            pix.x = pix.x * (float)meOrig.textureSide;
            pix.y = (float)meOrig.textureSide - pix.y * (float)meOrig.textureSide;

            pix.x = (float)(gx * partScaledSide) + pix.x / scale;
            pix.y = (float)(gy * partScaledSide) + pix.y / scale;

            pix.x = pix.x / (float)newTextureSide;
            pix.y = 1.0f - pix.y / (float)newTextureSide;

            (*meOrig.uvCoords)[i] = pix;
        }
        else
        {
            printf("WARNING unreferenced uv!\n");
        }
    }
    if(mp->verbose)
        printf(" ... done\n");

    ///////////////////////////////////////////////////////////////////////////////////////
    // create obj

    if(mp->verbose)
        printf("creating obj and mtl\n");

    const auto origMeshGroupedObjAsciiFileName =
        mp->mip->_ini.get<std::string>("retextureFromObjAscii.origMeshGroupedObjAsciiFileName", "");
    std::string mtlName = origMeshGroupedObjAsciiTextureFileName + ".mtl";
    FILE* fobj = fopen(origMeshGroupedObjAsciiFileName.c_str(), "w");
    FILE* fmtl = fopen(mtlName.c_str(), "w");

    fprintf(fmtl, "# \n");
    fprintf(fmtl, "# Wavefront material file\n");
    fprintf(fmtl, "# Created with AliceVision\n");
    fprintf(fmtl, "# \n\n");

    fprintf(fobj, "# \n");
    fprintf(fobj, "# Wavefront OBJ file\n");
    fprintf(fobj, "# Created with AliceVision\n");
    fprintf(fobj, "# \n");
    fprintf(fobj, "mtllib %s\n\n", mtlName.c_str());
    fprintf(fobj, "g TexturedMesh\n");

    for(int i = 0; i < meOrig.me->pts->size(); i++)
    {
        fprintf(fobj, "v %f %f %f\n", (*meOrig.me->pts)[i].x, (*meOrig.me->pts)[i].y, (*meOrig.me->pts)[i].z);
    }

    {
        fprintf(fmtl, "\n");
        fprintf(fmtl, "newmtl TextureAtlas_%i\n", 0);
        fprintf(fmtl, "Ka  0.6 0.6 0.6\n");
        fprintf(fmtl, "Kd  0.6 0.6 0.6\n");
        fprintf(fmtl, "Ks  0.9 0.9 0.9\n");
        fprintf(fmtl, "d  1.0\n");
        fprintf(fmtl, "Ns  0.0\n");
        fprintf(fmtl, "illum 2\n");
        fprintf(fmtl, "map_Kd %s\n", origMeshGroupedObjAsciiTextureName.c_str());

        fprintf(fobj, "usemtl TextureAtlas_%i\n", 0);

        for(int i = 0; i < meOrig.uvCoords->size(); i++)
        {
            fprintf(fobj, "vt %f %f\n", (*meOrig.uvCoords)[i].x, (*meOrig.uvCoords)[i].y);
        }

        for(int i = 0; i < meOrig.me->tris->size(); i++)
        {
            int idtri = i;
            // indexed from 1 !!!!
            fprintf(fobj, "f %i/%i %i/%i %i/%i\n", (*meOrig.me->tris)[idtri].i[0] + 1, (*meOrig.trisUvIds)[idtri].x + 1,
                    (*meOrig.me->tris)[idtri].i[1] + 1, (*meOrig.trisUvIds)[idtri].y + 1,
                    (*meOrig.me->tris)[idtri].i[2] + 1, (*meOrig.trisUvIds)[idtri].z + 1);
        }
    }

    fclose(fobj);
    fclose(fmtl);

    if(mp->verbose)
        printf(" ... done\n");

    delete uvCoordsMtlIds;
}

