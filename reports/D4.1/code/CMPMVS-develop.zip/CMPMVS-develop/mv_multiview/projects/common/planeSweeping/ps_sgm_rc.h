#pragma once

#include "ps_sgm_params.h"

class ps_sgm_rc
{
public:
    ps_sgm_rc(bool doComputeDepthsAndResetTCams, int _rc, int _scale, int _step, ps_sgm_params* _sp);
    ~ps_sgm_rc(void);

    bool sgmrc(bool checkIfExists = true);
    staticVector<int>* tcams;

protected:

    float getMinTcStepAtDepth(float depth, float minDepth, float maxDepth,
                              staticVector<staticVector<float>*>* alldepths);
    float getMeanTcStepAtDepth(float depth, float minDepth, float maxDepth,
                               staticVector<staticVector<float>*>* alldepths);
    staticVector<float>* getTcSeedsRcPlaneDists(int rc, staticVector<int>* tcams);
    bool selectBestDepthsRange(int nDepthsThr, staticVector<float>* rcSeedsDistsAsc);
    bool selectBestDepthsRange(int nDepthsThr, staticVector<staticVector<float>*>* alldepths);
    staticVector<staticVector<float>*>* computeAllDepthsAndResetTCams();
    void computeDepthsTcamsLimits(staticVector<staticVector<float>*>* alldepths);
    void computeDepths(float minDepth, float maxDepth, staticVector<staticVector<float>*>* alldepths);
    void computeDepthsAndResetTCams();

    staticVector<float>* getSubDepthsForTCam(int tcamid);

    ps_sgm_params* sp;

    int rc, scale, step;
    int wsh;
    float gammaC, gammaP;
    staticVector<float>* depths;
    staticVector<pixel>* depthsTcamsLimits;
    int w, h;

    std::string outDir;
    std::string tmpDir;
    std::string tcamsFileName;
    std::string depthsFileName;
    std::string depthsTcamsLimitsFileName;
    std::string SGM_depthMapFileName;
    std::string SGM_simMapFileName;
    std::string SGM_idDepthMapFileName;
};

void computeDepthMapsPSSGM(multiviewParams* mp, mv_prematch_cams* pc, const staticVector<int>& cams);
void computeDepthMapsPSSGM(int CUDADeviceNo, multiviewParams* mp, mv_prematch_cams* pc, const staticVector<int>& cams);
