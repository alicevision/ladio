#include "mv_matrix2x2.h"
#include "stdafx.h"

void matrix2x2::doprintf()
{
    printf("%f %f\n", m11, m12);
    printf("%f %f\n", m21, m22);
}
