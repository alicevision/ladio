#pragma once

#include "mv_mesh.h"
#include "output3D/mv_output3D.h"
#include "prematching/mv_prematch_cams.h"

struct meshRetex
{
    int nmtls = 0;
    int textureSide = 0;

    staticVector<int>* trisMtlIds = nullptr;
    staticVector<point2d>* uvCoords = nullptr;
    staticVector<voxel>* trisUvIds = nullptr;
    staticVector<point3d>* normals = nullptr;
    staticVector<voxel>* trisNormalsIds = nullptr;
    mv_mesh* me = nullptr;

    ~meshRetex()
    {
        delete trisMtlIds;
        delete uvCoords;
        delete trisUvIds;
        delete normals;
        delete trisNormalsIds;
        delete me;
    }
};

class mv_mesh_retexture_obj
{
public:
    struct retexPixels
    {
        point2d origTextPixel;
        int origTextAtlasId;
        point2d objTextPixel;
        point3d normal;
    };

    mv_output3D* o3d;
    multiviewParams* mp;
    mv_prematch_cams* pc;

    meshRetex meOrig;
    meshRetex meObj;

    mv_mesh_retexture_obj(multiviewParams* _mp, mv_prematch_cams* _pc, const std::string &origMeshObjAsciiFileName, const std::string& objAsciiFileName);
    ~mv_mesh_retexture_obj();

    void retexture(const std::string& origTextureFilepathPrefix,
                   const std::string& objTextureFilepath,
                   const std::string& objNormalMapFilepath);
    void retexturePushPull();
    void groupTexturesToOneFileToObj();

private:
    staticVector<point2d>* getObjTexturePixelsForObjTriangleIdInTriBarycCoord(point2d* pixs);
    staticVector<orientedPoint>* getObjOrientedPointsForObjTriTexturePixels(point3d* triPts, point3d* normPts,
                                                                            staticVector<point2d>* objTriTexturePixels);

    staticVector<int>* getMeObjTriangleNearestMeOrigTriangles(point3d* objTriPts,
                                                              staticVector<voxel>* meOrigTrisNeighTris, int meObjTtriId,
                                                              int meOrigNearestTtriId);
    staticVector<pixel>* getObjTexturePixelsForObjTriangleId(int meObjTriId);

    staticVector<retexPixels>* getRetexturePixels();
};

