#pragma once

#include "mesh/mv_mesh.h"
#include "rply.h"
#include "stdafx.h"

bool mv_loadply(std::string plyFileName, mv_mesh* me);