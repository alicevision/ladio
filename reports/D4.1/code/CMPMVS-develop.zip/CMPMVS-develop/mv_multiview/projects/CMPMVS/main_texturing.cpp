#include "delaunaycut/mv_delaunay_GC.h"
#include "delaunaycut/mv_delaunay_meshSmooth.h"
#include "largeScale/reconstructionPlan.h"

#include "planeSweeping/ps_refine_rc.h"
#include "CUDAInterfaces/refine.h"
#include "structures/mv_filesio.h"

#include <boost/program_options.hpp>
#include <boost/filesystem.hpp>


namespace bfs = boost::filesystem;
namespace po = boost::program_options;

bool checkHardwareCompatibility()
{
    if(listCUDADevices(false) < 1)
    {
        std::cerr << "ERROR: no CUDA capable devices were detected." << std::endl;
        return false;
    }
    return true;
}

bfs::path absolutePathNoExt(const bfs::path& p)
{
    return p.parent_path() / p.stem();
}

#define ALICEVISION_COUT(x) std::cout << x << std::endl
#define ALICEVISION_CERR(x) std::cerr << x << std::endl

int main(int argc, char* argv[])
{
    long startTime = clock();

    std::string iniFilepath;
    std::string inputMeshFilepath;
    std::string outputFolder;
    bool flipNormals = false;

    po::options_description inputParams;

    inputParams.add_options()
        ("ini", po::value<std::string>(&iniFilepath)->required(),
            "Configuration file (mvs.ini).")
        ("output", po::value<std::string>(&outputFolder)->required(),
            "Folder for output mesh: OBJ, material and texture files.")
        ("inputMesh", po::value<std::string>(&inputMeshFilepath),
            "Optional input mesh to texture. By default, it will texture the result of the reconstruction.")
        ("flipNormals", po::bool_switch(&flipNormals),
            "Option to flip face normals. It can be needed as it depends on the vertices order in triangles and the convention change from one software to another.");
    po::variables_map vm;

    try
    {
      po::store(po::parse_command_line(argc, argv, inputParams), vm);

      if(vm.count("help") || (argc == 1))
      {
        ALICEVISION_COUT(inputParams);
        return EXIT_SUCCESS;
      }

      po::notify(vm);
    }
    catch(boost::program_options::required_option& e)
    {
      ALICEVISION_CERR("ERROR: " << e.what() << std::endl);
      ALICEVISION_COUT("Usage:\n\n" << inputParams);
      return EXIT_FAILURE;
    }
    catch(boost::program_options::error& e)
    {
      ALICEVISION_CERR("ERROR: " << e.what() << std::endl);
      ALICEVISION_COUT("Usage:\n\n" << inputParams);
      return EXIT_FAILURE;
    }

    // check hardware compatibility
    if(!checkHardwareCompatibility())
        return EXIT_FAILURE;

    ALICEVISION_COUT("ini file: " << iniFilepath);
    ALICEVISION_COUT("inputMesh: " << inputMeshFilepath);

    // .ini parsing
    multiviewInputParams mip(iniFilepath);
    const double simThr = mip._ini.get<double>("global.simThr", 0.0);
    multiviewParams mp(mip.getNbCameras(), &mip, (float) simThr);
    mv_prematch_cams pc(&mp);

    if(false)
    {
        // Retexture from previous texture files.
        // Kept here for testing purposes. Should be removed later.

        bfs::path outPath;
        outPath = mip._ini.get<std::string>("global.outDir", "_OUT");
        if(outPath.is_relative())
            outPath = bfs::path(mip.mvDir) / outPath;
        std::string refMeshFilepath = (outPath / "meshAvImgTex.obj").string();

        mv_mesh_retexture_obj mro(&mp, &pc, refMeshFilepath, inputMeshFilepath);
        mro.retexture(absolutePathNoExt(refMeshFilepath).string(), absolutePathNoExt(inputMeshFilepath).string(), absolutePathNoExt(inputMeshFilepath).string() + "_normal");
        return EXIT_SUCCESS;
    }

    std::string refMeshFilepath = mip.mvDir + "mesh.bin";
    mv_mesh* mesh = new mv_mesh();
    if(!mesh->loadFromBin(refMeshFilepath))
    {
        std::cerr << "Unable to load: " << refMeshFilepath << std::endl;
        return EXIT_FAILURE;
    }
    staticVector<staticVector<int>*>* ptsCams = loadArrayOfArraysFromFile<int>(mip.mvDir + "meshPtsCamsFromDGC.bin");
    if(ptsCams->size() != mesh->pts->size())
        throw std::runtime_error("Error: Reference mesh and associated visibilities don't have the same size.");
    // filterPtsCamsByMinimalPixelSize(refMesh, refPtsCams, &mp);

    if(!inputMeshFilepath.empty())
    {
        meshRetex otherMesh;
        otherMesh.me = new mv_mesh();
        if(!otherMesh.me->loadFromObjAscii(
                    otherMesh.nmtls, &(otherMesh.trisMtlIds), &(otherMesh.normals), &(otherMesh.trisNormalsIds),
                                                    &(otherMesh.uvCoords), &(otherMesh.trisUvIds),
                    inputMeshFilepath))
        {
            std::cerr << "Unable to load: " << inputMeshFilepath << std::endl;
            return EXIT_FAILURE;
        }
        if(flipNormals)
            otherMesh.me->invertTriangleOrientations();

        mv_delaunay_GC* delaunayGC = new mv_delaunay_GC(&mp, &pc);
        delaunayGC->initTetrahedralizationFromMeshVertices(mesh, false);
        staticVector<staticVector<int>*>* otherPtsCams = delaunayGC->createPtsCamsForAnotherMesh(ptsCams, *otherMesh.me);

        std::swap(otherMesh.me, mesh);
        std::swap(ptsCams, otherPtsCams);

        deleteArrayOfArrays<int>(&otherPtsCams);
    }
    bfs::create_directory(outputFolder);

    mv_mesh_uvatlas mua(*mesh, mp, ptsCams);
    deleteArrayOfArrays<int>(&ptsCams);

    mv_output3D o3d(&mp);
    o3d.saveAsTexturedOBJ(outputFolder, mua);

    delete mesh;

    printfElapsedTime(startTime, "#");

    return EXIT_SUCCESS;
}
