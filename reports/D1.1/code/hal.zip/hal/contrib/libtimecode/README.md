libTimecode
-----------

Timecode and Framerate manipulation functions.

**WORK IN PROGRESS** (Oct/31/2012)

Documentation
-------------

http://x42.github.com/libtimecode/

