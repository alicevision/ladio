#pragma once

#include <memory>
#include <mutex>
#include <dbus-c++/dbus.h>
#include "IOControllerAdaptor.h"

class LEDBlinker;

class IOControllerServer
: public no::quine::CamBox::IOController_adaptor,
  public DBus::IntrospectableAdaptor,
  public DBus::ObjectAdaptor
{
  std::unique_ptr<LEDBlinker> _green_led_blinker;
  std::unique_ptr<LEDBlinker> _red_led_blinker;

  unsigned _failbits;
  bool _recording;
  bool _copying;
  std::mutex _mutex;
public:
  // Hardcoded other places, so make sure values stay this way
  enum Facility { HAL=0, DISK=1, NETWORK=2 };

  static const std::string NAME;
  static const std::string PATH;

  IOControllerServer(DBus::Connection &connection);
  ~IOControllerServer();

  void SetRecording(const bool& recording) override;
  void SetCopying(const bool& copying) override;
  void SetErrorLevel(const int32_t& facility, const bool& failed) override;
};

void InitGPIO();
