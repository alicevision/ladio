#include "server.h"
#include <signal.h>

static DBus::BusDispatcher dispatcher;

static void quit(int)
{
  dispatcher.leave();
}

int main()
{
  signal(SIGTERM, quit);
  signal(SIGINT, quit);

  InitGPIO();

  DBus::default_dispatcher = &dispatcher;
  DBus::Connection conn = DBus::Connection::SystemBus();
  conn.request_name(IOControllerServer::NAME.c_str());

  IOControllerServer server(conn);
  dispatcher.enter();
  return 0;
}
