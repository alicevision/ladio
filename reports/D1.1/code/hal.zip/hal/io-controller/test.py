import dbus
bus = dbus.SystemBus()
object = bus.get_object('no.quine.CamBox', '/no/quine/CamBox/IOController')
iface = dbus.Interface(object, 'no.quine.CamBox.IOController')
iface.SetCopying(2)
