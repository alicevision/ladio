#include "server.h"
#include <time.h>
#include <semaeapi.h>
#include <atomic>
#include <iostream>
#include <string>
#include <thread>

static uint32_t SEMA_HANDLE;

void InitGPIO()
{
  char ip[] = "127.0.0.1";
  char pw[] = "123";
  if (SemaEApiLibInitialize(false, IP_V4, ip, 0, pw, &SEMA_HANDLE) != EAPI_STATUS_SUCCESS)
    throw std::runtime_error("SemaEApiLibInitialize");
}

//////////////////////////////////////////////////////////////////////////////

const std::string IOControllerServer::NAME = "no.quine.CamBox";
const std::string IOControllerServer::PATH = "/no/quine/CamBox/IOController";

class LEDBlinker
{
public:
  enum Mode : int { off, blink, on };
  static constexpr int BLINK_INTERVAL_MS = 250;

  LEDBlinker(int pin);
  ~LEDBlinker();
  void SetMode(Mode mode);

private:
  std::thread _thread;
  int _pin;
  bool _pin_state;
  std::atomic<bool> _exit;
  std::atomic<Mode> _mode;

  bool NextPinState() const;
  void SetPinState(bool);
  void Thread();
};

LEDBlinker::LEDBlinker(int pin) :
  _pin(pin), _exit(false), _mode(off)
{
  SetPinState(off);
  _thread = std::thread(&LEDBlinker::Thread, this);
}

LEDBlinker::~LEDBlinker()
{
  SetPinState(false);
  _exit = true;
  _thread.join();
}

void LEDBlinker::SetMode(Mode mode)
{
  _mode = mode;
}

void LEDBlinker::Thread()
{
  struct timespec tp{ 0, BLINK_INTERVAL_MS * 1000000 };
  while (!_exit) {
    SetPinState(_pin_state);
    nanosleep(&tp, nullptr);
    _pin_state = NextPinState();
  }
}

void LEDBlinker::SetPinState(bool state)
{
  // Ignore errors here, SEMA returns "unknown error" on level change.
  _pin_state = state;
  SemaEApiGPIOSetLevel(SEMA_HANDLE, EAPI_GPIO_GPIO_ID(_pin), 1, state);
}

bool LEDBlinker::NextPinState() const
{
  if (_mode == off) return false;
  if (_mode == on) return true;
  return !_pin_state;
}

//////////////////////////////////////////////////////////////////////////////

IOControllerServer::IOControllerServer(DBus::Connection &connection) :
  DBus::ObjectAdaptor(connection, PATH),
  _green_led_blinker(new LEDBlinker(4)),
  _red_led_blinker(new LEDBlinker(5)),
  _failbits(0),
  _recording(false),
  _copying(false)
  
{
}

IOControllerServer::~IOControllerServer()
{}

void IOControllerServer::SetRecording(const bool& recording)
{
  std::lock_guard<std::mutex> lk(_mutex);
  std::clog << "SetRecording: " << recording << std::endl;
  _recording = recording;
  if (_recording) _red_led_blinker->SetMode(LEDBlinker::on);
  else if (_copying) _red_led_blinker->SetMode(LEDBlinker::blink);
  else _red_led_blinker->SetMode(LEDBlinker::off);
}

void IOControllerServer::SetCopying(const bool& copying)
{
  std::lock_guard<std::mutex> lk(_mutex);
  std::clog << "SetCopying: " << copying << std::endl;
  _copying = copying;
  if (!_recording)
    _red_led_blinker->SetMode(_copying ? LEDBlinker::blink : LEDBlinker::off);
}

void IOControllerServer::SetErrorLevel(const int32_t& facility, const bool& failed)
{
  std::lock_guard<std::mutex> lk(_mutex);
  std::clog << "SetErrorLevel: " << facility << " " << failed << std::endl;

  if (failed) _failbits |= 1U << facility;
  else _failbits &= ~(1U << facility);
  
  if (!_failbits) _green_led_blinker->SetMode(LEDBlinker::on);
  else _green_led_blinker->SetMode(LEDBlinker::blink);
}

