// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <assert.h>
#include <QThread>
#include <QtGlobal>
#include <QtEndian>
#include <QDebug>
#include <QDir>
#include <QFileInfo>
#include <QCoreApplication>
#include <memory>
#include <stdexcept>
#include "QMLExternalProcessAPI.h"
#include "ProcessUtils.h"

namespace labo
{

/////////////////////////////////////////////////////////////////////////////

DaneelController::DaneelController(QObject *parent) :
  QObject(parent),
  _daneelProcess(nullptr),
  _daneelRPCClient(nullptr)
{
  _cacheDirectory = GetDataDirectory("NETWORK_CACHE");
}

void DaneelController::start()
{
  if (_daneelProcess)
    throw std::runtime_error("daneel cannot be started multiple times");
  
  if (FindProcessByName("daneel") != -1) {
    qWarning() << "daneel already running; will not be unable to monitor it";
    goto initRPCClient;
  }

  {
    QString daneelPath = QCoreApplication::applicationDirPath() + "/daneel";
    _daneelProcess = StartProcessInTerminal(daneelPath,
      QStringList() <<
        "--cacheDir" << cacheDirectory() <<
        "--logLevel" << "1");
    connect(_daneelProcess, static_cast<void(QProcess::*)(int, QProcess::ExitStatus)>(&QProcess::finished),
      this, [this](int, QProcess::ExitStatus) {
        emit daneelExited();  // Give a chance to handle it before crash
        throw std::runtime_error("daneel crashed; appCutie must be restarted");
    });


    // Wait for daneel to start.
    QThread::msleep(1000);
  }
  
initRPCClient:
  if (!QFile::exists("/tmp/LaboDemuxer.C"))
    throw std::runtime_error("timeout waiting for daneel to start");
  _daneelRPCClient = new DaneelRPCClient(this);
  if (!_daneelRPCClient->isConnected())
    throw std::runtime_error("couldn't connect to daneel");

  updateStreamList();
  
}

// Must be called when there is no playback running because playback is using a Demuxer's slot.
void DaneelController::updateStreamList()
{
  auto streams = _daneelRPCClient->listStreams();
  if (!streams.empty()) {
    _streamList.clear();
    for (const auto& s : streams)
      _streamList.append(s);
    emit streamListChanged();
  }
}

void DaneelController::playStream(const QString& streamName, int streamPort)
{
  _daneelRPCClient->playStream(streamName.toStdString(), streamPort);
}

bool DaneelController::cachingEnabled()
{
  return _daneelRPCClient->cachingEnabled();
}

void DaneelController::enableCaching(bool enabled)
{
  _daneelRPCClient->enableCaching(enabled);
}


QObject *DaneelController::singletonProviderCB(QQmlEngine*, QJSEngine*)
{
  static DaneelController *instance = nullptr;
  if (!instance)
    instance = new DaneelController();
  return instance;
}

/////////////////////////////////////////////////////////////////////////////

GortController::GortController(QObject* parent) :
  QObject(parent),
  _gortProcess(nullptr),
  _calibrationProcess(nullptr)
{
  _calibrationDataDirectory = GetDataDirectory("CALIBRATION_DATA");
}

void GortController::reloadParameters()
{
  if (_gortProcess) {
    // Must disconnect signals before killing so that gort doesn't get started
    // from the crash handler [finished() signal] too.  Must also wait for it
    // to finish.
    _gortProcess->disconnect(); // disconnects all signals
    _gortProcess->kill();
    if (!_gortProcess->waitForFinished(5000))
      qCritical() << "gort failed to exit upon signal; this may cause further errors";
    delete _gortProcess;
    _gortProcess = nullptr;
  }
  startGort();
}

void GortController::startGort()
{
  Q_ASSERT(!_gortProcess);
  
  if (FindProcessByName("appGort") != -1)
    throw std::runtime_error("gort started externally; clean up and restart appCutie");

  // XXX: Some error-checking here!
  QString gortPath = QCoreApplication::applicationDirPath() + "/appGort";
  QString sfmDataPath = _sfmReconstructionFilepath;
  QString descFolder = QFileInfo(_sfmReconstructionFilepath).absolutePath() + "/_mvg_build/matches";
  
  QStringList args;
  args <<
    QString("--shmName=/LaboDemuxer.1") <<
    QString("--sfmData=") + sfmDataPath <<
    QString("--descFolder=") + descFolder <<
    QString("--wcIntrinsicsFile=") + _wc1IntCalFilePath;
  if (!_sdiIntCalFilePath.isEmpty())
    args << QString("--sdiIntrinsicsFile=") + _sdiIntCalFilePath;
  if (!_extCalFilePath.isEmpty())
    args << QString("--extrinsicsFile=") + _extCalFilePath;

  qInfo() << "Starting: " << gortPath << " " << args.join(" ");
  
  _gortProcess = StartProcessInTerminal(gortPath,args);
  
  connect(_gortProcess, static_cast<void(QProcess::*)(int, QProcess::ExitStatus)>(&QProcess::finished),
    this, [this](int exitCode, QProcess::ExitStatus) {
      if (_gortProcess) {
        qInfo() << "gort crashed; exit code was: " << exitCode;
        _gortProcess->deleteLater();
        _gortProcess = nullptr;
      }
      qInfo() << "Restarting gort.";
      startGort();
  });
}

QObject *GortController::singletonProviderCB(QQmlEngine*, QJSEngine*)
{
  static GortController *instance = nullptr;
  if (!instance)
    instance = new GortController();
  return instance;
}

/////////////////////////////////////////////////////////////////////////////

CalibrationController::CalibrationController(QObject* parent) : QObject(parent)
{
  _calibrationProcess = nullptr;
}

void CalibrationController::setOutputFilePath(const QString& filePath)
{
  if (_calibrationProcess)
    throw std::runtime_error("cannot change output file name while calibration process is running");
  _outputFilePath = filePath;
}

void CalibrationController::run(const QString& programPath, const QStringList& args)
{
  if (_calibrationProcess)
    throw std::runtime_error("cannot start calibration process while another is running");
  
  _calibrationProcess = StartProcessInTerminal(programPath, args);
  connect(_calibrationProcess, static_cast<void(QProcess::*)(int, QProcess::ExitStatus)>(&QProcess::finished),
    this, &CalibrationController::processFinished);
}

void CalibrationController::processFinished(int, QProcess::ExitStatus)
{
  _calibrationProcess->deleteLater();
  _calibrationProcess = nullptr;
  bool fileGenerated = QFileInfo::exists(_outputFilePath);
  emit calibrationFinished(fileGenerated);
}

/////////////////////////////////////////////////////////////////////////////

IntCalController::IntCalController(QObject* parent) : CalibrationController(parent),
  _maxFrames(1000),
  _boardRows(1),
  _boardColumns(1)
{ }

void IntCalController::run()
{
  QString programPath = "openMVG_main_cameraCalibration";
  QStringList args = QStringList()
    << "--size" << QString::number(_boardColumns) << QString::number(_boardRows)
    << "--maxFrames" << QString::number(_maxFrames)
    << "--input" << _videoFilePath
    << "--output" << outputFilePath();
  
  qInfo() << "Starting: " << programPath << " " << args.join(" ");
  
  CalibrationController::run(programPath, args);
}

QObject* IntCalController::singletonProviderCB(QQmlEngine*, QJSEngine*)
{
  static IntCalController* instance = nullptr;
  if (!instance)
    instance = new IntCalController();
  return instance;
}

/////////////////////////////////////////////////////////////////////////////

ExtCalController::ExtCalController(QObject* parent) : CalibrationController(parent),
  _fps(5)
{
}

void ExtCalController::run()
{
  QString programPath = "openMVG_main_rigCalibration";
  QStringList args = QStringList()
    << "--sfmdata" << _sfmReconstructionFilepath
    << "--cameraIntrinsics" << _sdiIntrinsicsFilePath << _wc1IntrinsicsFilePath << _wc2IntrinsicsFilePath
    << "--mediapath" << _sdiVideoFilePath << _wc1VideoFilePath
    // << QString::number(_fps)
    // << "--nNearestKeyFrames" << "5"
    << "--outfile" << outputFilePath();
  
  qInfo() << "Starting: " << programPath << " " << args.join(" ");
  
  CalibrationController::run(programPath, args);
}

QObject* ExtCalController::singletonProviderCB(QQmlEngine*, QJSEngine*)
{
  static ExtCalController* instance = nullptr;
  if (!instance)
    instance = new ExtCalController();
  return instance;
}

} // labo

