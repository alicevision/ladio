// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <QCoreApplication>
#include <QStandardPaths>
#include <QDir>
#include <QFileInfo>
#include <QDebug>
#include "ProcessUtils.h"

namespace labo
{

static QString ResourcePrefix;

/*!
 The prefix may be either empty to use embedded resources, or a valid directory.
 \throw std::runtime_error if the prefix is a non-existent directory.
 */
void SetResourcePrefix(const QString& prefix)
{
  if (!prefix.isEmpty() && !QDir(prefix).exists())
    throw std::runtime_error(std::string("SetResourcePrefix: non-existent directory") + prefix.toStdString());
  ResourcePrefix = prefix;
}

const QString& GetResourcePrefix()
{
  return ResourcePrefix;
}

QString GetResourcePath(const QString& resource)
{
  auto path = (ResourcePrefix.isEmpty() ? ":/" : ResourcePrefix) + resource;
  if (!QFile::exists(path))
    throw std::invalid_argument(std::string("Required resource not found: ") + resource.toStdString());
  return path;
}

QUrl GetResourceUrl(const QString& resource)
{
  auto path = GetResourcePath(resource);
  if (ResourcePrefix.isEmpty()) path.replace(0, 2, "qrc://");
  else path.prepend("file://");
  return QUrl(path);
}

/////////////////////////////////////////////////////////////////////////////

/*! Return self-process name from argv0.  Will return only the name, w/o path. */
QString SelfProcessName()
{
  auto components = QCoreApplication::applicationFilePath().split('/');
  if (components.empty())
    throw std::runtime_error("SelfProcessName: empty applicationFilePath");
  return components.last();
}

/*!
 Finds a process whose command corresponds to name.  Throws std::runtime_error if
 there are multiple processes with the given name running.
*/ 
int FindProcessByName(const QString& name)
{
  QProcess p;
  p.start("/bin/sh", QStringList() << "-c" << QString("ps cx | grep %1").arg(name));
  
  if (!p.waitForStarted(1000))
    throw std::runtime_error("failed to run shell command");
  if (!p.waitForFinished(2000))
    throw std::runtime_error("timeout waiting for shell command");
  if (p.exitStatus() != QProcess::NormalExit)
    throw std::runtime_error("shell crashed");
  if (p.exitCode() != 0)  // grep didn't find anything
    return -1;
  
  auto lines = p.readAll().split('\n');
  Q_ASSERT(lines.size() > 0);
  
  // Even with a single line of output, split will append an empty string to the end of the list.
  if (lines.back() == "")
    lines.pop_back();
  if (lines.size() > 1)
    throw std::runtime_error(std::string("multiple instances of support program running ") + name.toStdString());

  // Parse PID.  Should check field count, but executables may contain empty spaces :/
  auto fields = QString(lines[0]).split(' ', QString::SkipEmptyParts);
  if (fields[2].contains('Z'))	// ugly hack; zombies are not reaped immediately
    return -1;
  bool ok;
  int pid = fields[0].toInt(&ok);
  if (!ok)
    throw std::runtime_error(std::string("could not parse ps output; line: ") + lines[0].toStdString());
  
  return pid;
}

/*! Uses QStandardPaths::AppLocalDataLocation to find the root. */
QString GetDataDirectory(const QString& name)
{
  auto dataRootDirectory = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
  if (dataRootDirectory.isEmpty())
    throw std::runtime_error("could not determine standard location for application data");

  auto dataDirectory = dataRootDirectory + "/" + name;
  if (!QDir(dataDirectory).exists() && !QDir().mkpath(dataDirectory))
    throw std::runtime_error(std::string("couldn't create application data directory: ") + dataDirectory.toStdString());
  
  return dataDirectory;
}

QProcess* StartProcessInTerminal(const QString& pathToProcess, QStringList args)
{
  QString execPath;
  
#if defined(Q_OS_LINUX)

  execPath = "/usr/bin/xterm";
  if (!execPath.isEmpty())
    args = QStringList() << "-hold" << "-e" << pathToProcess << args; // -e must come last
  else
    execPath = pathToProcess;

#elif defined(Q_OS_OSX)

  execPath = "/opt/X11/bin/xterm";
  if (!execPath.isEmpty())
    args = QStringList() << "-hold" << "-e" << pathToProcess << args; // -e must come last
  else
    execPath = pathToProcess;
#else
#warning "Unsupported platform; spawning in terminal won't work";
#endif
  
  QProcess *process = new QProcess(QCoreApplication::instance());
  process->start(execPath, args, QIODevice::NotOpen);
  if (!process->waitForStarted(20000))
    throw std::runtime_error(std::string("timeout waiting to start process: ") + pathToProcess.toStdString());
  return process;
}


}
