// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <functional>
#include <QLocalSocket>
#include <QStringList>
#include "SHMInterface.h"
#include "HalFrame.pb.h"
#include "HalService.pb.h"

namespace labo
{

class RPCClient : public QObject
{
protected:
  QLocalSocket _socket;
  std::string _rpcBytes;        // serialized RPC message
  uint32_t _replySize;          // size to read from the socket
  int64_t _requestId;

  static void frameMessage(const hal::RPCMessage& msg, std::string& buffer);
  RPCClient(const QString& path, QObject* parent = 0);
  bool rpcCallSync(hal::RPCMessage& msg);
  
public:
  bool isConnected() const { return _socket.isOpen(); }
};

/////////////////////////////////////////////////////////////////////////////

class DaneelRPCClient : public RPCClient
{
public:
  DaneelRPCClient(QObject* parent = 0);
  QStringList listStreams();
  void playStream(const std::string& streamName, int streamPort);
  bool cachingEnabled();
  void enableCaching(bool);
};

/////////////////////////////////////////////////////////////////////////////

class DemuxerRPCClient : public RPCClient
{
  using FrameCB = std::function<void(const hal::FrameMetadata&)>;
  
  hal::SHMInterface& _shm;
  const int _slot;
  int _frameOrd;                // last ord
  int64_t _lastpts;             // for debugging [writing out dropped frames]
  FrameCB _frameCB;

  void getFrame();
  void getFrameReadCB();

public:
  DemuxerRPCClient(const char *name, int slot, QObject* parent = 0);
  void connect(FrameCB frameCB);
  
  hal::SHMInterface& shm()
  {
    return _shm;
  }
  
  bool isRunning() const
  {
    return _frameCB != nullptr;
  }
};
    
}   // labo
