// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <boost/numeric/conversion/cast.hpp>
#include <QDebug>
#include <QtGlobal>
#include <string>
#include <stdexcept>
#include "VideoSource.h"
#include "TCUtil.h"
#include "HalService.pb.h"

using boost::numeric_cast;

namespace labo
{

static const std::tuple<short, short, short, short> NO_TC = std::tuple<short, short, short, short>(0, 0, 0, 0);

/*!
 Name is used only to connect to the demuxer's RPC server instance.  Server and
 port is specified in the start() method.
 */
HalQtVideoSource::HalQtVideoSource(QObject *parent, const char* name, unsigned minQueueLength) :
  QObject(parent),
  _name(name),
  _minQueueLength(minQueueLength),
  _requestLocalization(false),
  _sws(nullptr)
{
}

HalQtVideoSource::~HalQtVideoSource()
{
  assert(!isRunning());
}

void HalQtVideoSource::start(int slot)
{
  if (_rpcClient)
    throw std::logic_error("HalQtVideoSource: cannot call start without intervening stop");
  if (slot != hal::SHMManager::RENDER_CLIENT_SLOT && slot != hal::SHMManager::DISPLAY_CONTROLLER_SLOT)
    throw std::invalid_argument("HalQtVideoSource: slot");
  
  _rpcClient = std::unique_ptr<DemuxerRPCClient>(new DemuxerRPCClient(_name.c_str(), slot, this));
  _rpcClient->connect([this](const hal::FrameMetadata& frameMetadata) { processFrame(frameMetadata); });
}

void HalQtVideoSource::stop()
{
  _rpcClient->disconnect();
  _rpcClient.reset();
}

/*!
 Dequeue a frame if there are at least minQueueLength frames in the queue.
 \return false if there aren't enough frames in the queue.
 */
bool HalQtVideoSource::dequeue(Frame& frame)
{
  if (static_cast<unsigned>(_frameQueue.size()) < _minQueueLength)
    return false;
  
  if (!_requestLocalization) {
    assert(_locQueue.empty());
    frame = _frameQueue.takeFirst();
    frame.metadata.clear_localization();
    return true;
  }
  
  // Match up frame TC with localization TCs in the queue; simple 2-way merge.
  while (!_locQueue.empty() && (unsigned)_frameQueue.size() >= _minQueueLength) {
    const auto frameTC = to_tuple(_frameQueue.front().metadata.time());
    const auto locTC = to_tuple(_locQueue.front().time());
    
    if((frameTC != NO_TC) && (locTC != NO_TC)) {
      // If the main video stream contains a valid timecode,
      // we use it to synchronize the main video frames with the localization frames.
      // Else if we don't have a valid timecode, we just return
      // the last frame and the last localization together.
      
      if (frameTC < locTC) {
        // Skip the main video stream frame as the latest localization is more recent.
        _frameQueue.pop_front();
        continue;
      }

      if (frameTC > locTC) {
        // Skip the localization frame as we don't have the corresponding localization information anymore.
        // We put a warning because this should not happen in standard scenarios.
        qWarning() << name() << ": unmatched localization TC: " << to_string(_locQueue.front().time()).c_str();
        _locQueue.pop_front();
        continue;
      }
      
      assert(frameTC == locTC);
    }
    
    frame = _frameQueue.takeFirst();
    *frame.metadata.mutable_localization() = _locQueue.takeFirst();
    return true;
  }

  // Nothing matched.
  return false;
}

/*!
 Release a frame previously returned by dequeue.  Calling this method is only
 an optimization: it will enqueue the frame into an internal cache of free
 frames, and thus help avoid allocating memory every time a new frame is
 delivered.
 NB: only image data is released; metadata remains valid.
 */
void HalQtVideoSource::release(Frame& frame)
{
  if (_freeQueue.size() < CACHE_QUEUE_LENGTH)
    _freeQueue.append(frame.image);   // free queue managed as LIFO
  frame.image = QImage();
}

// Metadata is received through the RPC socket; bulk image data is in SHM front buffer.
void HalQtVideoSource::processFrame(const hal::FrameMetadata &metadata)
{
  assert(_requestLocalization || _locQueue.empty());
  enqueueScaledImage(metadata);
  if (_requestLocalization && metadata.has_localization())
    enqueueLocalization(metadata.localization());
  emit frameEnqueued(_frameQueue.back().image, &_frameQueue.back().metadata);
}

// Appends received frame with metadata to _frameQueue
void HalQtVideoSource::enqueueScaledImage(const hal::FrameMetadata& metadata)
{
  if (!_frameQueue.empty() && to_tuple(metadata.time()) != NO_TC && to_tuple(metadata.time()) <= to_tuple(_frameQueue.back().metadata.time())) {
    qWarning() << name() << ": non-monotonic frame timecode; IGNORING: " <<
      "highest in queue: " << to_string(_frameQueue.back().metadata.time()).c_str() <<
      "; received: " << to_string(metadata.time()).c_str();
  }
  
  uchar *const frameBits = reinterpret_cast<uchar*>(_rpcClient->shm().frame().yuv.get());
  const QSize frameSize(metadata.width(), metadata.height());

  // NB! target pixel format must match the format we specify to OpenGL (GL_RGBA).
  _sws = sws_getCachedContext(_sws,
          // source
          frameSize.width(), frameSize.height(), static_cast<AVPixelFormat>(AV_PIX_FMT_YUV420P),
          // target
          frameSize.width(), frameSize.height(), AV_PIX_FMT_RGBA,
          SWS_FAST_BILINEAR,
          nullptr, nullptr, nullptr);
  
  if (!_sws)
    throw std::runtime_error("H264Decoder: sws_getContext");

  // Destination is RGBA packed; has only one plane.
  QImage targetImage = allocateImage(frameSize);
  uint8_t *dst[3] = { targetImage.bits(), 0, 0 };
  int dstStride[3] = { frameSize.width() * 4, 0, 0 };

  // Source is YUV 420P
  uint8_t *src[3];
  src[0] = frameBits;
  src[1] = src[0] + 2000 * 2000;
  src[2] = src[1] + 2000 * 2000 / 4;

  int srcStride[3];
  srcStride[0] = frameSize.width();
  srcStride[1] = frameSize.width() / 2;
  srcStride[2] = frameSize.width() / 2;

  sws_scale(_sws, src, srcStride, 0, frameSize.height(), dst, dstStride);

  _frameQueue.append(Frame{metadata, targetImage});
}

// Puts localization in sorted order into _locQueue.
void HalQtVideoSource::enqueueLocalization(const hal::LocalizationInfo& localization)
{
  assert(!_frameQueue.empty() && _requestLocalization);
  
  if (_locQueue.empty() || to_tuple(localization.time()) > to_tuple(_locQueue.back().time())) {
    _locQueue.push_back(localization);
    return;
  }
  
  qWarning() << name() << ": non-monotonic localization timecode; " <<
    "highest in queue: " << to_string(_locQueue.back().time()).c_str() <<
    "; received: " << to_string(localization.time()).c_str();
  
  auto it = std::lower_bound(_locQueue.begin(), _locQueue.end(), localization,
    [](const hal::LocalizationInfo& l1, const hal::LocalizationInfo& l2) {
      return to_tuple(l1.time()) < to_tuple(l2.time());
  });
  assert(it != _locQueue.end());  // largest, is handled above
  
  if (to_tuple(it->time()) == to_tuple(localization.time())) {
    qWarning() << name() << ": localization returned duplicate time-code; ignoring: " << to_string(localization.time()).c_str();
    return;
  }
  
  _locQueue.insert(it, localization);
}

// If the queue capacity would be exceeded, reuse the front of the queue and put it at the back.
QImage HalQtVideoSource::allocateImage(const QSize& frameSize)
{
  QImage targetImage;

  if (static_cast<unsigned>(_frameQueue.size()) < MAX_QUEUE_LENGTH) {  // must get a new image...
    if (!_freeQueue.isEmpty())
      targetImage = _freeQueue.takeLast();      // free queue managed as LIFO
  } else {                                      // ... else must drop oldest frame
    qDebug() << name() << ": Queue length exceeded; dropping frame; " << this;
    targetImage = _frameQueue.takeFirst().image;
    _frameQueue.pop_front();
    emit frameDropped();
  }

  if (targetImage.size() != frameSize)
    targetImage = QImage(frameSize, QImage::Format_RGB32);

  assert(static_cast<unsigned>(_frameQueue.size()) <= MAX_QUEUE_LENGTH);
  assert(static_cast<unsigned>(_freeQueue.size()) <= CACHE_QUEUE_LENGTH);
  assert(targetImage.size() == frameSize);

  return targetImage;
}

} // labo

