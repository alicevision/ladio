// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <math.h>
#include <sstream>
#include <QQuickWindow>
#include <QImage>
#include "VideoSource.h"
#include "VideoItem.h"

namespace labo
{

static constexpr int FRAME_RATE_MS = 40;
static constexpr int MIN_QUEUE_LENGTH = 1;
// This is the maximal queue length before starting to force an update
// of the image independently from the FPS.
static constexpr int MAX_QUEUE_LENGTH = 2;

HalQtVideoItem::HalQtVideoItem(QQuickItem *parent) :
  QQuickFramebufferObject(parent),
  _timerId(0),
  _slot(0),
  _requestLocalization(false),
  _frameWidth(0),
  _frameHeight(0),
  _paused(false)
{
  // Setup window events.
  connect(this, &HalQtVideoItem::windowChanged, this, &HalQtVideoItem::onWindowChanged);
  // NOTE: video frames are consumed by timer, set up in start()
}

void HalQtVideoItem::setSourceName(const QString& name)
{
  if (_videoSource) {
    qWarning() << "Cannot change source while video source is running.";
    return;
  }
  _sourceName = name;
}

void HalQtVideoItem::setSlot(int slot)
{
  if (_videoSource) {
    qWarning() << "Cannot change slot while video source is running.";
    return;
  }
  _slot = slot;
}

void HalQtVideoItem::setRequestLocalization(bool v)
{
  _requestLocalization = v;
  if (_videoSource)
    _videoSource->setRequestLocalization(v);
  emit requestLocalizationChanged();
}

void HalQtVideoItem::start()
{
  if (_videoSource)
    throw std::logic_error("HalQtVideoItem: stream already running");
  _videoSource.reset(new HalQtVideoSource(this, _sourceName.toStdString().c_str(), MIN_QUEUE_LENGTH));
  connect(_videoSource.get(), &HalQtVideoSource::frameDropped,
    [this]() { qWarning() << "HalQtVideoItem: video source dropped frame; " << this; });
  connect(_videoSource.get(), &HalQtVideoSource::frameEnqueued, this, &HalQtVideoItem::frameEnqueued);

  _videoSource->start(_slot);
  _videoSource->setRequestLocalization(_requestLocalization);
  emit isRunningChanged();
  if (!(_timerId = startTimer(FRAME_RATE_MS)))
    qWarning() << "HalQtVideoItem: Couldn't start timer; no video will be displayed.";
}

/*! Stops streaming and clears streamUrl property. */
void HalQtVideoItem::stop()
{
  if (_videoSource) {
    _videoSource->stop();
    _videoSource.reset();
  }
  killTimer(_timerId);
  _timerId = 0;
  emit isRunningChanged();
}

void HalQtVideoItem::setPaused(bool paused)
{
  if (paused != _paused) {
    _paused = paused;
    if (_paused)
      _pausedFrame = _frame;
    emit pausedChanged();
  }
}

void HalQtVideoItem::updateFrame()
{
  if(_frameWidth != _frame.metadata.width() || _frameHeight != _frame.metadata.height()) {
    _frameWidth = _frame.metadata.width();
    _frameHeight = _frame.metadata.height();
    emit frameSizeChanged();
  }

  if (!_frame.metadata.recording().on())
    _frame.metadata.mutable_recording()->clear_filename();
  if (_recordingFilename != _frame.metadata.recording().filename().c_str()) {
    _recordingFilename = _frame.metadata.recording().filename().c_str();
    emit recordingFilenameChanged();
  }
  
  update();
}

void HalQtVideoItem::timerEvent(QTimerEvent *ev)
{
  assert(ev->timerId() == _timerId);
  if (_videoSource->dequeue(_frame))
    updateFrame();
}

void HalQtVideoItem::frameEnqueued(QImage, hal::FrameMetadata*)
{
  if (_videoSource->queueLength() > MAX_QUEUE_LENGTH) {
    _videoSource->dequeue(_frame);
    updateFrame();
  }
}

void HalQtVideoItem::onWindowChanged(QQuickWindow *w)
{
  if (!w && _videoSource)
    _videoSource->stop();
}

}   // namespace labo
