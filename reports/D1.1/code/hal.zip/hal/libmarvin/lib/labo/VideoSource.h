// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <QQueue>
#include <QImage>
#include <QLocalSocket>
#include "DemuxerRPCClient.h"
#include "HalFrame.pb.h"
#include "HalService.pb.h"

extern "C"
{
#include <libswscale/swscale.h>
}

namespace labo
{


/*!
 Qt is icky about what can/must (not) be called from UI/rendering thread. This class
 encapsulates a thread which communicates synchronously with the demuxer RPC server.

 An internal queue of frames is maintained up to a given maximum length.  If the
 consumer is very slow, oldest frames will be dropped to accomodate newer frames.

 \note Image and metadata are returned to the consumer by value, so the consumer
 can thus be arbitrarily slow. (QImage is implicitly shared in Qt, i.e., it is
 cheap to "copy".)

 \todo We don't really need a thread.  Now that we use UNIX sockets to check
 for new frames, we could integrate it into the Qt event loop.

 \todo Buffer with a poll-based interface is a general utility class.  Should be
 decoupled from Qt and moved to libMarvin.
*/

class HalQtVideoSource : public QObject
{
  Q_OBJECT

public:
  struct Frame
  {
    hal::FrameMetadata metadata;
    QImage image;
  };

private:
  const std::string _name;
  const unsigned _minQueueLength;
  bool _requestLocalization;
  std::unique_ptr<DemuxerRPCClient> _rpcClient;
  QQueue<Frame> _frameQueue;                // frames waiting to be displayed...
  QQueue<hal::LocalizationInfo> _locQueue;  // localization info sorted by TC
  QQueue<QImage> _freeQueue;                // frames to be reused
  struct SwsContext *_sws;

  void processFrame(const hal::FrameMetadata&);
  void enqueueScaledImage(const hal::FrameMetadata&);
  void enqueueLocalization(const hal::LocalizationInfo&);
  QImage allocateImage(const QSize &frameSize);

signals:
  void frameEnqueued(QImage, hal::FrameMetadata*);
  void frameDropped();

public:
  static constexpr unsigned MAX_QUEUE_LENGTH = 25;
  static constexpr int CACHE_QUEUE_LENGTH = 4;  // # of allocated frame for reuse

  HalQtVideoSource(QObject *parent, const char* name, unsigned minQueueLength);
  ~HalQtVideoSource();
  bool dequeue(Frame& frame);
  void release(Frame& frame);
  int queueLength() const { return _frameQueue.size(); }

  const char *name() const
  {
    return _rpcClient ? _rpcClient->shm().name() : "";
  }

  bool isRunning()
  {
    return _rpcClient ? _rpcClient->isRunning() : false;
  }
  
  bool requestLocalization() const
  {
    return _requestLocalization;
  }
  
  void setRequestLocalization(bool requestLocalization)
  {
    _requestLocalization = requestLocalization;
    if (!_requestLocalization)
      _locQueue.clear();
  }
  
  void start(int slot);
  void stop();
};

}   // namespace labo
