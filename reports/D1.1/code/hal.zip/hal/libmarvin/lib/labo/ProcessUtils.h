// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <QProcess>
#include <QStringList>
#include <QUrl>

namespace labo
{

void SetResourcePrefix(const QString& prefix);
const QString& GetResourcePrefix();
QString GetResourcePath(const QString& resource);
QUrl GetResourceUrl(const QString& resource);

QString SelfProcessName();
int FindProcessByName(const QString&);
QString GetDataDirectory(const QString&);
QProcess* StartProcessInTerminal(const QString& pathToProcess, QStringList args);

} // labo
