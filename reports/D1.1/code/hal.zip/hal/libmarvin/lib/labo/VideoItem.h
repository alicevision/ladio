// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <memory>
#include <QUrl>
#include <QQuickItem>
#include <QQuickPaintedItem>
#include <QQuickFramebufferObject>
#include <QImage>
#include <QOpenGLDebugLogger>
#include "VideoSource.h"

namespace labo
{

//! QtQuick item for displaying video.  This is an abstract class that just
//! defines common properties and "plumbing" towards HalQtVideoSource.
class HalQtVideoItem : public QQuickFramebufferObject
{
  Q_OBJECT
  Q_PROPERTY(QString sourceName READ sourceName WRITE setSourceName)
  Q_PROPERTY(int slot READ slot WRITE setSlot)
  Q_PROPERTY(bool requestLocalization READ requestLocalization WRITE setRequestLocalization NOTIFY requestLocalizationChanged)
  Q_PROPERTY(bool isRunning READ isRunning NOTIFY isRunningChanged)
  Q_PROPERTY(int frameWidth READ frameWidth NOTIFY frameSizeChanged)
  Q_PROPERTY(int frameHeight READ frameHeight NOTIFY frameSizeChanged)
  Q_PROPERTY(bool paused READ isPaused WRITE setPaused NOTIFY pausedChanged)
  Q_PROPERTY(QString recordingFilename READ recordingFilename NOTIFY recordingFilenameChanged)
  
  int _timerId;
  int _slot;
  bool _requestLocalization;
  QString _sourceName;
  std::unique_ptr<HalQtVideoSource> _videoSource;
  QString _recordingFilename;
  
  HalQtVideoSource::Frame _frame, _pausedFrame;
  int _frameWidth;
  int _frameHeight;
  bool _paused;
  
  void timerEvent(QTimerEvent*) override;
  void onWindowChanged(QQuickWindow*);
  void updateFrame();
  
protected:
  const HalQtVideoSource::Frame& getFrame() const
  {
    return _paused ? _pausedFrame : _frame;
  }
  
  void releaseFrame()
  {
    _videoSource->release(_frame);
  }
  
signals:
  void frameSizeChanged();
  void isRunningChanged();
  void requestLocalizationChanged();
  void recordingFilenameChanged();
  void pausedChanged();
  
private slots:
  void frameEnqueued(QImage, hal::FrameMetadata*);

public:
  HalQtVideoItem(QQuickItem *parent = 0);
  
  Q_INVOKABLE void start();
  Q_INVOKABLE void stop();

  QString sourceName() const { return _sourceName; }
  void setSourceName(const QString& name);
  int slot() const { return _slot; }
  void setSlot(int slot);
  bool requestLocalization() const { return _requestLocalization; }
  void setRequestLocalization(bool v);
  bool isRunning() const { return _videoSource ? _videoSource->isRunning() : false; }
  int frameWidth() const { return _frame.metadata.width(); }
  int frameHeight() const { return _frame.metadata.height(); }
  bool isPaused() const { return _paused; }
  void setPaused(bool);
  QString recordingFilename() const { return _recordingFilename; }
};

}   // namespace labo
