// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <QDir>
#include <QNetworkRequest>
#include <QEventLoop>
#include <QTimer>
#include <QRegExp>
#include "QMLHalAPI.h"
#include "QMLExternalProcessAPI.h"
#include "ProcessUtils.h"

namespace labo
{

QObject *HalController::singletonProviderCB(QQmlEngine*, QJSEngine*)
{
  static HalController *instance = nullptr;
  if (!instance)
    instance = new HalController();
  return instance;
}


HalController::HalController(QObject* parent) :
  QObject(parent),
  _networkAccessManager(new QNetworkAccessManager(this)),
  _networkReply(nullptr),
  _downloadFile(nullptr)
{
  _downloadDirectory = GetDataDirectory("HAL_DOWNLOADS");
}

void HalController::setUrl(QUrl url)
{
  if (url.scheme() != "hal") {
    qWarning() << "Invalid scheme; ignoring URL";
    return;
  }
  _baseURL = url;
}

// GET data from HAL.
// GRR, the damn api is inconsistent; see updateHalFileList().
// Normally, if query is non-empty, we'll use POST unles getMethodOverride is true.
QJsonDocument HalController::transact(const QString& path, const QUrlQuery& query, bool getMethodOverride)
{
  QNetworkReply* reply = nullptr;
  QJsonDocument result;
  
  
  {
    QUrl url = _baseURL;
    url.setScheme("http");
    url.setPort(5000);
    url.setPath(path);
    url.setQuery(query);

    QNetworkRequest request(url);

    if (!query.isEmpty() && !getMethodOverride)
      reply = _networkAccessManager->post(request, QByteArray());
    else
      reply = _networkAccessManager->get(request);

    qDebug() << "Sent HAL request: " << url;
  }
  
  // XXX: simulate blocking network read
  {
    QEventLoop loop;
    
    QTimer timer;
    timer.setInterval(1000);
    timer.setSingleShot(true);
    timer.start();
    
    connect(&timer, &QTimer::timeout, &loop, &QEventLoop::quit);
    connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
    loop.exec();
  }
  
  if (reply->isFinished()) {
    auto jsonString = reply->readAll();
    qDebug() << "Received HAL response: " << jsonString.left(256);  // write out max 256 chars
    result = QJsonDocument::fromJson(jsonString);
  }
  else {
    qWarning() << "HAL timed out; error: " << reply->errorString();
  }

  delete reply;
  return result;
}

QJsonObject HalController::toObject(const QJsonDocument& d)
{
  QJsonObject result;
  if (!d.isObject()) qWarning() << "HAL reply doesn't contain an object";
  else result = d.object();
  return result;
}

QJsonArray HalController::toArray(const QJsonDocument& d)
{
  QJsonArray result;
  if (!d.isArray()) qWarning() << "HAL reply doesn't contain an array";
  else result = d.array();
  return result;
}

bool HalController::recording()
{
  auto result = toObject(transact("/vtr/"));
  return result["record-flag"].toBool();
}

void HalController::setRecording(bool flag)
{
  QUrlQuery query;
  query.addQueryItem("record", flag ? "true" :  "false");
  transact("/vtr/", query);
}

QVariantMap HalController::getSDICameraParameters()
{
  return toObject(transact("/camera/main/status")).toVariantMap();
}

QVariantMap HalController::getWitnessCameraParameters(int camera)
{
  if (camera != 0 && camera != 1) {
    qWarning() << "Invalid WC id";
    return QVariantMap();
  }
  auto path = QString("/camera/wc/%1").arg(camera);
  return toObject(transact(path)).toVariantMap();
}

static QUrlQuery fillQuery(const QVariantMap& vm)
{
  QUrlQuery query;
  for (QVariantMap::const_iterator it = vm.constBegin(); it != vm.constEnd(); ++it)
    query.addQueryItem(it.key(), it.value().toString());
  return query;
}

void HalController::setWitnessCameraParameters(int camera, const QVariantMap& vm)
{
  auto query = fillQuery(vm);
  auto path = QString("/camera/wc/%1").arg(camera);
  transact(path, query);
}

void HalController::setSDICameraParameters(const QVariantMap&)
{
  qWarning() << "Setting SDI parameters unsupported in API";
}

void HalController::updateHalFileList()
{
  // XXX: damn inconsistent API design.  This is the only method which takes a 
  // parameter list but doesn't work with POST.
  QUrlQuery query;
  query.addQueryItem("subtree", "true");
  _halFileList = toArray(transact("/data/", query, true));
}

// Search through HAL file list after URL matching the given name.  The URL will
// have [unique ID] in between clip name and camera type.
// NB: recording file name must adhere convention [Camera]_[ClipName]_{WC01,WC02,SDI}.
QString HalController::getUrl(const QString& recordingFilename) const
{
  auto parts = recordingFilename.split("_");
  QRegExp rx(QString("%1_%2_[0-9A-Z]{6}_%3\\.mov$").arg(parts[0]).arg(parts[1]).arg(parts[2]));
  QString url;
  
  const int sz = _halFileList.size();
  for (int i = 0; i < sz; ++i) {
    const QJsonValue val = _halFileList[i];
    if (!val.isObject()) {
      qWarning() << "HAL file list doesn't contain objects";
      break;
    }
    
    const auto obj = val.toObject();
    const auto urlString = obj["url"].toString();
    if (rx.indexIn(urlString) >= 0) {
      qDebug() << "matching: " << urlString;
      url = urlString;
      break;
    }
  }
  
  qDebug() << "mapped recording file name " << recordingFilename << " to " << url;
  return url;
}

void HalController::downloadFile(QString recordingFilename)
{
  Q_ASSERT(downloadActive() == !!_downloadFile);
  
  if (downloadActive()) {
    qWarning() << "Cannot start download while another one is active";
    return;
  }
  
  const auto halPath = getUrl(recordingFilename);
  const auto urlPath = QString("/data/") + halPath;
  
  if (halPath.isEmpty()) {
    qWarning() << "cannot map recording file name to physical URL: " << recordingFilename;
    emit downloadFinished(false);
    return;
  }
  
  // XXX: this may overwrite existing files!
  const auto filePath = downloadDirectory() + "/" + recordingFilename + ".mov";
  _downloadFile = new QFile(filePath);
  if (!_downloadFile->open(QFile::ReadWrite)) {
    qWarning() << "downloadFile: failed to open output file: " << filePath;
    delete _downloadFile;
    _downloadFile = nullptr;
    emit downloadFinished(false);
    return;
  }
  
  QUrl url = _baseURL;
  url.setScheme("http");
  url.setPath(urlPath);
  qDebug() << "Downloading file; request: " << url;
  
  QNetworkRequest request(url);
  _networkError = QNetworkReply::NoError;
  _networkReply = _networkAccessManager->get(request);
  _networkReply->setReadBufferSize(16 * 1024 * 1024); // 16MB buffer
  _downloadProgress = 0;
  
  connect(_networkReply, &QNetworkReply::readyRead, this, &HalController::readData);
  connect(_networkReply, &QNetworkReply::downloadProgress, this, &HalController::updateProgress);
  connect(
    _networkReply, static_cast<void(QNetworkReply::*)(QNetworkReply::NetworkError)>(&QNetworkReply::error),
    this, &HalController::finishDownload);
  connect(_networkReply, &QNetworkReply::finished, [this]() { finishDownload(QNetworkReply::NoError); });
  
  emit downloadProgressChanged(_downloadProgress);
  emit downloadActiveChanged(true);
}

void HalController::readData()
{
  Q_ASSERT(downloadActive() == !!_downloadFile);

  auto data = _networkReply->readAll();
  _downloadFile->write(data);
}

void HalController::updateProgress(qint64 bytesReceived, qint64 bytesTotal)
{
  Q_ASSERT(downloadActive() == !!_downloadFile);
  Q_ASSERT(downloadActive());

  float r = 1;
  if (bytesReceived < bytesTotal) {
    r = (float)((double)bytesReceived / bytesTotal);
    if (r == 1) r = 0.98; // don't let it become 1 (rounding errors) unless finished
  }
  _downloadProgress = r;
  emit downloadProgressChanged(r);
}

void HalController::finishDownload(QNetworkReply::NetworkError err)
{
  Q_ASSERT(downloadActive() == !!_downloadFile);
  Q_ASSERT(downloadActive());

  // In case of error, finished() signal may also be delivered after error() signal, so do nothing.
  if (!_networkReply)
    return;
  
  if (err != QNetworkReply::NoError) {
    qWarning() << "Download failed; removing file: " << _downloadFile->fileName();
    _downloadFile->remove();
  }
  else {
    readData();
  }
  
  _networkError = err;
  _networkReply->deleteLater();
  _networkReply = nullptr;
  _downloadFile->close();
  delete _downloadFile;
  _downloadFile = nullptr;
  
  emit downloadActiveChanged(false);
  emit downloadFinished(err == QNetworkReply::NoError);
}

} // labo
