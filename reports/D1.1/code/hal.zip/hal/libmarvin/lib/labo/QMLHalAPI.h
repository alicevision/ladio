// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QObject>
#include <QVariant>
#include <QUrl>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>

class QQmlEngine;
class QJSEngine;
class QFile;

namespace labo
{

//! This is a singleton type; Cutie interacts only with a single HAL at a time.
class HalController : public QObject
{
  Q_OBJECT
  Q_PROPERTY(QUrl url MEMBER _baseURL NOTIFY urlChanged)
  Q_PROPERTY(QString downloadDirectory READ downloadDirectory CONSTANT)
  Q_PROPERTY(float downloadProgress READ downloadProgress NOTIFY downloadProgressChanged)
  Q_PROPERTY(bool downloadActive READ downloadActive NOTIFY downloadActiveChanged)
    
  QString _downloadDirectory;
  QNetworkAccessManager *_networkAccessManager;
  QNetworkReply* _networkReply;
  QUrl _baseURL;
  QFile* _downloadFile;
  float _downloadProgress;
  QNetworkReply::NetworkError _networkError;
  QJsonArray _halFileList;

  QJsonDocument transact(const QString& path, const QUrlQuery& query = QUrlQuery(), bool getMethodOverride = false);
  QString getUrl(const QString& recordingFilename) const;
  static QJsonObject toObject(const QJsonDocument&);
  static QJsonArray toArray(const QJsonDocument&);
  
  
private slots:
  void readData();
  void updateProgress(qint64, qint64);
  void finishDownload(QNetworkReply::NetworkError);
  
signals:
  void urlChanged();
  void downloadProgressChanged(float value);
  void downloadActiveChanged(bool active);
  void downloadFinished(bool isOk);

public:
  static QObject *singletonProviderCB(QQmlEngine*, QJSEngine*);

  HalController(QObject* parent = 0);
  
  QUrl url() { return _baseURL; }
  void setUrl(QUrl url);
  
  QString downloadDirectory() const { return _downloadDirectory; }
  
  Q_INVOKABLE bool recording();
  Q_INVOKABLE void setRecording(bool);
  
  Q_INVOKABLE QVariantMap getSDICameraParameters();
  Q_INVOKABLE void setSDICameraParameters(const QVariantMap&);
  
  Q_INVOKABLE QVariantMap getWitnessCameraParameters(int camera);
  Q_INVOKABLE void setWitnessCameraParameters(int camera, const QVariantMap&);
  
  Q_INVOKABLE void updateHalFileList();
  Q_INVOKABLE void downloadFile(QString recordingFilename);
  float downloadProgress() { return _downloadProgress; }
  bool downloadActive() { return !!_networkReply; }
};

} // labo
