// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <QObject>
#include <QVariantList>
#include <QHostAddress>
#include <QProcess>
#include "DemuxerRPCClient.h"

class QQmlEngine;
class QJSEngine;
class QSettings;

namespace labo
{

class DaneelController : public QObject
{
  Q_OBJECT
  Q_PROPERTY(QVariantList streamList READ streamList NOTIFY streamListChanged)
  Q_PROPERTY(QString cacheDirectory READ cacheDirectory CONSTANT)

  QProcess *_daneelProcess;
  QString _cacheDirectory;
  DaneelRPCClient* _daneelRPCClient;
  QVariantList _streamList;
  
signals:
  void daneelExited();
  void streamListChanged();

public slots:
  void updateStreamList();

public:
  static QObject *singletonProviderCB(QQmlEngine*, QJSEngine*);

  DaneelController(QObject *parent = 0);

  QVariantList streamList() const { return _streamList; }
  QString cacheDirectory() const { return _cacheDirectory; }

  Q_INVOKABLE void start();
  Q_INVOKABLE void playStream(const QString& streamName, int streamPort);
  Q_INVOKABLE bool cachingEnabled();
  Q_INVOKABLE void enableCaching(bool);
};

// Gort doesn't need SDI internal calibration because it uses only WC for localization.
class GortController : public QObject
{
  Q_OBJECT
  Q_PROPERTY(QString calibrationDataDirectory READ calibrationDataDirectory CONSTANT)
  Q_PROPERTY(QString sfmReconstructionFilepath MEMBER _sfmReconstructionFilepath)
  Q_PROPERTY(QString wc1InternalCalibrationFilePath MEMBER _wc1IntCalFilePath)
  Q_PROPERTY(QString wc2InternalCalibrationFilePath MEMBER _wc2IntCalFilePath)
  Q_PROPERTY(QString sdiInternalCalibrationFilePath MEMBER _sdiIntCalFilePath)
  Q_PROPERTY(QString externalCalibrationFilePath MEMBER _extCalFilePath)
  
  QString _calibrationDataDirectory;
  QString _sfmReconstructionFilepath;
  QString _wc1IntCalFilePath;
  QString _wc2IntCalFilePath;
  QString _sdiIntCalFilePath;
  QString _extCalFilePath;
  QProcess *_gortProcess;
  QProcess *_calibrationProcess;
  
  void startGort();
  

public:
  static QObject *singletonProviderCB(QQmlEngine*, QJSEngine*);
  
  GortController(QObject* parent = 0);

  QString calibrationDataDirectory() const { return _calibrationDataDirectory; }
  Q_INVOKABLE void reloadParameters();
};

class CalibrationController : public QObject
{
  Q_OBJECT
  Q_PROPERTY(QString outputFilePath READ outputFilePath WRITE setOutputFilePath)
  
  QString _outputFilePath;
  QProcess *_calibrationProcess;
  
protected:
  void run(const QString& programPath, const QStringList& args);

private slots:
  void processFinished(int, QProcess::ExitStatus);

signals:
  void calibrationFinished(bool isOk);

public:
  CalibrationController(QObject* parent = 0);

  QString outputFilePath() const { return _outputFilePath; }
  void setOutputFilePath(const QString&);
  
};

class IntCalController : public CalibrationController
{
  Q_OBJECT
  Q_PROPERTY(QString videoFilePath MEMBER _videoFilePath)
  Q_PROPERTY(int maxFrames MEMBER _maxFrames)
  Q_PROPERTY(int boardRows MEMBER _boardRows)
  Q_PROPERTY(int boardColumns MEMBER _boardColumns)
  
  QString _videoFilePath;
  int _maxFrames;
  int _boardRows;
  int _boardColumns;
  
public:
  static QObject* singletonProviderCB(QQmlEngine*, QJSEngine*);
  
  IntCalController(QObject* parent = 0);
  Q_INVOKABLE void run();
};

class ExtCalController : public CalibrationController
{
  Q_OBJECT
  Q_PROPERTY(QString sfmReconstructionFilePath MEMBER _sfmReconstructionFilepath)
  Q_PROPERTY(QString sdiVideoFilePath MEMBER _sdiVideoFilePath)
  Q_PROPERTY(QString sdiIntrinsicsFilePath MEMBER _sdiIntrinsicsFilePath)
  Q_PROPERTY(QString wc1VideoFilePath MEMBER _wc1VideoFilePath)
  Q_PROPERTY(QString wc1IntrinsicsFilePath MEMBER _wc1IntrinsicsFilePath)
  Q_PROPERTY(QString wc2VideoFilePath MEMBER _wc2VideoFilePath)
  Q_PROPERTY(QString wc2IntrinsicsFilePath MEMBER _wc2IntrinsicsFilePath)
  Q_PROPERTY(int fps MEMBER _fps)
  
  QString _sfmReconstructionFilepath;
  QString _sdiVideoFilePath;
  QString _sdiIntrinsicsFilePath;
  QString _wc1VideoFilePath;
  QString _wc1IntrinsicsFilePath;
  QString _wc2VideoFilePath;
  QString _wc2IntrinsicsFilePath;
  int _fps;
  
public:
  static QObject* singletonProviderCB(QQmlEngine*, QJSEngine*);

  ExtCalController(QObject* parent = 0);
  Q_INVOKABLE void run();
};

} // labo
