// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <boost/numeric/conversion/cast.hpp>
#include <boost/algorithm/string/replace.hpp>
#include "DemuxerRPCClient.h"
#include "SHMInterface.h"

namespace labo
{

RPCClient::RPCClient(const QString& path, QObject* parent) :
  QObject(parent),
  _requestId(1)
{
  _socket.connectToServer(path);
  if (!_socket.waitForConnected(1000)) {
    qWarning() << "RPCClient: can't connect to server " << path;
    return;
  }
}

bool RPCClient::rpcCallSync(hal::RPCMessage& message)
{
  // Note: for waitForReadyRead, we use a timeout of 5000.
  // We have notice that a timeout of 100 works fine with the witness cameras
  // but is not enough when using the BlackMagic camera.
  try {
    message.set_requestid(_requestId++);
    frameMessage(message, _rpcBytes);

    uint32_t writeSize = boost::numeric_cast<uint32_t>(_rpcBytes.size());
    uint32_t readSize;

    if (boost::numeric_cast<size_t>(_socket.write(&_rpcBytes[0], writeSize)) < writeSize)
      throw std::runtime_error("write to server failed");
    if (!_socket.waitForBytesWritten(10000))
      throw std::runtime_error("write timeout");
    if (!_socket.waitForReadyRead(10000))
      throw std::runtime_error("server timeout (waitForReadyRead init)");
    if (_socket.read(reinterpret_cast<char*>(&readSize), 4) < 4)
      throw std::runtime_error("short read [size]");

    _rpcBytes.resize(readSize);
    readSize = 0;
    
    while (readSize < _rpcBytes.size()) {
      auto bytesAvailable = _socket.bytesAvailable();
      if (!bytesAvailable && !_socket.waitForReadyRead(5000))
        throw std::runtime_error("server timeout (waitForReadyRead)");
      readSize += boost::numeric_cast<uint32_t>(_socket.read(&_rpcBytes[readSize], bytesAvailable));
    }
    
    if (!message.ParseFromString(_rpcBytes))
      throw std::runtime_error("couldn't parse rpc reply");
    if (!message.has_reply())
      throw std::runtime_error("rpc call doesn't contain a reply");
    if (message.reply().has_errordescription())
      throw std::runtime_error(std::string("rpc call returned error: ") + message.reply().errordescription().what());
  }
  catch (boost::numeric::bad_numeric_cast& err) {
    qWarning() << "DemuxerRPCClient: rpc server failed; invalid size";
    return false;
  }
  catch (std::runtime_error& err) {
    qWarning() << "DemuxerRPCClient: rpcCallSync failed: " << err.what() << "; socket error: " << _socket.errorString();
    return false;
  }
  return true;
}

void RPCClient::frameMessage(const hal::RPCMessage& msg, std::string& buffer)
{
  const uint32_t msgSize = boost::numeric_cast<uint32_t>(msg.ByteSize());
  static_assert(sizeof(msgSize) == 4, "invalid size");
  buffer.resize(msgSize + 4);
  memcpy(&buffer[0], &msgSize, 4);
  if (!msg.SerializeToArray(&buffer[4], buffer.size()-4))
    throw std::runtime_error("frameMessage failed");
}

/////////////////////////////////////////////////////////////////////////////

DaneelRPCClient::DaneelRPCClient(QObject* parent) :
  RPCClient("/tmp/LaboDemuxer.C", parent)
{
}

QStringList DaneelRPCClient::listStreams()
{
  QStringList streamList;
  
  if (!_socket.isOpen())
    throw std::logic_error("DemuxerRPCClient: must connect to server");
  
  hal::RPCMessage rpcMessage;
  (void) rpcMessage.mutable_request()->mutable_liststreams(); // create request
  if (!rpcCallSync(rpcMessage) || !rpcMessage.reply().has_liststreams()) {
    qWarning() << "listStreams failed; no sources returned";
    return streamList;
  }
  
  using fptr = const std::string& (hal::ListStreamsMessage_Reply::*)(int) const;
  const auto& reply = rpcMessage.reply().liststreams();
  auto copy = [&streamList, &reply](fptr ptr, int count) {
    for (int i = 0; i < count; ++i)
    {
      std::string url = (reply.*ptr)(i);
      boost::replace_all(url, ".local.", "");
      qInfo() << "DaneelRPCClient::listStreams: " << url.c_str();
      streamList.append(url.c_str());
    }
  };

  copy(&hal::ListStreamsMessage_Reply::halservers, reply.halservers_size());
  copy(&hal::ListStreamsMessage_Reply::daneelservers, reply.daneelservers_size());
  copy(&hal::ListStreamsMessage_Reply::cachedfiles, reply.cachedfiles_size());
  
  return streamList;
}

void DaneelRPCClient::playStream(const std::string& streamName, int streamPort)
{
  hal::RPCMessage rpcMessage;
  rpcMessage.mutable_request()->mutable_playstream()->set_streamname(streamName);
  rpcMessage.mutable_request()->mutable_playstream()->set_streamport(streamPort);
  if (!rpcCallSync(rpcMessage)) {
    qWarning() << "playStream failed; no video will be played";
    return;
  }
}

bool DaneelRPCClient::cachingEnabled()
{
  hal::RPCMessage rpcMessage;
  (void) rpcMessage.mutable_request()->mutable_enablecaching();
  if (!rpcCallSync(rpcMessage))
    qWarning() << "getting recordingEnabled failed";
  return rpcMessage.reply().enablecaching().enabled();
}

void DaneelRPCClient::enableCaching(bool enabled)
{
  hal::RPCMessage rpcMessage;
  rpcMessage.mutable_request()->mutable_enablecaching()->set_enabled(enabled);
  if (!rpcCallSync(rpcMessage))
    qWarning() << "setting recordingEnabled failed (1)";
  if (rpcMessage.reply().enablecaching().enabled() != enabled)
    qWarning() << "setting recordingEnabled failed (2)";
}

/////////////////////////////////////////////////////////////////////////////

DemuxerRPCClient::DemuxerRPCClient(const char *name, int slot, QObject* parent) :
  RPCClient(QString("/tmp/") + name, parent),
  _shm(hal::SHMManager::instance().attach(name, slot)),
  _slot(slot),
  _frameOrd(0),
  _lastpts(0)
{
  if (_slot != hal::SHMManager::RENDER_CLIENT_SLOT && _slot != hal::SHMManager::DISPLAY_CONTROLLER_SLOT)
    throw std::invalid_argument("DemuxerRPCClient: invalid slot");
}

void DemuxerRPCClient::connect(FrameCB frameCB)
{
  if (_frameCB)
    throw std::logic_error("DemuxerRPCClient: already connected");

  hal::RPCMessage rpcMessage;
  rpcMessage.mutable_request()->mutable_connect()->set_slot(_slot);
  if (!rpcCallSync(rpcMessage)) {
    qWarning() << "DemuxerRPCClient: failed to connect to server";
    return;
  }

  _frameOrd = 0;
  _frameCB = frameCB;
  
  QObject::connect(&_socket, &QLocalSocket::readyRead, this, &DemuxerRPCClient::getFrameReadCB);
  getFrame();
}

void DemuxerRPCClient::getFrame()
{
  ++_frameOrd;      // Must increment so that the server notices that there's a fresh request waiting.
  _replySize = 0;   // So that getFrameReadCB knows we're waiting on a new message
  
  hal::RPCMessage message;
  message.mutable_request()->mutable_getframe()->set_ord(_frameOrd);
  message.set_requestid(_requestId++);
  frameMessage(message, _rpcBytes);

  uint32_t writeSize = boost::numeric_cast<uint32_t>(_rpcBytes.size());
  if (boost::numeric_cast<size_t>(_socket.write(&_rpcBytes[0], writeSize)) < writeSize)
    throw std::runtime_error("getFrame: write to server failed");
  if (!_socket.waitForBytesWritten(10))
    throw std::runtime_error("getFrame: write timeout");
  if (_socket.read(reinterpret_cast<char*>(&_replySize), 4) < 0)
    throw std::runtime_error("getFrame: read failed");
}

void DemuxerRPCClient::getFrameReadCB()
{
  if (!_replySize) {
    if (_socket.bytesAvailable() < 4)
      return;
    if (_socket.read(reinterpret_cast<char*>(&_replySize), 4) < 4)
      throw std::runtime_error("short read [metadataSize]");
    _rpcBytes.resize(_replySize);
  }
  
  if (_socket.bytesAvailable() < _replySize)
    return;
  if (_socket.read(&_rpcBytes[0], _replySize) < _replySize)
    throw std::runtime_error("short read [metadata]");

  hal::RPCMessage message;
  if (!message.ParseFromString(_rpcBytes))
    throw std::runtime_error("failed to parse getFrame reply");
  if (!message.has_reply() || !message.reply().has_getframe())
    throw std::runtime_error("invalid reply to getFrame");
  if (message.reply().has_errordescription()) {
    qWarning() << "getFrame failed; no frames will be displayed: " << message.reply().errordescription().what().c_str();
    return;
  }
  
  const auto& frameMetadata = message.reply().getframe().frame();
  int receivedPts = frameMetadata.pts();
  
  if (receivedPts - _lastpts > 1)
    qWarning() << "dropped frames; last pts: " << _lastpts << "; current pts: " << receivedPts;
  
  _frameOrd = frameMetadata.ord();
  _lastpts = receivedPts;
  _frameCB(frameMetadata);
  getFrame();
}

} // labo
