// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <memory>
#include <boost/noncopyable.hpp>
#include <boost/interprocess/offset_ptr.hpp>

namespace hal
{

/*!
 Frame data as provided by SHMInterface.  Defines system parameters (max frame size, etc.)
 */
class FrameDescriptor : private boost::noncopyable
{
  friend class SHMLayout;
  char* init(char* base);
  
public:
  using pointer = boost::interprocess::offset_ptr<char, int64_t, uint64_t>;

  static constexpr size_t maxDecodedSize()  { return 2000 * 2000 * 4; /* RGBA */ }
  static constexpr size_t maxEncodedSize()  { return 1 << 20; }
  static constexpr size_t size() { return maxDecodedSize() + maxEncodedSize(); }
  
  pointer       yuv;        // YUV 420 planar decoded data
  pointer       haldata;    // raw data for frame as received from hal
  uint32_t      halsize;    // size of hal message
};

/////////////////////////////////////////////////////////////////////////////

/*!
 Abstract interface for posting and delivering frame data through SHM. The
 "system name" of the SHM segment is derived from the id provided to getInstance.
 Each video stream must have its own SHM instance.
 
 Each instance supports number of clients; each client gets its own "slot" in
 the SHM area upon attaching.
 
 \warning All methods must be externally synchronized.
 */
class SHMInterface : private boost::noncopyable
{
public:
  using pointer = boost::interprocess::offset_ptr<FrameDescriptor, int64_t, uint64_t>;
  
  //! Destructor; removes the segment iff this instance also created it.
  virtual ~SHMInterface()
  { }
  
  //! Return the full name associated with this interface.
  virtual const char* name() const = 0;
  
  //! Return a reference to the frame descriptor for this client.
  virtual FrameDescriptor& frame() const = 0;
  
  //! Copy data between slots.
  virtual void copy(int dstSlot, int srcSlot) = 0;
};

class SHMManager : private boost::noncopyable
{
  std::vector<std::unique_ptr<SHMInterface>> instances;

public:
  static constexpr int DEMUXER_SLOT = 0;
  static constexpr int DISPLAY_CONTROLLER_SLOT = 1;
  static constexpr int LOCALIZATION_SERVER_SLOT = 2;
  static constexpr int RENDER_CLIENT_SLOT = 3;
  
  static SHMManager& instance();
  
  /*!
   Create the given segment.  If a segment for the same id already exists,
   it will be unlinked first.  The SHM object will be destroyed when the
   returned instance is destroyed (usually, upon program exit).
   \throws std::runtime_error ; not recoverable.
   \warning Not thread safe!
  */
  SHMInterface& create(const char* id);
  
  /*!
   Open the given segment which must already exist.  Slot 0 is reserved for the
   creator of the segment.
   \throws std::runtime_error if the segment doesn't already exist.
  */
  SHMInterface& attach(const char* id, int slot);
  
  /*!
   Unregister an existing instance.  If we created this instance, system
   resources will also be freed.
  */
  void close(SHMInterface&);
};

} // hal
