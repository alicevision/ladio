// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <algorithm>
#include <boost/lexical_cast.hpp>
#include <boost/uuid/uuid_io.hpp>
#include "NetworkIO.h"

using boost::lexical_cast;

namespace hal
{

const boost::uuids::uuid PacketEnvelope::TYPE_UUID[PT_INVALID] = {
  lexical_cast<boost::uuids::uuid>("c07e5a02-8854-11e5-8e00-448a5b9a696f"), // QUIT
  lexical_cast<boost::uuids::uuid>("c07e5d2c-8854-11e5-8e01-448a5b9a696f"), // CONNECT
  lexical_cast<boost::uuids::uuid>("c07e5d2c-8854-11e5-8e02-448a5b9a696f"), // DATA
  lexical_cast<boost::uuids::uuid>("c07e5d2c-8854-11e5-8e03-448a5b9a696f")  // RESEND
};


PacketEnvelope::PayloadType PacketEnvelope::format() const
{
  int i = std::find(TYPE_UUID, TYPE_UUID+PT_INVALID, formatUUID) - TYPE_UUID;
  return i < PT_INVALID ? static_cast<PayloadType>(i) : PT_INVALID;
}

} // hal
