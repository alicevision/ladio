// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <stdexcept>
#include <functional>
#include <array>
#include <list>
#include <memory>
#include "NetworkIO.h"

namespace hal
{

namespace asio = boost::asio;

/*
 Implementation note:
 
 Clients are stored in std::list so that iterators stored in outstanding async
 requests are not invalidated as we register new clients.
*/
class NetworkTransmitter
{
  class ItemCompletionHandler
  {
    NetworkTransmitter& _owner;
    Logger& _logger;
    std::function<void(void)> _handler;
    uint32_t _groupIndex;
    uint16_t _itemIndex;
    
  public:
    ItemCompletionHandler(NetworkTransmitter& owner, std::function<void()> handler,
            uint32_t groupIndex, uint16_t itemIndex) :
      _owner(owner), _logger(_owner._logger), _handler(std::move(handler)), _groupIndex(groupIndex), _itemIndex(itemIndex)
    { }
    
    ~ItemCompletionHandler()
    {
      HAL_LOG(TRACE) << "item completed: (" << _groupIndex << "," << _itemIndex << ')';
      _owner._io.post(std::move(_handler));  // dispatch could throw if it invoked handler directly
    }
  };

  class ClientState : boost::noncopyable
  {
    static constexpr size_t MAX_REREQUEST_COUNT = udp_parameters::MAX_PAYLOAD_SIZE / sizeof(uint32_t);

    NetworkTransmitter& _owner;
    Logger& _logger;
    udp_endpoint _ep;
    std::chrono::steady_clock::time_point _lastSeenTime;
    uint32_t _rerequestedCount;  // set to 0 if no outstanding rerequests
    uint32_t _rerequestedGroup;  // must be checked against current group before each packet is resent
    bool _failed;
    uint32_t _rerequestedPackets[MAX_REREQUEST_COUNT];
    PacketEnvelopePtr _packetToResend;
    
    void resendPackets(unsigned rerequestIndex);
    
  public:
    // We DO want implicit conversion for operator== and find.
    ClientState(NetworkTransmitter& owner, udp_endpoint ep) :
      _owner(owner),
      _logger(_owner._logger),
      _ep(ep),
      _lastSeenTime(std::chrono::steady_clock::now()),
      _rerequestedCount(0),
      _rerequestedGroup(0),
      _failed(false)
    { }
    
    ~ClientState()
    {
      _failed = true;
    }
    
    udp_endpoint ep() const
    {
      return _ep;
    }
    
    bool failed() const
    {
      return _failed;
    }

    void setLastSeenTime(std::chrono::steady_clock::time_point now)
    {
      _lastSeenTime = now;
    }
    
    void setFailOnTimeout(std::chrono::steady_clock::time_point now)
    {
      if (now - _lastSeenTime > udp_parameters::KEEPALIVE_TIMEOUT)
        _failed = true;
    }
    
    void sendItem(std::shared_ptr<ItemCompletionHandler> completionHandler, size_t itemBegin, size_t itemEnd);
    void resendPackets(const PacketEnvelope& requestPacket);
  };
  
  using ClientStatePtr = std::shared_ptr<ClientState>;
  using ClientStateList = std::list<ClientStatePtr>;
  
  const boost::uuids::uuid _sessionUUID;
  Logger _logger;
  asio::io_service& _io;
  const udp_endpoint _interfaceEp;  // used to bind the socket to particular address
  udp_socket _socket;               // used both for sending and receiving
  udp_endpoint _requesterEp;        // client that send the current request
  PacketBuffer _packetBuffer;       // send buffers
  PacketEnvelopePtr _requestPacket; // request contents from client
  size_t _itemBegin, _itemEnd;      // newly enqueued item
  uint32_t _groupIndex;
  uint16_t _itemIndex;
  ClientStateList _clients;
  
  void preparePackets(asio::const_buffer data, bool newGroup);
  void sendItem(std::function<void()> handler);
  void scheduleReceive();
  void processRequest();
  void registerClient(ClientStateList::iterator it, udp_endpoint clientEp);

public:
  //! Thrown by async_enqueue: there is no more place for items in the current group.
  struct buffer_full : virtual boost::exception, virtual std::exception
  { };
  
  NetworkTransmitter(asio::io_service& io, udp_endpoint interfaceEp, size_t maxBufferCapacity /* bytes */);
  ~NetworkTransmitter();
  void async_enqueue(asio::const_buffer data, bool newGroup, std::function<void()> handler);
};


} // hal
