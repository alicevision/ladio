// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <mutex>
#include <boost/numeric/conversion/cast.hpp>
#include "Logger.h"
#include "H264Decoder.h"

namespace hal
{

using asio::mutable_buffer;
using asio::buffer_size;
using asio::buffer_cast;

AVCodec *H264Decoder::codec = nullptr;

/*!
 Create an instance of the class.
 \throws std::runtime_error if a codec cannot be allocated and initialized.
 */
std::unique_ptr<H264Decoder> H264Decoder::create()
{
  static std::mutex mutex;

  std::unique_lock<std::mutex> lock(mutex);
  
  if (!codec) {
    avcodec_register_all();
    if (!(codec = avcodec_find_decoder(AV_CODEC_ID_H264)))
      throw std::runtime_error("H264Decoder: codec not found");
  }
  
  return std::unique_ptr<H264Decoder>(new H264Decoder);
}

static std::string instanceName(void *p)
{
  char tmp[256];
  sprintf(tmp, "H264Decoder@%p", p);
  return tmp;
}

H264Decoder::H264Decoder() :
  _logger(boost::log::keywords::channel = instanceName(this))
{
  av_init_packet(&_packet);
  _context = avcodec_alloc_context3(codec);
  _frame = av_frame_alloc();
  
  if (!_context || !_frame)
    throw std::runtime_error("H264Decoder: failed to allocate context and frame");

  AVDictionary *opts = NULL;
  av_dict_set(&opts, "threads", "2", 0);

  if (avcodec_open2(_context, codec, &opts) < 0)
    throw std::runtime_error("H264Decoder: avcodec_open2");
}

H264Decoder::~H264Decoder()
{
  avcodec_close(_context);
  avcodec_free_context(&_context);
  av_frame_free(&_frame);
  // No need to free the packet as it never owns its data.
}


/*!
 Decode one frame into and convert it to RGBA format, preserving its original dimensions.

 \return true if an image has been decoded.  In that case, width(), height() and
 pixelFormat() methods can be used to retrieve characteristics of the decoded frame.
 \note Decoding is an incremental process, so it is possible for this method to return
 false even if no error occurred.  decode_error is thrown in case of failure.
*/
bool H264Decoder::decode(asio::const_buffer data, asio::mutable_buffer decodedData)
{
  assert(asio::buffer_size(data));

  _packet.size = (int)buffer_size(data);
  _packet.data = const_cast<uint8_t*>(buffer_cast<const uint8_t*>(data));
  int got_picture;

  // We don't know the dimensions of the picture, so use 2k as max.
//  _frame->data[0] = buffer_cast<uint8_t*>(decodedData);
//  _frame->data[1] = _frame->data[0] + 2000 * 2000;
//  _frame->data[2] = _frame->data[1] + 2000 * 2000 / 4;
//
//  _frame->linesize[0] = 1920;
//  _frame->linesize[1] = 1920 / 2;
//  _frame->linesize[2] = 1920 / 2;
  
  if (avcodec_decode_video2(_context, _frame, &got_picture, &_packet) < 0)
    throw decode_error("H264Decoder: avcodec_decode_video2");
  
  if (!got_picture) {
    HAL_LOG(INFO) << "empty frame,skipping.";
    return false;
  }
  
  assert(_frame->pict_type > 0);
  assert(_frame->format == AV_PIX_FMT_YUV420P);

  // width() and height() valid after successfull decode
  
  if (boost::numeric_cast<size_t>(width()*height()*4) > buffer_size(decodedData))
    throw std::runtime_error("H264Decoder: buffer too small");

  memcpy(buffer_cast<uint8_t*>(decodedData), _frame->data[0], _frame->width * _frame->height);
  memcpy(buffer_cast<uint8_t*>(decodedData) + 2000*2000, _frame->data[1], _frame->width * _frame->height / 4);
  memcpy(buffer_cast<uint8_t*>(decodedData) + 2000*2000 + 2000*2000/4, _frame->data[2], _frame->width * _frame->height / 4);
  
  return true;
}

} //hal
