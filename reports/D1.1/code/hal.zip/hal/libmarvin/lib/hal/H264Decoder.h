// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <string>
#include <memory>
#include <boost/asio.hpp>
#include "Logger.h"

extern "C"
{
#include <libavcodec/avcodec.h>
}

namespace hal
{

namespace asio = boost::asio;

/*!
 Encapsulates libav decoder state.
 
 \throws std::runtime_error in case of unrecoverable errors.
 H264Decoder::decode_error in case of recoverable errors.
 
 \note This class is allowed to exist only on the heap because deleting and recreating
 an instance is the most reliable way of restarting the decoder in case of recoverable
 errors.
 */
class H264Decoder
{
  static AVCodec *codec;

private:
  Logger _logger;
  AVCodecContext *_context;
  AVFrame *_frame;
  AVPacket _packet;
  std::string _rgbData;

  H264Decoder();
  
public:
  static std::unique_ptr<H264Decoder> create();
  ~H264Decoder();
  bool decode(asio::const_buffer data, asio::mutable_buffer decodedData);
  int width() const { return _frame->width; }
  int height() const { return _frame->height; }
  enum AVPixelFormat pixelFormat() const { return AV_PIX_FMT_RGBA; }
  
  struct decode_error : std::runtime_error
  {
    explicit decode_error(const std::string &what) : runtime_error(what)
    { }
  };
};

} // hal
