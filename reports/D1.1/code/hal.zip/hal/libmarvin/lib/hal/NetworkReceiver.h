// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once
#include <functional>
#include "NetworkIO.h"
#include "TypedLocalConnection.h"

namespace hal
{

namespace asio = boost::asio;

struct AbstractReceiver
{
  virtual ~AbstractReceiver() { }
  virtual void async_dequeue(PacketSequence& ps, const std::function<void()>& completionHandler) = 0;
};

/*
 Covention in the code: upstream is the producer side; downstream is the consumer side.
 */
class NetworkReceiver : TypedLocalConnection<PacketSequence>, public AbstractReceiver
{
  // initialized by constructor
  Logger _logger;
  const udp_endpoint _serverEp;
  PacketBuffer _packetBuffer;
  udp_socket _socket;
  asio::steady_timer _rerequestTimer;
  asio::steady_timer _reconnectTimer;
  
  // internal signaling
  bool _dequeuePending;
  PacketSequence _dequeuedItem;
  unsigned _itemsProduced;              // within the group
  unsigned _itemsConsumed;              // .. ditto
  PacketEnvelopePtr _newGroupPending;   // packet starting new group if non-null

  // maintained by protocol while receiving packets
  boost::uuids::uuid
              _sessionUUID;
  bool        _rerequestActive;
  uint32_t    _groupIndex;            // determined by sender [incoming packets]
  uint32_t    _lastReceivedPacket;    // ... within current group
  size_t      _gapBegin;              // [0,gapBegin) is contiguous; [gapBegin, gapEnd) is the
  size_t      _gapEnd;                // first missing range of packets.
  size_t      _itemBegin;             // first packet for the item at the front of the queue
  size_t      _itemEnd;               // last packet; read by dequeue
  
  void scheduleConnect();
  void scheduleReceive();
  void processPacket(PacketEnvelopePtr packet);
  void handleNewGroup(PacketEnvelopePtr packet);
  void beginNewGroup(PacketEnvelopePtr packet);
  void moveGap();
  void postCompleteItem();
  void scheduleRerequest();
  
public:
  NetworkReceiver(asio::io_service& io, udp_endpoint serverEp, size_t maxBufferCapacity);
  ~NetworkReceiver();
  void async_dequeue(PacketSequence& ps, const std::function<void()>& completionHandler) override;
};

} // hal
