// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <algorithm>
#include <boost/lexical_cast.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <boost/uuid/nil_generator.hpp>
#include "NetworkReceiver.h"

namespace hal
{

// The unicast protocol requires that client and server use same port for receiving and sending.
NetworkReceiver::NetworkReceiver(
        asio::io_service& io,
        udp_endpoint serverEp,
        size_t maxBufferCapacity) :
  TypedLocalConnection<PacketSequence>(io),
  _logger(boost::log::keywords::channel = 
    std::string("NetworkReceiver:") + boost::lexical_cast<std::string>(serverEp.port())),
  _serverEp(serverEp),
  _packetBuffer(maxBufferCapacity),
  _socket(io, udp_endpoint(asio::ip::address_v4::any(), 0)),
  _rerequestTimer(io),
  _reconnectTimer(io),
  _dequeuePending(false),
  _itemsProduced(0),
  _itemsConsumed(0),
  _newGroupPending(nullptr),
  _sessionUUID(boost::uuids::nil_generator()()),
  _rerequestActive(false),
  _groupIndex(-1)
{
  // socket constructor binds to port for sending data;
  // connect filters incoming traffic to the one host/port.
  _socket.non_blocking(true);
  _socket.connect(_serverEp);
  scheduleConnect();
  scheduleReceive();
  HAL_LOG(INFO) << "started; connected to server " << _serverEp;
}

NetworkReceiver::~NetworkReceiver()
{
  HAL_LOG(INFO) << "stopped.";
}

void NetworkReceiver::async_dequeue(PacketSequence& ps, const std::function<void()>& completionHandler)
{
  if (_dequeuePending)
    throw std::logic_error("cannot have multiple pending dequeues");

  _dequeuePending = true;
  
  downstream().async_receive(ps, [this, completionHandler, &ps]() {
    if (!_dequeuePending)
      throw std::logic_error("dequeuePending false in async_dequeue handler");
    _dequeuePending = false;
    auto psCopy = ps;     // handler may modify the ps it sent in to async_dequeue; we must send identical back
    completionHandler();
    downstream().send(psCopy);
  });
}

void NetworkReceiver::scheduleConnect()
{
  _reconnectTimer.expires_from_now(udp_parameters::CONNECT_INTERVAL);
  _reconnectTimer.async_wait([this](const boost::system::error_code& ec) {
    if (ec)
      throw boost::enable_error_info(boost::system::system_error(ec,
        "NetworkReceiver::scheduleConnect: timer failed")) << exception_source(this);
    scheduleConnect();
  });
  
  auto packet = _packetBuffer.allocate();
  packet->formatUUID = PacketEnvelope::TYPE_UUID[PacketEnvelope::PT_CONNECT];
  packet->groupIndex = 0;
  packet->payloadSize = 0;
  
  _socket.async_send(packet->io_buffer(),
    [this,packet](const boost::system::error_code& ec, size_t nwritten) {
      _packetBuffer.free(packet);
      if (ec || nwritten != sizeof(PacketEnvelope))
        HAL_LOG(WARNING) << "sending connect packet failed: " <<
          (ec ? ec.message() : "short write");
  });
}

void NetworkReceiver::scheduleReceive()
{
  auto packet = _packetBuffer.allocate();
  _socket.async_receive(packet->io_buffer(),
    [this,packet](const boost::system::error_code &ec, size_t nread) {
      HAL_LOG(DISABLED) << "packet received: (" << packet->groupIndex << "," << packet->packetWithinGroup << ")";
      
      // Note: async_receive will fail with connection refused if there's a prior send and the socket is "connected"
      // http://stackoverflow.com/questions/2372371/error-receiving-in-udp-connection-refused
      if (ec) {
        _packetBuffer.free(packet);
        if (ec == boost::system::errc::connection_refused) {
          scheduleReceive();
          return;
        }
        throw boost::enable_error_info(boost::system::system_error(ec,
          "NetworkReceiver::scheduleReceive: async_receive")) << exception_source(this);
      }
      if (nread != sizeof(PacketEnvelope)) {
        HAL_LOG(WARNING) << "ignoring packet of invalid size: " << nread;
        _packetBuffer.free(packet);
        scheduleReceive();
        return;
      }
      if (packet->format() != PacketEnvelope::PT_DATA) {
        HAL_LOG(WARNING) << "invalid packet format received; ignoring.";
        _packetBuffer.free(packet);
        scheduleReceive();
        return;
      }
      if (packet->groupIndex & 0x80000000) {
        _packetBuffer.free(packet);
        throw boost::enable_error_info(std::runtime_error("group index overflowed")) << exception_source(this);
      }
      
      // Checks passed; normal packet/group processing will schedule receive/rerequest when appropriate.
      // Order of comparison is important for performance reasons.
      if (packet->groupIndex != _groupIndex || packet->sessionUUID != _sessionUUID)
        handleNewGroup(packet);
      else
        processPacket(packet);
    });
}

// NB! We assume that groupIndex will never decrease during the lifetime of NetworkReceiver.
// This is true as long as HAL is not restarted (normally not the case).
void NetworkReceiver::processPacket(PacketEnvelopePtr packet)
{
  assert(packet->groupIndex == _groupIndex);
  
  // TODO: should reschedule timer, so that the timeout is relative to the last received gap packet??
  
  // Past packets get ignored.
  if (packet->packetWithinGroup < _gapBegin) {
    HAL_LOG(TRACE) << "duplicate packet; index within group: " << packet->packetWithinGroup;
    _packetBuffer.free(packet);
    scheduleReceive();
    return;
  }

  _packetBuffer.replace_free(packet->packetWithinGroup, packet);
  assert(_packetBuffer[packet->packetWithinGroup] == packet);
  
  if (packet->packetWithinGroup < _gapEnd)
    HAL_LOG(DISABLED) << "gap packet " << "(" << packet->groupIndex << "," << packet->packetWithinGroup << ")";
  
  _lastReceivedPacket = std::max(_lastReceivedPacket, packet->packetWithinGroup);
  moveGap();
  scheduleReceive();
  scheduleRerequest();
}

// New group can begin only if the consumer has finished with all previous items.
// Otherwise, we have to postpone new group handling and wait for being invoked
// from acknowledge callback (set up in postCompleteItem).
// handleNewGroup won't schedule any new receives until the consumer has emptied
// the current group.
void NetworkReceiver::handleNewGroup(PacketEnvelopePtr packet)
{
  assert(packet->groupIndex != _groupIndex || packet->sessionUUID != _sessionUUID);
  assert((_groupIndex == uint32_t(-1)) == _sessionUUID.is_nil());

  if (packet->sessionUUID != _sessionUUID) {
    _sessionUUID = packet->sessionUUID;
    HAL_LOG(INFO) << "detected new session: " << _sessionUUID << "; first group: " << packet->groupIndex;
  } 
  else if (packet->groupIndex < _groupIndex) {
    HAL_LOG(WARNING) << "discarding delayed packet; group " << packet->groupIndex << "; current group: " << _groupIndex;
    _packetBuffer.free(packet);
    scheduleReceive();
    return;
  }
  else {
    HAL_LOG(TRACE) << "detected new group: " << packet->groupIndex;
  }
  
  if (!_newGroupPending) {
    assert(_itemsProduced >= _itemsConsumed);
    if (_itemsProduced == _itemsConsumed) {
      beginNewGroup(packet);
    }
    else {
      HAL_LOG(DEBUG) << "waiting to start new group: " << packet->groupIndex
        << "; # of unconsumed items: " << _itemsProduced - _itemsConsumed;
      _newGroupPending = packet;
    }
  }
  else if (packet == _newGroupPending) {
    // XXX: what if _newGroupPending->_sessionUUID != _sessionUUID ??
    assert(_itemsProduced == _itemsConsumed);
    beginNewGroup(_newGroupPending);
    _newGroupPending = nullptr;
  }
  else {
    HAL_LOG(TRACE) << "new group packet ignored while waiting for consumer: ("
      << packet->groupIndex << "," << packet->packetWithinGroup << ")";
    _packetBuffer.free(packet);
  }
}

// Really begin new group.
void NetworkReceiver::beginNewGroup(PacketEnvelopePtr packet)
{
  HAL_LOG(TRACE) << "begin new group: " << packet->groupIndex;
  
  _packetBuffer.replace_free(packet->packetWithinGroup, packet);
  assert(_packetBuffer[packet->packetWithinGroup] == packet);

  _rerequestTimer.cancel();
  
  _itemBegin = 0;
  _itemEnd = 0;              // items begin at packet#0
  _itemsProduced = 0;
  _itemsConsumed = 0;

  // update group tracking data
  if (!packet->packetWithinGroup) { // yay! got the very first packet in the group?
    _gapBegin = 1;
    _gapEnd = 1;
  } else {                          // nay, we got a hole at the beginning
    _gapBegin = 0;
    _gapEnd = packet->packetWithinGroup;
  }

  _groupIndex = packet->groupIndex;
  _lastReceivedPacket = packet->packetWithinGroup;

  scheduleReceive();
  scheduleRerequest();
}

void NetworkReceiver::moveGap()
{
  
  // Packet falls within the current gap.
  
  // Potentially contiguous until the last received packet.
  for (; _gapBegin <= _lastReceivedPacket; ++_gapBegin) {
    if (_packetBuffer[_gapBegin]->groupIndex != _groupIndex)
      break;
    if (_packetBuffer[_gapBegin]->itemWithinGroup & 0x8000)
      postCompleteItem();
  }

  // XXX: this for should probably inside the above!  Verify!!!
  for (_gapEnd = _gapBegin; _gapEnd <= _lastReceivedPacket; ++_gapEnd)
    if (_packetBuffer[_gapEnd]->groupIndex == _groupIndex)
      break;

  // [gapBegin, gapEnd) is now the new interval of missing packets.
  assert(std::all_of(_packetBuffer.begin() + _gapBegin, _packetBuffer.begin() + _gapEnd,
    [this](const PacketEnvelopePtr &pe) { return pe->groupIndex != _groupIndex; } ));
}

void NetworkReceiver::postCompleteItem()
{
  assert(_itemBegin == _itemEnd);
  
  while (!(_packetBuffer[_itemEnd]->itemWithinGroup & 0x8000))
    if (++_itemEnd > _lastReceivedPacket)
      throw std::logic_error("end packet for item not found");

  const auto groupIndex = _groupIndex;
  const auto itemIndex = _packetBuffer[_itemBegin]->itemWithinGroup;
  
  HAL_LOG(DISABLED) << "item: (" << groupIndex << "," << itemIndex << ")";
  
  PacketSequence ps(&_packetBuffer, _itemBegin, ++_itemEnd, groupIndex, itemIndex);
  _itemBegin = _itemEnd;

  upstream().send(ps);
  ++_itemsProduced;
  HAL_LOG(TRACE) << "item delivered: " << ps << "; size: " << asio::buffer_size(ps);

  upstream().async_receive(_dequeuedItem, [this]() {
    HAL_LOG(TRACE) << "item released: " << _dequeuedItem;
    ++_itemsConsumed;
    if (_itemsConsumed > _itemsProduced)
      throw std::logic_error("causality error; consumed > produced");
    if (_itemsConsumed == _itemsProduced && _newGroupPending) {
      HAL_LOG(DEBUG) << "all items consumed; scheduling new group: " << _newGroupPending->groupIndex;
      handleNewGroup(_newGroupPending);
    }
  });
}

// Rerequest missing packets within the first gap.
void NetworkReceiver::scheduleRerequest()
{
  static constexpr size_t indexesPerPacket = udp_parameters::MAX_PAYLOAD_SIZE / sizeof(uint32_t);

  assert(_gapBegin <= _gapEnd);
  size_t gapLength = _gapEnd - _gapBegin;
  if (_rerequestActive || !gapLength)
    return;
  
  HAL_LOG(TRACE) << "rerequesting gap; group: " << _groupIndex << "; interval: [" << _gapBegin << ":" << _gapEnd << ")";

  _rerequestActive = true;
  _rerequestTimer.expires_from_now(udp_parameters::REREQUEST_INTERVAL);
  _rerequestTimer.async_wait([this](const boost::system::error_code &ec) {
    _rerequestActive = false;
    if (ec == boost::asio::error::operation_aborted)
      return;
    scheduleRerequest();
  });

  size_t rerequestIndex = _gapBegin;
  
  while (gapLength) {
    size_t thisPacketCount = std::min(indexesPerPacket, gapLength);
    gapLength -= thisPacketCount;

    auto ioPacket = _packetBuffer.allocate();
    ioPacket->formatUUID = PacketEnvelope::TYPE_UUID[PacketEnvelope::PT_RESEND];
    ioPacket->groupIndex = _groupIndex;
    ioPacket->payloadSize = 0;
    
    uint32_t *buf = reinterpret_cast<uint32_t*>(ioPacket->payload);
    for (; thisPacketCount--; ++rerequestIndex)
      if (_packetBuffer[rerequestIndex]->groupIndex != _groupIndex) {
        *buf++ = rerequestIndex;
        ioPacket->payloadSize += sizeof(uint32_t);
      }
    
    _socket.async_send(ioPacket->io_buffer(),
      [=](const boost::system::error_code &ec, size_t nwritten) {
        _packetBuffer.free(ioPacket);
        if (ec || nwritten != sizeof(PacketEnvelope))
          HAL_LOG(WARNING) << "Failed to rerequest packets for group " << _groupIndex
            << ":" << (ec ? ec.message() : "short write");
      });
  }
  assert(rerequestIndex == _gapEnd);
}

} // hal

