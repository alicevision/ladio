// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once
#include <memory>
#include <stdexcept>
#include <boost/log/common.hpp>

namespace hal
{

enum severity_level {
  DISABLED = -1, TRACE, DEBUG, INFO, WARNING, ERROR
};
using Logger = boost::log::sources::severity_channel_logger_mt<severity_level>;
Logger& get_global_logger();

struct logger_deleter
{
  void operator()(boost::shared_ptr<Logger>*) const;
};

using LoggerInstance = std::unique_ptr<boost::shared_ptr<Logger>, logger_deleter>;

LoggerInstance startLogger(bool use_journal, const char* global_logger_channel_name);
void setLogLevel(severity_level level);
void setLogFilter(const char* filterText);

} // hal

// For compatibility with main hal code.
using hal_logger_t = hal::Logger;

// Macros are unaffected by namespaces anyway
#define HAL_LOG(sev) BOOST_LOG_SEV(_logger, sev)
#define HAL_GLOBAL_LOG(sev) BOOST_LOG_SEV(get_global_logger(), sev)
