// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

/*! \file
 TCtime utilities: conversion to tuple (provides lex comparisons) and string.
 */

namespace hal
{

inline std::tuple<short, short, short, short> to_tuple(const TCTime& t)
{
  return std::make_tuple(t.hour(), t.minute(), t.second(), t.frame());
}

inline std::string to_string(const TCTime& t)
{
  using std::to_string;
  return to_string(t.hour()) + ":" + to_string(t.minute()) + ":" + to_string(t.second()) +
    "." + to_string(t.frame());
}

}
