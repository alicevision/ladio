// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
/*! \file Implementation of partially reliable protocol on top of UDP.  Incoming
 * data is divided into groups and the receiver can request a retransmit of a
 * particular packet as long as the sender has not begun a new group.
 */

#pragma once

#include <stddef.h>
#include <thread>
#include <vector>
#include <chrono>
#include <iostream>
#include <memory>
#include <boost/asio.hpp>
#include <boost/asio/steady_timer.hpp>
#include <boost/uuid/uuid.hpp>
#include <boost/noncopyable.hpp>
#include <boost/exception/all.hpp>
#include <boost/iterator/indirect_iterator.hpp>
#include "Logger.h"

namespace hal
{

namespace asio = boost::asio;

using udp_endpoint = asio::ip::udp::endpoint;
using udp_socket = asio::ip::udp::socket;

//! Network protocol parameters.
namespace udp_parameters
{
//! Interval between missing packets have been requested and rerequesting them again.
const std::chrono::milliseconds REREQUEST_INTERVAL(12);

//! Transmitter will stop sending data to the client if it hasn't received keepalive within this time period.
const std::chrono::seconds KEEPALIVE_TIMEOUT(10);

//! Receivers send "connect" (keepalive) messages with this period.
const std::chrono::seconds CONNECT_INTERVAL(2);

//! Recommended buffer capacity for NetworkReceiver and NetworkTransmitter.
//! Must be large enough for one complete group of items.
constexpr size_t BUFFER_SIZE = 64 << 20;

//! Max payload size in single UDP packet.
constexpr size_t MAX_PAYLOAD_SIZE = 768;

// Stream ports for "original" (not retransmitted) streams.
constexpr int WC01_PORT = 5001;
constexpr int WC02_PORT = 5002;
constexpr int SDI_PORT = 5003;
}

//! On some occasions we need to know which instance of Transmitter/Receiver threw.
using exception_source = boost::error_info<struct tag_exception_source, void*>;

/*!
 All packets exchanged between receiver and transmitter are enveloped in this
 structure and have the same size.
 \note The class is implicitly convertible to asio::mutable_buffer; however
 the returned buffer represents ONLY the payload part.
*/
class PacketEnvelope : boost::noncopyable
{
  PacketEnvelope() = default;
  
  friend std::shared_ptr<PacketEnvelope> std::make_shared<PacketEnvelope>();
  
public:
  static std::shared_ptr<PacketEnvelope> make()
  {
    // make_shared cannot access private constructors
    class make_shared_enabler : public PacketEnvelope { };
    return std::make_shared<make_shared_enabler>();
  }
  
  //! The only permissible payload types in the system.
  enum PayloadType
  {
    PT_QUIT,      // internal message: signals the thread to quit; currently unused
    PT_CONNECT,   // register new client to send data to
    PT_DATA,      // stream data
    PT_RESEND,    // sent by receiver; interpreted by sender
    PT_INVALID    // unrecognized UUID
  };

  static const boost::uuids::uuid TYPE_UUID[PT_INVALID];

  boost::uuids::uuid
            formatUUID,         // identifies payload type and version
            sessionUUID;        // unique for each transmitter instance
  uint32_t  groupIndex;         // monotonically increasing
  uint32_t  packetWithinGroup;  // starts at 0 within each group...
  uint16_t  itemWithinGroup;    // ...ditto; or'd with 0x8000 for last packet for this item
  uint16_t  payloadSize;        // payload size
  uint16_t  reserved[2];        // padding
  uint8_t   payload[udp_parameters::MAX_PAYLOAD_SIZE];
  
  //! Returns a buffer sequence representing the whole buffer (header + payload)
  asio::mutable_buffers_1 io_buffer() const
  {
    constexpr size_t envelopeSize = offsetof(PacketEnvelope, payload);
    static_assert(envelopeSize == 2*16 + 2*4 + 4*2, "layout not packed");
    static_assert(envelopeSize + sizeof(payload) == sizeof(PacketEnvelope), "layout not packed");
    return asio::buffer(const_cast<PacketEnvelope*>(this), sizeof(*this));
  }

  /*! Validate packet contents and return the result.
   \note This method is slow-ish, so callers should cache the result.
   */
  PayloadType format() const;
  
  //! Returns a mutable_buffer representing the payload buffer.
  operator asio::mutable_buffer() const
  {
    return asio::mutable_buffer(const_cast<uint8_t*>(payload), payloadSize);
  }
};

//! Packet envelopes are handled only via shared pointers.
using PacketEnvelopePtr = std::shared_ptr<PacketEnvelope>;

/*!
 * Contains an array of PacketEnvelope instances, up to a given maximum payload capacity.
 * \todo Make an iterator class based on indexes.  Intermittent reallocations of buffer
 * wouldn't disrupt anything because indexes are stable.
 */
class PacketBuffer : private std::vector<PacketEnvelopePtr>
{
  using Storage = std::vector<PacketEnvelopePtr>;
public:
  // Expose methods inherited from storage implementation
  using Storage::operator[];
  using Storage::iterator;
  using Storage::const_iterator;
  using Storage::size;
  using Storage::begin;
  using Storage::end;
    
  /*!
   Constructor allocates double size to account for packets with little payload.
   Fills the buffer with invalid data so that we know from first iteration which
   packets belong to the current synchronization group.
  */
  PacketBuffer(size_t maxCapacity) :
    Storage(2*maxCapacity / udp_parameters::MAX_PAYLOAD_SIZE)
  {
    for (size_t i = 0; i < size(); ++i) {
      auto pe = PacketEnvelope::make();
      pe->groupIndex = 0xFFFFFF8D;
      pe->packetWithinGroup = -1;
      (*this)[i] = std::move(pe);
    }
  }

  PacketEnvelopePtr allocate()
  {
    auto pe(back());
    pop_back();
    return pe;
  }
  
  void free(PacketEnvelopePtr p)
  {
    push_back(p);
  }
  
  void replace_free(size_t freed, PacketEnvelopePtr replacement)
  {
    std::swap(at(freed), replacement);
    push_back(replacement);
  }
};

//! Implements MutableBufferSequence for asio.
class PacketSequence
{
  friend class PacketBuffer;
  PacketBuffer* _owner;
  size_t _begin, _end;

public:
  using value_type = PacketEnvelope;
  using const_iterator = boost::indirect_iterator<PacketBuffer::const_iterator>;
  
  // Metadata for debugging; does not participate in value semantics.
  uint32_t groupIndex;
  uint16_t itemIndex;

  PacketSequence() : _owner(nullptr), _begin(0), _end(0)
  { }

  // No constructor to make it a POD.
  PacketSequence(PacketBuffer* owner, size_t begin, size_t end, uint32_t groupIndex, uint16_t itemIndex) :
    _owner(owner), _begin(begin), _end(end), groupIndex(groupIndex), itemIndex(itemIndex)
  {
    assert(begin <= owner->size() && end <= owner->size());
  }

  const_iterator begin() const
  {
    assert(_begin <= _owner->size());
    return const_iterator(_owner->begin() + _begin);
  }

  const_iterator end() const
  {
    assert(_end <= _owner->size());
    return const_iterator(_owner->begin() + _end);
  }

  bool empty() const
  {
    return _begin == _end;
  }

  bool operator==(const PacketSequence& other) const
  {
    if (_owner != other._owner)
      throw std::logic_error("PacketSequence::operator==: different owners");
    return _begin == other._begin && _end == other._end;
  }

  bool operator!=(const PacketSequence& other) const
  {
    return !(*this == other);
  }
  
  friend std::ostream& operator<<(std::ostream& os, const PacketSequence& ps)
  {
    os << "PacketSequence(" << ps.groupIndex << "," << ps.itemIndex << ")";
    return os;
  }
};
} // hal
