// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <fstream>
#include <boost/archive/xml_oarchive.hpp>
#include <boost/archive/xml_iarchive.hpp>
#include "HalFrame.pb.h"
#include "TrackingCache.h"

namespace hal
{
namespace tracking_cache
{

void TrackingLog::addFrame(const FrameMetadata& frameMetadata)
{
  const LocalizationInfo& locInfo = frameMetadata.localization();
  
  // Precondition
  if (locInfo.glrotationmatrix_size() != 9 || locInfo.gltranslation_size() != 3 || locInfo.mayacameramatrix_size() != 16)
    throw std::logic_error("TrackingLog: invalid rotation/translation/mayacameramatrix size");

  if (!_hasDate) {
    date.year = frameMetadata.date().year();
    date.month = frameMetadata.date().month();
    date.day = frameMetadata.date().day();
    _hasDate = true;
  }
  
  if (!_hasIntrinsics) {
    for (int i = 0; i < locInfo.mvgintrinsics_size(); ++i)
      intrinsics.push_back(locInfo.mvgintrinsics(i));
    _hasIntrinsics = true;
  }

  frameWidth = frameMetadata.width();
  frameHeight = frameMetadata.height();
  
  frames.push_back(FrameTrackingInfo());
  auto& fti = frames.back();
  
  fti.time.hour = locInfo.time().hour();
  fti.time.minute = locInfo.time().minute();
  fti.time.second = locInfo.time().second();
  fti.time.frame = locInfo.time().frame();
  fti.time.subframe = 0;
  
  for (int i = 0; i < locInfo.tags_size(); ++i) {
    const auto& tag = locInfo.tags(i);
    fti.tags.push_back(CCTag{tag.id(), tag.x(), tag.y()});
  }
  
  for (int i = 0; i < 9; ++i)
    fti.glRotation[i] = locInfo.glrotationmatrix(i);
  for (int i = 0; i < 3; ++i)
    fti.glTranslation[i] = locInfo.gltranslation(i);
  for (int i = 0; i < 16; ++i)
    fti.mayaCameraMatrix[i] = locInfo.mayacameramatrix(i);
}

void TrackingLog::save(const std::string& filename, TrackingLog& tl)
{
  std::ofstream ofs(filename);
  boost::archive::xml_oarchive oa(ofs);
  oa << boost::serialization::make_nvp("TrackingLog", tl);
}

TrackingLog TrackingLog::load(const std::string& filename)
{
  TrackingLog tl;
  std::ifstream ifs(filename);
  boost::archive::xml_iarchive ia(ifs);
  ia >> boost::serialization::make_nvp("TrackingLog", tl);
  return tl;
}


} // tracking_cache
} // hal
