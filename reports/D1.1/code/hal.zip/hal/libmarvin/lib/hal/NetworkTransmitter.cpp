// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <algorithm>
#include <boost/lexical_cast.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <boost/uuid/random_generator.hpp>
#include <time.h>
#include "NetworkTransmitter.h"

namespace hal
{

void NetworkTransmitter::ClientState::sendItem(std::shared_ptr<ItemCompletionHandler> completionHandler, size_t itemBegin, size_t itemEnd)
{
  assert(itemBegin <= itemEnd);
  
  if (itemBegin == itemEnd || _failed)
    return;

  _owner._socket.async_send_to(_owner._packetBuffer[itemBegin]->io_buffer(), _ep,
    [=](const boost::system::error_code& ec, size_t nwritten) {
      if (ec || nwritten < sizeof(PacketEnvelope)) {
        HAL_LOG(ERROR) << "write failed; client: " << _ep << "; reason: " << (ec ? ec.message() : "short write");
        _failed = true;
      }
      //HAL_LOG(DISABLED) << "sent packet " << "(" << groupIndex << "," << itemIndex << ")";
      sendItem(completionHandler, itemBegin+1, itemEnd);
    });
    
  // Execute at most one handler after having sent one packet; hopefully this will process rerequests earlier than usual.
  _owner._io.poll_one();  
  
  // Since each packet is ~800 bytes; delay of 0.2ms rate-limits sending to ~40Mbps.
  // XXX: Maybe we don't need rate-limiting since only a completed async send will
  // trigger sending of the next packet.
  // XXX: this would slow down event loop. A proper solution for timeout is a timer
  // which, when it fires, it schedules next packet send.
  //struct timespec ts = { 0, 200000 };
  //nanosleep(&ts, 0);
}

// Resend is fully asynchronous and best-effort, so we don't need completion notification.
void NetworkTransmitter::ClientState::resendPackets(const PacketEnvelope& requestPacket)
{
  HAL_LOG(TRACE) << "resend requested; client: " << _ep << "; group: "
    << requestPacket.groupIndex << "; current group: " << _owner._groupIndex;
  if (requestPacket.groupIndex != _owner._groupIndex)
    return;
  if (requestPacket.payloadSize % 4) {
    HAL_LOG(ERROR) << "invalid payload size in PT_RESEND; client: " << _ep;
    return;
  }
  if (_rerequestedCount) {
    HAL_LOG(DEBUG) << "resend discarded because another one is active; client: " << _ep;
    return;
  }
  
  // WARNING! _requestPacket is reused on each call to scheduleReceive, so we must copy out
  // indices AND their group before starting asynchronous transfer of these packets.
  
  _rerequestedCount = requestPacket.payloadSize / 4;
  _rerequestedGroup = _owner._groupIndex;
  
  if (_rerequestedCount > MAX_REREQUEST_COUNT)
    throw std::logic_error("resendPackets: count too large");
  
  const uint32_t *indexList = reinterpret_cast<const uint32_t*>(requestPacket.payload);
  std::copy(indexList, indexList + _rerequestedCount, _rerequestedPackets);
  resendPackets(0);
}

void NetworkTransmitter::ClientState::resendPackets(unsigned rerequestIndex)
{
  if (rerequestIndex >= _rerequestedCount || _rerequestedGroup != _owner._groupIndex || _failed) {
    HAL_LOG(TRACE) << "resend complete; client: " << _ep << (_failed ? "; FAILED" : "");
    _rerequestedCount = 0;
    return;
  }
  
  const auto packetIndex = _rerequestedPackets[rerequestIndex];
  if (packetIndex >= _owner._packetBuffer.size()) {
    HAL_LOG(ERROR) << "invalid packet index requested; aborting resend; client: " << _ep;
    _rerequestedCount = 0;
    return;
  }

  // This increases envelope's reference count; async_enqueue must take care not to
  // overwrite packets with refcount > 1 but allocate new ones.
  _packetToResend = _owner._packetBuffer[packetIndex];
  _owner._socket.async_send_to(_packetToResend->io_buffer(), _ep,
    [=](const boost::system::error_code& ec, size_t nwritten) {
      if (ec || nwritten != sizeof(PacketEnvelope))
        return;
      HAL_LOG(TRACE) << "resent packet: (" << _rerequestedGroup << "," << packetIndex << ")";
      resendPackets(rerequestIndex+1);
    });
}

/////////////////////////////////////////////////////////////////////////////

/*!
 Sets up transmitter to bind to the provided interface endpoint for sending.
 Packets will be sent to the send endpoint (may be unicast, multicast or
 broadcast address).
 Throws if setup fails.
*/
NetworkTransmitter::NetworkTransmitter(asio::io_service& io, udp_endpoint interfaceEp, size_t maxBufferCapacity) :
  _sessionUUID(boost::uuids::random_generator()()),
  _logger(boost::log::keywords::channel =
    std::string("NetworkTransmitter:") + boost::lexical_cast<std::string>(interfaceEp.port())),
  _io(io),
  _interfaceEp(interfaceEp),
  _socket(_io, _interfaceEp), // this constructor bind()s to address+port
  _packetBuffer(maxBufferCapacity),
  _requestPacket(PacketEnvelope::make()),
  _itemBegin(0),
  _itemEnd(0),
  _groupIndex(-1),
  _itemIndex(-1)
{
  _socket.non_blocking(true); // we use also potentially blocking calls
  scheduleReceive();
  HAL_LOG(INFO) << "started.";
}

NetworkTransmitter::~NetworkTransmitter()
{
  HAL_LOG(INFO) << "stopped.";
}

/*!
 Allocates enough packets to accomodate size bytes.  Allocation assumes that each
 packet will be filled to its max capacity before going to the next one.
 
 \note When a new group is started, all pending sends for the current group are aborted.
 
 \throws std::invalid_argument and std::logic_error.
*/
void NetworkTransmitter::async_enqueue(asio::const_buffer data, bool newGroup, std::function<void()> handler)
{
  const size_t size = asio::buffer_size(data);
  
  if (_groupIndex == uint32_t(-1) && !newGroup)
    throw std::logic_error("very first enqueue must start a new group");
  if (_io.stopped())
    throw std::logic_error("cannot enqueue unless running");
  if (!size)
    throw std::invalid_argument("enqueue: zero size");  // packetCount is invalid now

  _io.dispatch([=]() {
    preparePackets(data, newGroup);
    sendItem(std::move(handler));
  });
  
  HAL_LOG(TRACE) << "item enqueued: (" << _groupIndex << "," << _itemIndex << ")";
}

// BULK SEND ////////////////////////////////////////////////////////////////

void NetworkTransmitter::preparePackets(asio::const_buffer data, bool newGroup)
{
  auto size = asio::buffer_size(data);
  const auto packetCount = (size-1) / udp_parameters::MAX_PAYLOAD_SIZE + 1;
  
  if (newGroup) {
    ++_groupIndex;
    _itemIndex = 0;
    _itemBegin = 0;
    _itemEnd = packetCount;
    HAL_LOG(TRACE) << "begin new group: " << _groupIndex;
  }
  else {
    ++_itemIndex;
    _itemBegin = _itemEnd;
    _itemEnd += packetCount;
  }
  
  if (_groupIndex & 0x80000000)
    throw boost::enable_error_info(std::runtime_error("group index overflow"))
      << exception_source(this);
  
  if (_itemEnd > _packetBuffer.size())
    throw buffer_full() << exception_source(this);

  // Initialize envelopes in the range.  Take care not to overwrite packets
  // referenced by clients for resend.
  for (size_t i = _itemBegin; i < _itemEnd; ++i) {
    if (newGroup && !_packetBuffer[i].unique())
      _packetBuffer[i] = PacketEnvelope::make();
    auto& packet = _packetBuffer[i];
    packet->formatUUID = PacketEnvelope::TYPE_UUID[PacketEnvelope::PT_DATA];
    packet->sessionUUID = _sessionUUID;
    packet->groupIndex = _groupIndex;
    packet->packetWithinGroup = i;
    packet->itemWithinGroup = _itemIndex;
    packet->payloadSize = std::min(udp_parameters::MAX_PAYLOAD_SIZE, size);
    size -= packet->payloadSize;
  }
  assert(size == 0);
  
  // Mark last item packet as such.
  _packetBuffer[_itemEnd-1]->itemWithinGroup |= 0x8000;
  
  // Copy buffer data.
  PacketSequence ps(&_packetBuffer, _itemBegin, _itemEnd, _groupIndex, _itemIndex);
  asio::buffer_copy(ps, data);
}

void NetworkTransmitter::sendItem(std::function<void()> handler)
{
  using namespace std::chrono;
  const auto now = steady_clock::now();
  
  // Erase failed clients.  They are managed by shared_ptr, so they're safe to erase
  // from here, even if there are outstanding send calls to the erased ones.  Must
  // first compute timed out clients.
  // NB: remove_if leaves removed elements with unspecified content!
  std::for_each(_clients.begin(), _clients.end(), [this,now](const ClientStatePtr& client) {
    client->setFailOnTimeout(now);
    if (client->failed())
      HAL_LOG(INFO) << "Removing failed/timed out client: " << client->ep();
  });
  
  auto failedBegin = std::remove_if(_clients.begin(), _clients.end(),
    [](const ClientStatePtr& client) { return client->failed(); });
  _clients.erase(failedBegin, _clients.end());
  
  // Completion handler must be referenced by all clients.
  auto completionHandler = std::make_shared<ItemCompletionHandler>(*this, std::move(handler), _groupIndex, _itemIndex);
  std::for_each(_clients.begin(), _clients.end(), [=](ClientStatePtr& client) {
    client->sendItem(completionHandler, _itemBegin, _itemEnd);
  });
}

void NetworkTransmitter::scheduleReceive()
{
  using namespace boost::system;
  
  _socket.async_receive_from(_requestPacket->io_buffer(), _requesterEp,
    [=](const boost::system::error_code &ec, size_t nread) {
      if (ec)
        throw boost::enable_error_info(system_error(ec,
          "NetworkTransmitter::scheduleReceive: async_receive_from")) << exception_source(this);
      if (nread != sizeof(PacketEnvelope)) {
        HAL_LOG(WARNING) << "invalid packet size: " << nread << "; client: " << _requesterEp;
        scheduleReceive();
        return;
      }
      if (_requestPacket->payloadSize > udp_parameters::MAX_PAYLOAD_SIZE) {
        HAL_LOG(WARNING) << "invalid payload size: " << _requestPacket->payloadSize;
        scheduleReceive();
        return;
      }
      if (_requestPacket->groupIndex & 0x80000000) {
        HAL_LOG(DEBUG) << "invalid group index in packet; ignoring: " << _requestPacket->groupIndex;
        scheduleReceive();
        return;
      }
      
      processRequest();
      scheduleReceive();
    });
}

void NetworkTransmitter::processRequest()
{
  auto it = std::find_if(_clients.begin(), _clients.end(),
    [this](const ClientStatePtr& client) { return client->ep() == _requesterEp; });

  switch (_requestPacket->format())
  {
  case PacketEnvelope::PT_CONNECT:
    registerClient(it, _requesterEp);
    return;
    
  case PacketEnvelope::PT_RESEND:
    if (it == _clients.end())
      HAL_LOG(WARNING) << "Received resend request from unregistered client: " << _requesterEp;
    else
      (*it)->resendPackets(*_requestPacket);
    return;
  
  default:
    HAL_LOG(WARNING) << "invalid packet format";
  }
}

void NetworkTransmitter::registerClient(ClientStateList::iterator it, udp_endpoint clientEp)
{
  if (it != _clients.end()) {
    assert((*it)->ep() == clientEp);
    if ((*it)->failed()) {
      *it = std::make_shared<ClientState>(*this, clientEp);
      HAL_LOG(DEBUG) << "revived client: " << clientEp;
    } else {
      (*it)->setLastSeenTime(std::chrono::steady_clock::now());
      HAL_LOG(DISABLED) << "received keepalive from client: " << clientEp;
    }
  }
  else {
    _clients.push_back(std::make_shared<ClientState>(*this, clientEp));
    HAL_LOG(INFO) << "added client: " << clientEp << "; total client count: " << _clients.size();
  }
}

} // hal
