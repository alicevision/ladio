// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <type_traits>
#include <boost/asio.hpp>

namespace hal
{

namespace asio = boost::asio;

/*!
 One endpoint of the socketpair.
 */
template<typename T>
class TypedLocalConnectionEndpoint
{
  template<typename, typename> friend class TypedLocalConnection;
  // XXX: is_trivially_copyable is not implemented yet
  // static_assert(std::is_trivially_copyable<T>::value, "message must be a POD");

  asio::local::datagram_protocol::socket& _socket;
  
protected:  
  TypedLocalConnectionEndpoint(asio::local::datagram_protocol::socket& socket) :
    _socket(socket)
  { }

public:
  asio::io_service& get_io_service()
  {
    return _socket.get_io_service();
  }
  
  void cancel()
  {
    _socket.cancel();
  }
  
  void send(const T& message)
  {
    _socket.send(asio::buffer(&message, sizeof(message)));
  }
  
  void receive(T& message)
  {
    _socket.receive(asio::buffer(&message, sizeof(message)));
  }
  
  // Communication over local sockets is extremely unlikely to fail, and if it does, we can't recover.
  
  template<typename F>
  void async_send(const T& message, const F& handler)
  {
    _socket.async_send(asio::buffer(&message, sizeof(message)),
      [this, handler](const boost::system::error_code& ec, size_t n) {
        if (ec || n != sizeof(message))
          throw boost::system::system_error(ec, "TypedLocalConnectionEndpoint: async_send");
        handler();
      });
  }
  
  template<typename F>
  void async_receive(T& message, const F& handler)
  {
    _socket.async_receive(asio::buffer(&message, sizeof(message)),
      [this, handler](const boost::system::error_code& ec, size_t n) {
        if (ec || n != sizeof(message))
          throw boost::system::system_error(ec, "TypedLocalConnectionEndpoint: async_receive");
        handler();
      });
  }
};

/*!
 Typed socketpair with different message types at upstream and downstream.
 Note that both sockets are set to non-blocking mode, so blocking receive and
 send can be safely used for polling in an async event loop.
 */
template<typename U, typename D = U>
class TypedLocalConnection
{
  asio::local::datagram_protocol::socket
    _upstreamSocket, _downstreamSocket;
  
public:
  TypedLocalConnection(asio::io_service& io) :
    _upstreamSocket(io), _downstreamSocket(io)
  {
    asio::local::connect_pair(_upstreamSocket, _downstreamSocket);
    _upstreamSocket.non_blocking(true);
    _downstreamSocket.non_blocking(true);
  }
    
  asio::io_service& get_io_service()
  {
    return _upstreamSocket.get_io_service();
  }
    
  TypedLocalConnectionEndpoint<U> upstream()
  {
    return TypedLocalConnectionEndpoint<U>(_upstreamSocket);
  }

  TypedLocalConnectionEndpoint<D> downstream()
  {
    return TypedLocalConnectionEndpoint<D>(_downstreamSocket);
  }
};

}
