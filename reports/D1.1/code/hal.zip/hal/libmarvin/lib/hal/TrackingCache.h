// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once
#include <boost/serialization/nvp.hpp>
#include <boost/serialization/version.hpp>
#include <boost/serialization/vector.hpp>
#include <boost/serialization/string.hpp>
#include <boost/serialization/array.hpp>

namespace hal
{

class FrameMetadata;

namespace tracking_cache
{

struct TCTime
{
  int hour, minute, second, frame, subframe;
  
  template<typename Archive>
  void serialize(Archive& ar, const unsigned /*version*/)
  {
    ar & BOOST_SERIALIZATION_NVP(hour);
    ar & BOOST_SERIALIZATION_NVP(minute);
    ar & BOOST_SERIALIZATION_NVP(second);
    ar & BOOST_SERIALIZATION_NVP(frame);
    ar & BOOST_SERIALIZATION_NVP(subframe);
  }
};

struct TCDate
{
  int year, month, day;

  template<typename Archive>
  void serialize(Archive& ar, const unsigned /*version*/)
  {
    ar & BOOST_SERIALIZATION_NVP(year);
    ar & BOOST_SERIALIZATION_NVP(month);
    ar & BOOST_SERIALIZATION_NVP(day);
  }
};

struct CCTag
{
  int id;
  float x, y;
  // TODO: ellipse information, not sent by gort ATM.
  
  template<typename Archive>
  void serialize(Archive& ar, const unsigned /*version*/)
  {
    ar & BOOST_SERIALIZATION_NVP(id);
    ar & BOOST_SERIALIZATION_NVP(x);
    ar & BOOST_SERIALIZATION_NVP(y);
  }
};

struct FrameTrackingInfo
{
  TCTime time;
  std::vector<CCTag> tags;
  float glRotation[9];      // boost serialization doesn't have overload for std::array
  float glTranslation[3];
  float mayaCameraMatrix[16];

  template<typename Archive>
  void serialize(Archive& ar, const unsigned /*version*/)
  {
    ar & BOOST_SERIALIZATION_NVP(time);
    ar & BOOST_SERIALIZATION_NVP(tags);
    ar & BOOST_SERIALIZATION_NVP(glRotation);
    ar & BOOST_SERIALIZATION_NVP(glTranslation);
    ar & BOOST_SERIALIZATION_NVP(mayaCameraMatrix);
  }
};

class TrackingLog
{
public:
  TCDate date;
  std::vector<float> intrinsics;
  std::vector<float> extrinsics;
  int frameWidth, frameHeight;
  std::vector<FrameTrackingInfo> frames;
  
  void addFrame(const FrameMetadata&);
  
  template<typename Archive>
  void serialize(Archive& ar, const unsigned /*version*/)
  {
    ar & BOOST_SERIALIZATION_NVP(date);
    ar & BOOST_SERIALIZATION_NVP(intrinsics);
    ar & BOOST_SERIALIZATION_NVP(extrinsics);
    ar & BOOST_SERIALIZATION_NVP(frameWidth);
    ar & BOOST_SERIALIZATION_NVP(frameHeight);
    ar & BOOST_SERIALIZATION_NVP(frames);
  }
  
  static void save(const std::string& filename, TrackingLog& tl);
  static TrackingLog load(const std::string& filename);
  
private:
  // Not serializaed
  bool _hasDate = false;
  bool _hasIntrinsics = false;
};

} // tracking_cache
} // hal

// Must be at top-level namespace
BOOST_CLASS_VERSION(hal::tracking_cache::TCTime, 1)
BOOST_CLASS_VERSION(hal::tracking_cache::TCDate, 1)
BOOST_CLASS_VERSION(hal::tracking_cache::CCTag, 1)
BOOST_CLASS_VERSION(hal::tracking_cache::FrameTrackingInfo, 1)
BOOST_CLASS_VERSION(hal::tracking_cache::TrackingLog, 1)
