// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <array>
#include <fstream>
#include <boost/log/sinks/async_frontend.hpp>
#include <boost/log/attributes/attribute.hpp>
#include <boost/log/attributes/clock.hpp>
#include <boost/log/expressions/formatters/date_time.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/utility/setup/common_attributes.hpp>
#include <boost/log/utility/setup/filter_parser.hpp>
#include <boost/log/support/date_time.hpp>
#include <boost/log/sinks/text_ostream_backend.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/sinks/text_file_backend.hpp>
#include <boost/serialization/singleton.hpp>
#include <boost/serialization/extended_type_info.hpp>
#include <boost/serialization/shared_ptr.hpp>
#include "Logger.h"

namespace hal
{

namespace logging = boost::log;
namespace expr = boost::log::expressions;
namespace sinks = boost::log::sinks;
namespace keywords = boost::log::keywords;
namespace attrs = boost::log::attributes;
namespace sinks = boost::log::sinks;

typedef sinks::asynchronous_sink<sinks::text_ostream_backend> log_stream_sink_t;

static boost::shared_ptr<log_stream_sink_t> log_stream_sink;
static boost::shared_ptr<Logger> global_logger;

Logger& get_global_logger()
{
  if (!global_logger)
    throw std::logic_error("get_global_logger: logging not initialized");
  return *global_logger;
}

std::ostream& operator<<(std::ostream& strm, severity_level level)
{
  // String prefix for severity level; defined in syslog(3), parsed by journald; 7: most verbose
  static const std::array<const char*, 5> LEVEL_STRINGS = {{ "<7>", "<6>", "<5>", "<4>", "<3>" }};
  if (static_cast<size_t>(level) < LEVEL_STRINGS.size())
    strm << LEVEL_STRINGS[level];
  else
    strm << level;
  return strm;
}

std::istream& operator>>(std::istream& strm, severity_level& level)
{
  int l;
  if (!(strm >> l))
    return strm;
  if (l < 0 || l > ERROR)
    throw std::runtime_error("invalid severity value (allowed range is [0-4]");
  
  level = static_cast<severity_level>(l);
  return strm;
}

void setLogLevel(severity_level level)
{
  assert(log_stream_sink || !"must initialize logging first");
  
  if (log_stream_sink)
    log_stream_sink->set_filter(expr::attr<severity_level>("Severity") >= level);
}

void setLogFilter(const char* filterText)
{
  auto filter = boost::log::parse_filter(filterText);
  if (log_stream_sink)
    log_stream_sink->set_filter(filter);
}

static void initLogger(bool use_journal)
{
  // Setup console logger
  auto backend = boost::make_shared<sinks::text_ostream_backend>();
  backend->add_stream(boost::shared_ptr<std::ostream>(&std::clog, boost::serialization::null_deleter()));
  log_stream_sink = boost::make_shared<log_stream_sink_t>(backend);

  if (!use_journal) {
    backend->add_stream(boost::shared_ptr<std::ostream>(new std::ofstream("hal.log")));
    log_stream_sink->set_formatter(expr::stream
      << expr::format_date_time<boost::posix_time::ptime>("TimeStamp", "%Y-%m-%dT%H:%M:%S.%f") << ' '
      << expr::attr<attrs::current_thread_id::value_type>("ThreadID") << ' '
      << expr::attr<severity_level>("Severity") << ' '
      << '[' << expr::attr<std::string>("Channel") << ']' 
      << ' ' << expr::message
      << std::flush);
  }
  else {
    log_stream_sink->set_formatter(expr::stream
      << expr::attr<severity_level>("Severity")
      << '[' << expr::attr<std::string>("Channel") << ']' 
      << '[' << expr::attr<attrs::current_thread_id::value_type>("ThreadID") << ']'
      << ' ' << expr::message
      << std::flush);
  }
  backend->auto_flush(true);
}

// If use_journal is true, the output format is changed to accomodate journal conventions.
// In this case, the output is NOT sent to the console.
LoggerInstance startLogger(bool use_journal, const char* global_logger_channel_name)
{
  static struct once
  {
    once()
    {
      logging::add_common_attributes();
      logging::register_simple_filter_factory<severity_level,char>("Severity");
    }
  } _once;

  if (global_logger)
    throw std::logic_error("startLogger: already started");
  
  boost::shared_ptr<logging::core> core = logging::core::get();

  initLogger(use_journal);
  assert(log_stream_sink);

  core->add_sink(log_stream_sink);
  global_logger = boost::make_shared<Logger>(boost::log::keywords::channel = global_logger_channel_name);
  return LoggerInstance(&global_logger, logger_deleter());
}

void stopLogger()
{
  boost::shared_ptr<boost::log::core> core = boost::log::core::get();
  HAL_GLOBAL_LOG(INFO) << "stopLogger called";

  global_logger.reset();
  core->remove_sink(log_stream_sink);
  log_stream_sink->flush();
  log_stream_sink.reset();
}

void logger_deleter::operator()(boost::shared_ptr<Logger>* l) const
{
  if (*l) 
    stopLogger();
  if (*l)
    throw std::logic_error("stopLogger() failed");
}

} // hal
