// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <algorithm>
#include <vector>
#include <sstream>
#include <sys/types.h>
#include <sys/signal.h>
#include <signal.h>
#include <string.h>
#include <boost/interprocess/shared_memory_object.hpp>
#include <boost/interprocess/mapped_region.hpp>
#include <boost/system/system_error.hpp>
#include "Logger.h"
#include "SHMInterface.h"

namespace hal
{

namespace bi = boost::interprocess;

// Initializes the descriptor and returns the pointer past the end of used space.
char* FrameDescriptor::init(char* base)
{
  char* const ob = base;
  yuv = base; base += maxDecodedSize();
  haldata = base; base += maxEncodedSize();
  assert(base == ob+size());
  return base;
}

// NB! Not exported; implementation detail.
class SHMLayout
{
  friend class SHMInstance;
  
  static constexpr int CLIENT_COUNT = 4;
  static constexpr size_t HEADER_SIZE = 64 << 10;
  static constexpr size_t allocatedSize() { return HEADER_SIZE + CLIENT_COUNT*FrameDescriptor::size(); }

  using pointer = SHMInterface::pointer;

  char              _id[64];
  uint32_t          _abiSizeCheck;
  uint32_t          _segmentSize;
  int64_t           _clients[CLIENT_COUNT]; // we can check whether client is alive by pid
  pointer           _frame[CLIENT_COUNT];   // back buffer + front buffer for two clients
  FrameDescriptor   _frameDescriptors[CLIENT_COUNT];
  
  static SHMLayout* create(void* base, const char* id);
  static SHMLayout* attach(void* base, const char* id);
  static void copy(FrameDescriptor& dst, const FrameDescriptor& src);
};

//! Initializes a new segment at base.
SHMLayout* SHMLayout::create(void* base, const char* id)
{
  SHMLayout* self = static_cast<SHMLayout*>(base);
  
  if (strlen(id+1) > sizeof(self->_id))
    throw std::length_error("SHMLayout: id too long");
  if (id[0] != '/')
    throw std::invalid_argument("SHMLayout: id must begin with a '/'");
  
  strcpy(self->_id, id);
  self->_abiSizeCheck = sizeof(SHMLayout);
  self->_segmentSize = allocatedSize();

  char *p = reinterpret_cast<char*>(base) + HEADER_SIZE;
  for (int i = 0; i < CLIENT_COUNT; ++i) {
    self->_clients[i] = -1;
    self->_frame[i] = &self->_frameDescriptors[i];
    p = self->_frame[i]->init(p);
  }

  return self;
}

//! Returns null if base is an uninitialized segment, otherwise returns base cast to SHMLayout.
//! Throws exception on fatal errors.
SHMLayout* SHMLayout::attach(void *base, const char* id)
{
  SHMLayout *self = static_cast<SHMLayout*>(base);

  if (strcmp(self->_id, id) != 0)
    return nullptr;
  if (self->_abiSizeCheck != sizeof(SHMLayout))
    throw std::runtime_error("SHM: ABI size check failed [mismatching Boost ABI?]");
  if (self->_segmentSize != allocatedSize())
    throw std::runtime_error("SHM: invalid size");
  
  return self;
}

void SHMLayout::copy(FrameDescriptor& dst, const FrameDescriptor& src)
{
  memcpy(dst.yuv.get(), src.yuv.get(), FrameDescriptor::maxDecodedSize());
  memcpy(dst.haldata.get(), src.haldata.get(), src.halsize);
  dst.halsize = src.halsize;
}

/////////////////////////////////////////////////////////////////////////////

class SHMInstance : public SHMInterface
{
  Logger _logger;
  const bool _isCreator;
  bi::shared_memory_object _shm;
  bi::mapped_region _mapping;
  SHMLayout *_layout;
  int _slot;
  
public:
  SHMInstance(const char* id);
  SHMInstance(const char* id, int slot);
  ~SHMInstance();
  
  const char* name() const override
  {
    return _layout->_id;
  }
  
  FrameDescriptor& frame() const override
  {
    return *_layout->_frame[_slot];
  }
  
  void copy(int dstSlot, int srcSlot) override;
};

//! "create" constructor
SHMInstance::SHMInstance(const char* id) :
  _logger(boost::log::keywords::channel = "SHMInstance"),
  _isCreator(true),
  _shm(bi::open_or_create_t(), id, bi::read_write)
{
  using namespace boost::system;
  
  _shm.truncate(SHMLayout::allocatedSize());
  _mapping = bi::mapped_region(_shm, bi::read_write);
  _layout = SHMLayout::create(_mapping.get_address(), id);
  
  _slot = 0;
  _layout->_clients[0] = getpid();
  
  HAL_LOG(INFO) << "created segment " << id;
}

//! "open" constructor.
SHMInstance::SHMInstance(const char* id, int slot) :
  _logger(boost::log::keywords::channel = "SHMInstance"),
  _isCreator(false),
  _shm(bi::open_only_t(), id, bi::read_write),
  _mapping(_shm, bi::read_write),
  _layout(SHMLayout::attach(_mapping.get_address(), id)),
  _slot(slot)
{
  
  if (!_layout)
    throw std::runtime_error(std::string("invalid segment found for  name: ") + id);
  if (slot <= 0 || slot >= SHMLayout::CLIENT_COUNT)
    throw std::invalid_argument("invalid slot");
  {
    auto pid = _layout->_clients[slot];
    if (pid > 0 && kill(pid, 0) == 0) {
      std::ostringstream oss;
      oss << "slot " << slot << "already in use; PID: " << pid;
      throw std::runtime_error(oss.str());
    }
  }

  _layout->_clients[_slot] = getpid();
  HAL_LOG(INFO) << "attached to segment " << id << "; slot " << _slot;
}

SHMInstance::~SHMInstance()
{
  if (_isCreator) {
    if (!bi::shared_memory_object::remove(_layout->_id))
      HAL_LOG(ERROR) << "couldn't delete object with name " << _layout->_id;
  }
  HAL_LOG(INFO) << "instance destroyed; name: " << _layout->_id;
}

void SHMInstance::copy(int dstSlot, int srcSlot)
{
  if (dstSlot < 0 || dstSlot >= SHMLayout::CLIENT_COUNT)
    throw std::out_of_range("invalid dstSlot");
  if (dstSlot == SHMManager::DEMUXER_SLOT)
    throw std::invalid_argument("invalid dstSlot (must not write over demuxer's slot)");
  if (srcSlot < 0 || srcSlot >= SHMLayout::CLIENT_COUNT)
    throw std::out_of_range("invalid srcSlot");

  _layout->copy(
    _layout->_frameDescriptors[dstSlot],
    _layout->_frameDescriptors[srcSlot]);
}

/////////////////////////////////////////////////////////////////////////////
// We need SHMManager and static instance method to control order of destruction
// of static objects (reverse of order of construction).  The previous implementation
// deadlocked in boost::log being used in ~SHMInterface.

SHMManager& SHMManager::instance()
{
  static SHMManager self;
  return self;
}

SHMInterface& SHMManager::create(const char* id)
{
  for (const auto& it : instances)
    if (strcmp(it->name(), id) == 0)
      return *it;

  instances.push_back(std::unique_ptr<SHMInterface>(new SHMInstance(id)));
  return *instances.back();
}

SHMInterface& SHMManager::attach(const char* id, int slot)
{
  for (const auto& it : instances)
    if (strcmp(it->name(), id) == 0)
      return *it;
  
  instances.push_back(std::unique_ptr<SHMInterface>(new SHMInstance(id, slot)));
  return *instances.back();
}

void SHMManager::close(SHMInterface& instance)
{
  auto it = std::find_if(instances.begin(), instances.end(),
    [&](const std::unique_ptr<SHMInterface> &p) { return p.get() == &instance; });
    
  if (it == instances.end())
    throw std::logic_error("SHM: close: instance not found");
  instances.erase(it);
}

}
