lib/ contains bits and pieces of shared code. `hal` directory contains non-gui
code in `hal` namespace; `labo` directory contains Qt GUI classes used to
communicate with Daneel.

daneel/ contains rpcserver used to actually communicate with HAL. It is an
executable required by other projects.

