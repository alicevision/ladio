// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <time.h>
#include <thread>
#include <random>
#include "VideoTypes.h"
#include "Logger.h"

namespace hal
{

//! Generates a synthetic series of images (2D Brownian motion) in the absence of real cameras.
class SyntheticReader : public VideoStream
{
  VideoFrame_ptr _frame;
  uint32_t _counter;
  bool _running;
  TimecodeRate _tcr;
  TimecodeTime _current_tc;

  std::thread _thread;

  std::minstd_rand _rngEngine;
  std::uniform_int_distribution<> _rngDistPos;
  std::uniform_int_distribution<> _rngDistCol;
  int _x, _y;
  
  void generateFrame();
  void clearFrame();
  void copy(VideoFrame_ptr dst);
  void generateMotion(int nsteps);
  void linedda(int x1, int y1, int x2, int y2);
  void putPixel(int x, int y);
  bool updatePosition();
  void resetPosition();
  inline void addColor(unsigned char& c, int amount);
  inline unsigned char& pixel(int plane, int x, int y);

protected:
  void StartExternalSource() override;
  void StopExternalSource() override;

public:
  SyntheticReader(RecordingObserver&, const config::Camera&);
};

} // hal
