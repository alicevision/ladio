// (c) 2014-2016 Labo Mixedrealities AS
// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "GraphTypes.h"
#include "Logger.h"

#ifndef _WIN32
#include <pthread.h>
#endif

#include <openssl/md5.h>
#include <array>
#include <memory>
#include <iomanip>
#include <thread>
#include <fstream>
#include <boost/logic/tribool.hpp>
#include <boost/filesystem.hpp>
#include <boost/uuid/uuid.hpp>
#include <boost/uuid/random_generator.hpp>
#include <boost/uuid/string_generator.hpp>
#include <boost/uuid/uuid_io.hpp>


namespace hal
{
class FileHasherBody
{
  hal_logger_t _logger;
  bool _calculate_hash;
  TemporaryFileSet        _tfs;           // (Relative) path to tmp files.
  boost::filesystem::path _base_name;     // Common prefix of media and metadata files, INCLUDING UUID
  boost::filesystem::path _new_base_path; // In case of duplicate names from camera; INCLUDES path prefix, NO extension

  bool ExtractComponents();
  bool FindUnusedBaseName();
  boost::filesystem::path RenameFile(const boost::filesystem::path&);

  static void GenerateMD5Thread(const boost::filesystem::path& path);

public:
  FileHasherBody(bool calculate_hash);
  tbb::flow::continue_msg operator()(TemporaryFileSet);
};

// If calculate_hash is false, the files will only be renamed
FileHasherBody::FileHasherBody(bool calculate_hash) :
  _logger(boost::log::keywords::channel = "FileHasherNode"),
  _calculate_hash(calculate_hash)
{}

// The format for renaming is BASE_NAME.EXT.<UUID>
tbb::flow::continue_msg FileHasherBody::operator()(TemporaryFileSet tfs)
{
  _tfs = tfs;

  if (!tfs.ok) {
    HAL_LOG(ERROR) << "Received improperly finalized file set; not renaming; media file: " << tfs.media_file;
    return tbb::flow::continue_msg{};
  }

  if (tfs.media_file.empty()) {
    HAL_LOG(ERROR) << "Received empty media file name for renaming";
    return tbb::flow::continue_msg{};
  }
  if (!ExtractComponents() || !FindUnusedBaseName())
    return tbb::flow::continue_msg{};

  auto dst_media_path = RenameFile(_tfs.media_file);
  if (!_tfs.metadata_file.empty())
    RenameFile(_tfs.metadata_file);

  if (!dst_media_path.empty() && _calculate_hash) {
    std::thread t(GenerateMD5Thread, dst_media_path);
    t.detach();
  }

  return tbb::flow::continue_msg{};
}

bool FileHasherBody::ExtractComponents()
{
  _base_name = _tfs.media_file.stem().stem(); // Strip UUID and true extension to get the base name
  if (_base_name.empty()) {
    HAL_LOG(WARNING) << "Improperly formatted media file name; not renaming: " << _tfs.media_file;
    return false;
  }

  // This checks also that appended UUIDs match.
  if (!_tfs.metadata_file.empty() && _tfs.metadata_file.extension() != _tfs.media_file.extension()) {
    HAL_LOG(WARNING) << "Mismatching pair of temporary file names; not renaming: " << _tfs.media_file << "," << _tfs.metadata_file;
    return false;
  }

  return true;
}

bool FileHasherBody::FindUnusedBaseName()
{
  for (int i = 0; i < 1000; ++i) {
    _new_base_path = _tfs.media_file.parent_path() / _base_name;
    if (i > 0) {
      char ii[24];
      sprintf(ii, "#%02d", i);
      _new_base_path += ii;
    }

    boost::filesystem::path tmp1 = _new_base_path, tmp2 = _new_base_path;
    tmp1.replace_extension(_tfs.media_file.stem().extension());
    tmp2.replace_extension(_tfs.metadata_file.stem().extension());
    if (!exists(tmp1) && (_tfs.metadata_file.empty() || !exists(tmp2)))
      return true;
  }

  HAL_LOG(ERROR) << "Couldn't find unused base name for " << _base_name << "; not renaming.";
  return false;
}

boost::filesystem::path FileHasherBody::RenameFile(const boost::filesystem::path& src_path)
{
  auto dst_path = _new_base_path;
  dst_path.replace_extension(src_path.stem().extension());

  boost::system::error_code ec;
  rename(src_path, dst_path, ec);
  if (ec) {
    HAL_LOG(ERROR) << "Failed renaming " << src_path << " -> " << dst_path;
    return boost::filesystem::path();
  }
  return dst_path;
}

void FileHasherBody::GenerateMD5Thread(const boost::filesystem::path& path)
{
  HAL_GLOBAL_LOG(INFO) << "Generating checksum for file " << path;

#ifndef _WIN32
  {
    sched_param sch_params;
    sch_params.sched_priority = 0;
    if (pthread_setschedparam(pthread_self(), SCHED_IDLE, &sch_params)) {
      HAL_GLOBAL_LOG(WARNING) << "Failed to set thread scheduling for GenerateMD5: " << std::strerror(errno);
    }
  }
#endif

  MD5_CTX ctx;
  MD5_Init(&ctx);

  std::ifstream ifs(path.string().c_str(), std::ios::binary);
  if (!ifs) {
    HAL_GLOBAL_LOG(ERROR) << "Error opening file " << path.string() << " for generating checksum.";
    return;
  }

  static constexpr size_t BUF_SIZE = 1 << 20; // Read 1MB at a time.
  std::unique_ptr<char[]> buffer(new char[BUF_SIZE]);

  do {
    if (!ifs.read(buffer.get(), BUF_SIZE) && !ifs.eof()) {
      HAL_GLOBAL_LOG(ERROR) << "Error hashing file " << path.string();
      return;
    }
    MD5_Update(&ctx, buffer.get(), ifs.gcount());
  } while (ifs.gcount() == BUF_SIZE);

  HAL_GLOBAL_LOG(INFO) << "Completed generating checksum for file " << path.string();

  unsigned char md5[MD5_DIGEST_LENGTH + 16];
  MD5_Final(md5, &ctx);

  // Convert checksum to hex
  char buf[256];
  for (int i = 0; i < MD5_DIGEST_LENGTH; ++i)
    sprintf(buf + i * 2, "%02x", md5[i]);

  // Output to .md5 file
  std::string md5filename = path.string() + ".md5";
  std::ofstream of(md5filename, std::ios::trunc);
  if (of)
    of << buf << "\n";
  else
    HAL_GLOBAL_LOG(ERROR) << "Error writing checksum for file " << path;

#if 0
  if (cfg.sync_after_write)
    sync();
#endif
}

std::unique_ptr<FileHasherNode> MakeFileHasherNode(tbb::flow::graph& g, bool calculate_hash)
{
  return std::unique_ptr<FileHasherNode>(new FileHasherNode(g, 1, FileHasherBody(calculate_hash)));
}

} // hal
