// (c) 2014-2016 Labo Mixedrealities AS
// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "Config.h"
#include "GraphTypes.h"
#include "VideoTypes.h"
#include <mfxvideo++.h>
#include <array>
#include <memory>
#include <functional>
#include <boost/logic/tribool.hpp>
#include <boost/optional.hpp>

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <Windows.h>
#undef ERROR
#include "restricted/common_directx11.h"
#else
#include "restricted/common_vaapi.h"
#include "restricted/common_utils.h"
#endif

extern "C"
{
#include <libswresample/swresample.h>
#include <libswscale/swscale.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
}

using boost::tribool;
using boost::indeterminate;

namespace
{
static struct AV_INITIALIZER_
{
    AV_INITIALIZER_()
    {
        av_register_all();
        avcodec_register_all();
    }
} AV_INITIALIZER;
}

namespace hal
{

class AVCodecEncoder : public AVCodecContextHolder
{
protected:
    hal_logger_t _logger;
    bool _finalizing;
    int _ec;

    AVCodec *_codec;
    AVCodecContext *_context;
    AVFrame *_frame;

    AVCodecEncoder(const char* log_channel, AVCodecID codec_id);
    virtual void SetContextParameters(const VideoStream_ptr&, const config::OutputCodecPreset&) = 0;
    virtual void FillAVFrame(const VideoFrame_ptr&) = 0;

public:
    ~AVCodecEncoder() override;
    AVCodecContext* CodecContext() const override final { return _context; }
    EncodedPacket::Payload Encode(const RawPacket&) override;
    EncodedPacket::Payload Finalize() override;
};

AVCodecEncoder::AVCodecEncoder(const char* log_channel, AVCodecID codec_id) :
    _logger(boost::log::keywords::channel = log_channel),
    _finalizing(false),
    _ec(0),
    _codec(avcodec_find_encoder(codec_id))
{
    if (!_codec)
        HAL_LOG(WARNING) << "Codec " << avcodec_get_name(codec_id) << " not found; expect crash unless external codec is used";
    if (!(_context = avcodec_alloc_context3(_codec)))
        throw std::runtime_error("avcodec_alloc_context3");
    if (!(_frame = av_frame_alloc())) {
        avcodec_free_context(&_context);
        throw std::runtime_error("av_frame_alloc");
    }
    _context->flags = CODEC_FLAG_GLOBAL_HEADER;
}

AVCodecEncoder::~AVCodecEncoder()
{
    avcodec_free_context(&_context);
    av_frame_free(&_frame);
}

EncodedPacket::Payload AVCodecEncoder::Encode(const RawPacket& raw)
{
    EncodedPacket::Payload ep;

    if (_finalizing)
        throw std::logic_error("Encode called while finalize in progress");
    if (_ec < 0)
        throw std::logic_error("Codec already failed.");

    auto t0 = std::chrono::system_clock::now();

    // Try to get coded packet first, if any, to account for the case where the codec has a delay of exactly 1 frame.
    // In this case, avcodec_receive_packet won't return any packet after the 1st frame, but sending the subsequent
    // frame would fail if send were before receive.

    {
        auto avph = std::make_shared<AVPacketHolder>();
        if ((_ec = avcodec_receive_packet(_context, avph.get())) < 0 && _ec != AVERROR(EAGAIN))
            throw ffmpeg_error("avcodec_receive_packet", _ec);
        if (!_ec) ep.packet = avph; // Error, if any, must be EAGAIN here, so reset it to 0.
        else _ec = 0;
    }

    FillAVFrame(raw.frame);
    _frame->pts = raw.recording_length; // NB! Must rescale in AVFormatWriter

    if ((_ec = avcodec_send_frame(_context, _frame)) < 0)
        throw ffmpeg_error("avcodec_send_frame", _ec);

    auto td = std::chrono::system_clock::now() - t0;
    HAL_LOG(TRACE) << "Encoding took: " << std::chrono::duration_cast<std::chrono::milliseconds>(td).count();
    return ep;
}

// The caller must keep calling Finalize() until it returns an empty packet.
// Not proud of this code, send your thanks to the FFMPEG team.
EncodedPacket::Payload AVCodecEncoder::Finalize()
{
    if (_ec < 0)
        throw std::logic_error("Codec already failed.");

    EncodedPacket::Payload ep;
    ep.packet = std::make_shared<AVPacketHolder>();

retry:
    if ((_ec = avcodec_receive_packet(_context, ep.packet.get())) == AVERROR(EAGAIN)) {
        if (_finalizing) {
            HAL_LOG(ERROR) << "Finalize: avcodec_receive_packet returned EAGAIN during draining; finishing.";
            _ec = AVERROR_EOF;
        }
        else {
            if ((_ec = avcodec_send_frame(_context, 0)) < 0)    // FFS, this may return AVERROR(EAGAIN)! 
                throw ffmpeg_error("avcodec_send_frame(draining)", _ec);
            _finalizing = true;
            goto retry;
        }
    }
    else if (_ec) {
        if (_ec != AVERROR_EOF)
            throw ffmpeg_error("avcodec_receive_packet(draining)", _ec);
        ep.packet = nullptr;                                    // Don't reset _ec here, further calls to Finalize must fail.
    }

    return ep;
}

/////////////////////////////////////////////////////////////////////////////

class AVCodecAudioEncoder : public AVCodecEncoder
{
    SwrContext* _swr = nullptr;

    uint64_t GetChannelLayout(int channel_count);

protected:
    void SetContextParameters(const VideoStream_ptr&, const config::OutputCodecPreset&) override;
    void FillAVFrame(const VideoFrame_ptr& frame) override;

public:
    AVCodecAudioEncoder(const VideoStream_ptr& stream, const config::OutputCodecPreset& params);
};

AVCodecAudioEncoder::AVCodecAudioEncoder(const VideoStream_ptr& stream, const config::OutputCodecPreset& params) :
    AVCodecEncoder("AVCodecAudioEncoder", params.audio_codec)
{
    SetContextParameters(stream, params);
    if ((_ec = avcodec_open2(_context, _codec, nullptr)) < 0)
        throw ffmpeg_error("avcodec_open2(audio)", _ec);
}

// All audio is normalized to mono, 16-bit PCM @ 48kHZ.
void AVCodecAudioEncoder::SetContextParameters(const VideoStream_ptr& stream, const config::OutputCodecPreset& params)
{
    if (stream->channel_count > VideoFrame::MAX_AUDIO_CHANNELS)
        HAL_LOG(WARNING) << "Discarding excess audio channels; available count=" << stream->channel_count
        << "; max count=" << VideoFrame::MAX_AUDIO_CHANNELS;

    _context->codec_type = AVMEDIA_TYPE_AUDIO;
    _context->codec_id = params.audio_codec; AV_CODEC_ID_PCM_S16LE;
    _context->sample_rate = params.audio_sample_rate;
    _context->bit_rate = params.audio_bitrate;
    _context->channels = params.audio_channel_count;
    _context->sample_fmt = params.audio_sample_format;
    _context->channel_layout = AV_CH_LAYOUT_MONO;

    _frame->channels = 1;
    _frame->format = _context->sample_fmt;
    _frame->channel_layout = _context->channel_layout;
    _frame->sample_rate = _context->sample_rate;
    _frame->nb_samples = _context->sample_rate / stream->fps;           // allocate max space for frame
    _frame->linesize[0] = _frame->nb_samples * sizeof(int16_t);
    _frame->key_frame = 1;                                              // Every frame is a key frame for the PCM codec.
    if ((_ec = av_frame_get_buffer(_frame, 64)) < 0)
        throw ffmpeg_error("av_frame_get_buffer(audio)", _ec);

    if (_context->sample_rate != stream->sample_rate || stream->channel_count != 1 || _context->sample_fmt != stream->sample_format) {
        _swr = swr_alloc_set_opts(nullptr, _frame->channel_layout, AVSampleFormat(_frame->format), _frame->sample_rate,
            GetChannelLayout(stream->channel_count), stream->sample_format, stream->sample_rate, 0, nullptr);
        if (!_swr)
            throw std::runtime_error("swr_alloc_set_opts");
        if (swr_init(_swr) < 0)
            throw std::runtime_error("swr_init");
    }
}

uint64_t AVCodecAudioEncoder::GetChannelLayout(int channel_count)
{
    if (channel_count > 8) {
        HAL_LOG(WARNING) << "Unsupported channel count: " << channel_count << "; truncating to 8";
        channel_count = 8;
    }

    switch (channel_count) {
    case 0:
    case 1: return AV_CH_LAYOUT_MONO;
    case 2: return AV_CH_LAYOUT_STEREO;
    case 3: return AV_CH_LAYOUT_SURROUND;
    case 4: return AV_CH_LAYOUT_QUAD;
    case 5: return AV_CH_LAYOUT_5POINT0;
    case 6: return AV_CH_LAYOUT_6POINT0;
    case 7: return AV_CH_LAYOUT_7POINT0;
    case 8: return AV_CH_LAYOUT_OCTAGONAL;
    }

    throw std::invalid_argument("AVCodecAudioEncoder::GetChannelLayout");
}

void AVCodecAudioEncoder::FillAVFrame(const VideoFrame_ptr& frame)
{
    _frame->nb_samples = frame->num_audio_samples;

    if (!_swr) {
        memcpy(_frame->data[0], frame->audio_plane[0], _frame->nb_samples * sizeof(int16_t));
    }
    else {
        uint8_t* out[1] = { _frame->data[0] };
        if (swr_convert(_swr, out, frame->num_audio_samples, (const uint8_t**)frame->audio_plane, frame->num_audio_samples) < 0) {
            HAL_LOG(WARNING) << "swr_convert failed; no audio emitted";
            _frame->nb_samples = 0;
        }
    }
}

/////////////////////////////////////////////////////////////////////////////

class AVCodecVideoEncoder : public AVCodecEncoder
{
    struct SwsContext* _sws = nullptr;

protected:
    AVCodecVideoEncoder(const char* name, const config::OutputCodecPreset&);

    void SetContextParameters(const VideoStream_ptr&, const config::OutputCodecPreset&) override;
    void FillAVFrame(const VideoFrame_ptr&) override;

public:
    AVCodecVideoEncoder(const VideoStream_ptr& stream, const config::OutputCodecPreset& params);
    ~AVCodecVideoEncoder();
};

// Allows other codecs to be wrapped into AVCodecContext.  This ctor doesn't do any initialization
// except for the base class.
AVCodecVideoEncoder::AVCodecVideoEncoder(const char* name, const config::OutputCodecPreset& params) :
    AVCodecEncoder(name, params.video_codec)
{}

AVCodecVideoEncoder::AVCodecVideoEncoder(const VideoStream_ptr& stream, const config::OutputCodecPreset& params) :
    AVCodecEncoder("AVCodecVideoEncoder", params.video_codec)
{
    SetContextParameters(stream, params);
    AVDictionary *opts = NULL;
    av_dict_set(&opts, "threads", params.threads.c_str(), 0);
    if (!params.profile.empty())
        av_dict_set(&opts, "profile", params.profile.c_str(), 0);
    //if (stream->pixel_format == AV_PIX_FMT_GRAY8)
    //    av_dict_set(&opts, "flags", "gray", 0);
    if ((_ec = avcodec_open2(_context, _codec, &opts)) < 0)     // XXX: should free dictionary after this??
        throw ffmpeg_error("avcodec_open2(video)", _ec);
}

AVCodecVideoEncoder::~AVCodecVideoEncoder()
{
    if (_sws)
        sws_freeContext(_sws);
}

void AVCodecVideoEncoder::SetContextParameters(const VideoStream_ptr& stream, const config::OutputCodecPreset& params)
{
    _context->codec_type = AVMEDIA_TYPE_VIDEO;
    _context->codec_id = params.video_codec;
    _context->bit_rate = params.video_bitrate;
    _context->rc_max_rate = params.video_bitrate + 100000;
    _context->width = params.width;
    _context->height = params.height;
    _context->time_base.den = Config->fps;
    _context->time_base.num = 1;
    _context->gop_size = params.h264_gop_size;
    _context->pix_fmt = AV_PIX_FMT_NONE;

    // Try to match target format with that supported by codec.
    if (!_codec) {
        _context->pix_fmt = params.output_pixel_format;
    }
    else {
        for (int i = 0; _codec->pix_fmts[i] != AV_PIX_FMT_NONE; ++i)
            if (_codec->pix_fmts[i] == params.output_pixel_format) {
                _context->pix_fmt = params.output_pixel_format;
                break;
            }
        // Codec doesn't support the target format.  Assume the 1st in the list is the "best".
        if (_context->pix_fmt == AV_PIX_FMT_NONE)
            _context->pix_fmt = _codec->pix_fmts[0];
    }

    _frame->format = _context->pix_fmt;
    _frame->width = _context->width;
    _frame->height = _context->height;

    // Note: frame buffer has to be allocated only if we must convert the input frame to another format.
    // Otherwise, we just copy data pointers to the frame before sending it out.
    if (stream->pixel_format != _frame->format || stream->width != _frame->width || stream->height != _frame->height) {
        if (stream->strict) {
            if (stream->width != _frame->width || stream->height != _frame->height)
                throw std::runtime_error("Mismatched codec/stream resolution; stream: " + stream->name);
            bool is_stream_10bit = stream->pixel_format == AV_PIX_FMT_YUV422P10LE;
            bool is_output_10bit = stream->pixel_format == AV_PIX_FMT_YUV422P10LE;
            if (is_stream_10bit && !is_output_10bit)
                throw std::runtime_error("Output loses color precision; stream:" + stream->name);
        }
        if (av_frame_get_buffer(_frame, 64) < 0)
            throw std::runtime_error("AVCodecVideoEncoder: av_frame_get_buffer");
        _sws = sws_getContext(stream->width, stream->height, stream->pixel_format,
            _frame->width, _frame->height, static_cast<AVPixelFormat>(_frame->format), SWS_FAST_BILINEAR,
            nullptr, nullptr, nullptr);
        if (!_sws)
            throw std::runtime_error("AVCodecVideoEncoder: sws_getCachedContext");
    }
}

void AVCodecVideoEncoder::FillAVFrame(const VideoFrame_ptr& frame)
{
    if (!_sws) {
        _frame->data[0] = frame->plane[0];
        _frame->data[1] = frame->plane[1];
        _frame->data[2] = frame->plane[2];
        _frame->linesize[0] = frame->stride[0];
        _frame->linesize[1] = frame->stride[1];
        _frame->linesize[2] = frame->stride[2];
    }
    else {
        sws_scale(_sws, frame->plane, frame->stride, 0, frame->stream->height, _frame->data, _frame->linesize);
    }
}

// INTEL ENCODER, MFX API: TBD //////////////////////////////////////////////

// We still need ffmpeg ACodecContext.
class IntelVideoEncoder : public AVCodecVideoEncoder
{
    static mfxHDL DEVICE_HANDLE;

    MFXVideoSession _mfxSession;
    mfxFrameAllocator _mfxFrameAllocator;
    mfxVideoParam _mfxVideoParam;
    mfxExtCodingOption _mfxExtCodingOption;
    mfxExtCodingOption2 _mfxExtCodingOption2;
    mfxExtBuffer* _extendedBuffers[2];
    std::unique_ptr<MFXVideoENCODE> _mfxVideoEncode;
    mfxFrameAllocResponse _mfxFrameAllocResponse;
    mfxFrameSurface1** _pmfxSurfaces;
    mfxBitstream _mfxBitStream;
    SwsContext* _sws;
    bool _failed;

    static inline int align16(int n) { return 16 * ((n + 15) / 16); }

    void InitSession();
    void SetEncoderParameters(const VideoStream_ptr&, const config::OutputCodecPreset&);
    void EnableLowLatency(int gop_size);
    void AllocateSurfaces();
    void PrepareBitstream();
    std::vector<mfxU8> GetSPSPPS();
    mfxStatus EncodeFrameSync(mfxFrameSurface1*);
    std::shared_ptr<AVPacketHolder> ExtractBitstream();

    void LoadRaw400Frame(mfxFrameSurface1*, VideoFrame_ptr);
    void LoadRaw420Frame(mfxFrameSurface1*, VideoFrame_ptr);
    void LoadRaw422Frame(mfxFrameSurface1*, VideoFrame_ptr);
    void LoadRaw422P10Frame(mfxFrameSurface1*, VideoFrame_ptr);
    int GetFreeSurfaceIndex();

public:
    IntelVideoEncoder(const VideoStream_ptr& stream, const config::OutputCodecPreset& params, bool low_latency);
    ~IntelVideoEncoder();
    EncodedPacket::Payload Encode(const RawPacket& raw) override;
    EncodedPacket::Payload Finalize() override;
};

mfxHDL IntelVideoEncoder::DEVICE_HANDLE;

IntelVideoEncoder::IntelVideoEncoder(const VideoStream_ptr& stream, const config::OutputCodecPreset& params, bool low_latency) :
    AVCodecVideoEncoder("IntelVideoEncoder", params),
    _sws(nullptr),
    _failed(false)
{
    if (params.video_codec != AV_CODEC_ID_H264)
        throw std::invalid_argument("IntelVideoEncoder: codec not H264");

    SetContextParameters(stream, params);

    InitSession();
    _mfxVideoEncode.reset(new MFXVideoENCODE(_mfxSession));
    SetEncoderParameters(stream, params);
    if (low_latency)
        EnableLowLatency(params.h264_gop_size);
    AllocateSurfaces();

    {
        auto status = _mfxVideoEncode->Init(&_mfxVideoParam);
        if (status < MFX_ERR_NONE)
            throw std::runtime_error("MFXVideoEncode::Init");
        if (status == MFX_WRN_PARTIAL_ACCELERATION)
            HAL_GLOBAL_LOG(WARNING) << "MFXVideoEncode: partial acceleration";
    }

    PrepareBitstream();

    auto spspps = GetSPSPPS();
    if (!spspps.empty()) {
        _context->extradata_size = spspps.size();
        if (!(_context->extradata = (uint8_t *)av_malloc(spspps.size() + AV_INPUT_BUFFER_PADDING_SIZE)))
            throw std::bad_alloc();
        memcpy(_context->extradata, spspps.data(), spspps.size());
    }
}

IntelVideoEncoder::~IntelVideoEncoder()
{
    if (_mfxVideoEncode->Close() < MFX_ERR_NONE)
        HAL_LOG(ERROR) << "MFXVideoSession::Close";
    for (int i = 0; i < _mfxFrameAllocResponse.NumFrameActual; ++i)
        delete _pmfxSurfaces[i];
    delete[] _pmfxSurfaces;
    delete[] _mfxBitStream.Data;
    if (_mfxFrameAllocator.Free(_mfxFrameAllocator.pthis, &_mfxFrameAllocResponse) < MFX_ERR_NONE)
        HAL_LOG(ERROR) << "MFXFrameAllocator::Free";
    sws_freeContext(_sws);
}

void IntelVideoEncoder::InitSession()
{
    mfxInitParam param;
    param.Implementation = MFX_IMPL_HARDWARE;
    param.Version.Major = 1;
    param.Version.Minor = 16;   // Needed for MaxDecFrameBuffering
    param.ExternalThreads = 0;  // TODO: can use own threads so as to not clash with TBB
    param.ExtParam = nullptr;
    param.NumExtParam = 0;
    param.GPUCopy = MFX_GPUCOPY_DEFAULT;
#ifdef  _WIN32
    param.Implementation |= MFX_IMPL_VIA_D3D11;
#else //  _WIN32
    param.Implementation |= MFX_IMPL_VIA_VAAPI;
#endif

    mfxStatus sts = _mfxSession.InitEx(param);
    if (sts != MFX_ERR_NONE)
        throw std::runtime_error("MFXVideoSession::Init");

    if (!DEVICE_HANDLE) {
#ifdef _WIN32
        mfxStatus status = CreateHWDevice(_mfxSession, &DEVICE_HANDLE, 0, false);
#else
        mfxStatus status = CreateVAEnvDRM(&DEVICE_HANDLE);
#endif
        if (status != MFX_ERR_NONE)
            throw std::runtime_error("IntelVideoEncoder: failed to create HW device");
    }

    {
#ifdef _WIN32
        mfxHandleType ht = MFX_HANDLE_D3D11_DEVICE;
#else
        mfxHandleType ht = MFX_HANDLE_VA_DISPLAY;
#endif
        if (_mfxSession.SetHandle(ht, DEVICE_HANDLE) != MFX_ERR_NONE)
            throw std::runtime_error("MFXVideoSession::SetHandle");
    }

    _mfxFrameAllocator.pthis = _mfxSession;
    _mfxFrameAllocator.Alloc = simple_alloc;
    _mfxFrameAllocator.Free = simple_free;
    _mfxFrameAllocator.Lock = simple_lock;
    _mfxFrameAllocator.Unlock = simple_unlock;
    _mfxFrameAllocator.GetHDL = simple_gethdl;
    if (_mfxSession.SetFrameAllocator(&_mfxFrameAllocator) != MFX_ERR_NONE)
        throw std::runtime_error("MFXVideoSession::SetFrameAllocator");
}

void IntelVideoEncoder::SetEncoderParameters(const VideoStream_ptr& stream, const config::OutputCodecPreset& params)
{
    memset(&_mfxVideoParam, 0, sizeof(_mfxVideoParam));

    _mfxVideoParam.IOPattern = MFX_IOPATTERN_IN_VIDEO_MEMORY;
    _mfxVideoParam.AsyncDepth = 1;                              // We use own encoder instance for each stream; no pipelining atm

    _mfxVideoParam.mfx.CodecId = MFX_CODEC_AVC;
    _mfxVideoParam.mfx.TargetKbps = params.video_bitrate / 1000;      // Bitrate is in Mbps
    _mfxVideoParam.mfx.MaxKbps = 3 * _mfxVideoParam.mfx.TargetKbps / 2;
    _mfxVideoParam.mfx.RateControlMethod = MFX_RATECONTROL_VBR;
    _mfxVideoParam.mfx.EncodedOrder = 0;
    _mfxVideoParam.mfx.GopPicSize = params.h264_gop_size;
    _mfxVideoParam.mfx.GopRefDist = 1;                          // Use only I and P frames.
    _mfxVideoParam.mfx.GopOptFlag = MFX_GOP_CLOSED;
    _mfxVideoParam.mfx.IdrInterval = 4;
    _mfxVideoParam.mfx.TargetUsage = MFX_TARGETUSAGE_BEST_QUALITY;

    _mfxVideoParam.mfx.FrameInfo.FrameRateExtN = stream->fps;
    _mfxVideoParam.mfx.FrameInfo.FrameRateExtD = 1;
    _mfxVideoParam.mfx.FrameInfo.FourCC = MFX_FOURCC_NV12;
    _mfxVideoParam.mfx.FrameInfo.ChromaFormat = MFX_CHROMAFORMAT_YUV420;
    _mfxVideoParam.mfx.FrameInfo.PicStruct = MFX_PICSTRUCT_PROGRESSIVE;
    _mfxVideoParam.mfx.FrameInfo.CropX = 0;
    _mfxVideoParam.mfx.FrameInfo.CropY = 0;
    _mfxVideoParam.mfx.FrameInfo.CropW = stream->width;
    _mfxVideoParam.mfx.FrameInfo.CropH = stream->height;
    _mfxVideoParam.mfx.FrameInfo.Width = align16(stream->width);
    _mfxVideoParam.mfx.FrameInfo.Height = align16(stream->height);
}

void IntelVideoEncoder::EnableLowLatency(int gop_size)
{
    _mfxVideoParam.mfx.TargetUsage = MFX_TARGETUSAGE_BALANCED;
    _mfxVideoParam.mfx.IdrInterval = 0;                       // Every I-frame is an IDR-frame.
    _mfxVideoParam.mfx.GopOptFlag = MFX_GOP_CLOSED | MFX_GOP_STRICT;

    memset(&_mfxExtCodingOption, 0, sizeof(_mfxExtCodingOption));
    _mfxExtCodingOption.Header.BufferId = MFX_EXTBUFF_CODING_OPTION;
    _mfxExtCodingOption.Header.BufferSz = sizeof(_mfxExtCodingOption);
    _mfxExtCodingOption.MaxDecFrameBuffering = 1;

    memset(&_mfxExtCodingOption2, 0, sizeof(_mfxExtCodingOption2));
    _mfxExtCodingOption2.Header.BufferId = MFX_EXTBUFF_CODING_OPTION2;
    _mfxExtCodingOption2.Header.BufferSz = sizeof(_mfxExtCodingOption2);
    _mfxExtCodingOption2.IntRefType = 1;
    _mfxExtCodingOption2.IntRefCycleSize = gop_size;

    _extendedBuffers[0] = (mfxExtBuffer*)&_mfxExtCodingOption;
    _extendedBuffers[1] = (mfxExtBuffer*)&_mfxExtCodingOption2;

    _mfxVideoParam.ExtParam = _extendedBuffers;
    _mfxVideoParam.NumExtParam = 2;
}

void IntelVideoEncoder::AllocateSurfaces()
{
    {
        mfxStatus status = _mfxVideoEncode->Query(&_mfxVideoParam, &_mfxVideoParam);
        if (status < MFX_ERR_NONE)
            throw std::runtime_error("MfxVideoENCODE::Query");
        if (status == MFX_WRN_INCOMPATIBLE_VIDEO_PARAM)
            HAL_GLOBAL_LOG(WARNING) << "MfxVideoEncode::Query: incompatible video parameters";
    }

    mfxFrameAllocRequest alloc_request;
    memset(&alloc_request, 0, sizeof(alloc_request));
    if (_mfxVideoEncode->QueryIOSurf(&_mfxVideoParam, &alloc_request) < MFX_ERR_NONE)
        throw std::runtime_error("MfxVideoENCODE::QueryIOSurf");
#ifdef _WIN32
    alloc_request.Type |= WILL_WRITE;
#endif

    if (_mfxFrameAllocator.Alloc(_mfxFrameAllocator.pthis, &alloc_request, &_mfxFrameAllocResponse) < MFX_ERR_NONE)
        throw std::runtime_error("MfxFrameAllocator::Alloc");

    _pmfxSurfaces = new mfxFrameSurface1*[_mfxFrameAllocResponse.NumFrameActual];
    for (int i = 0; i < _mfxFrameAllocResponse.NumFrameActual; ++i) {
        _pmfxSurfaces[i] = new mfxFrameSurface1;
        memset(_pmfxSurfaces[i], 0, sizeof(mfxFrameSurface1));
        memcpy(&_pmfxSurfaces[i]->Info, &_mfxVideoParam.mfx.FrameInfo, sizeof(mfxFrameInfo));
        _pmfxSurfaces[i]->Data.MemId = _mfxFrameAllocResponse.mids[i];
        // TODO: ClearYUVSurfaceVAAPI(pmfxSurfaces[i]->Data.MemId); NOT implemented in "restricted"
    }
}

void IntelVideoEncoder::PrepareBitstream()
{
    // Retrieve parameters set by encoder so we can allocate the bitstream buffer.
    mfxVideoParam par;
    memset(&par, 0, sizeof(par));
    if (_mfxVideoEncode->GetVideoParam(&par) < MFX_ERR_NONE)
        throw std::runtime_error("MFXVideoEncode::GetVideoParam");

    memset(&_mfxBitStream, 0, sizeof(_mfxBitStream));
    _mfxBitStream.MaxLength = par.mfx.BufferSizeInKB * 1000;
    _mfxBitStream.Data = new mfxU8[_mfxBitStream.MaxLength];
}

std::vector<mfxU8> IntelVideoEncoder::GetSPSPPS()
{
    mfxU8 sps[2048], pps[2048];

    mfxExtCodingOptionSPSPPS ext_opt;
    memset(&ext_opt, 0, sizeof(ext_opt));
    ext_opt.Header.BufferId = MFX_EXTBUFF_CODING_OPTION_SPSPPS;
    ext_opt.Header.BufferSz = sizeof(mfxExtCodingOptionSPSPPS);
    ext_opt.SPSBufSize = sizeof(sps);
    ext_opt.SPSBuffer = sps;
    ext_opt.PPSBufSize = sizeof(pps);
    ext_opt.PPSBuffer = pps;

    mfxExtBuffer* ext_buf[1];
    ext_buf[0] = (mfxExtBuffer*)&ext_opt;

    mfxVideoParam par;
    memset(&par, 0, sizeof(par));
    par.ExtParam = ext_buf;
    par.NumExtParam = 1;

    if (_mfxVideoEncode->GetVideoParam(&par) < MFX_ERR_NONE)
        throw std::runtime_error("MfxVideoEncode::GetVideoParam");

    std::vector<mfxU8> ret;
    ret.reserve(ext_opt.SPSBufSize + ext_opt.PPSBufSize);
    ret.insert(ret.end(), sps, sps + ext_opt.SPSBufSize);
    ret.insert(ret.end(), pps, pps + ext_opt.PPSBufSize);
    return ret;
}

mfxStatus IntelVideoEncoder::EncodeFrameSync(mfxFrameSurface1* surface)
{
    mfxSyncPoint syncp;
    mfxStatus status;

    while (1) {
        status = _mfxVideoEncode->EncodeFrameAsync(nullptr, surface, &_mfxBitStream, &syncp);

        if (status < MFX_ERR_NONE) {
            if (status != MFX_ERR_NOT_ENOUGH_BUFFER)
                break;
            _mfxBitStream.MaxLength *= 2;
            delete[] _mfxBitStream.Data;
            _mfxBitStream.Data = new mfxU8[_mfxBitStream.MaxLength];
            continue;
        }

        if (status == MFX_WRN_DEVICE_BUSY) {
            MSDK_SLEEP(2);
            continue;
        }

        if (syncp) {
            status = MFX_ERR_NONE;
            break;
        }
    }

    if (status < MFX_ERR_NONE) {
        if (status != MFX_ERR_MORE_DATA) {
            _failed = true;
            throw std::runtime_error("MfxVideoEncoder::EncodeFrameAsync");
        }
        return status;
    }

    if (_mfxSession.SyncOperation(syncp, 10000) < MFX_ERR_NONE) {
        _failed = true;
        throw std::runtime_error("MfxVideoEncoder::SyncOperation");
    }

    return MFX_ERR_NONE;
}

std::shared_ptr<AVPacketHolder> IntelVideoEncoder::ExtractBitstream()
{
    std::shared_ptr<AVPacketHolder> packet;

    if (!_mfxBitStream.DataLength)
        return packet;

    packet = std::make_shared<AVPacketHolder>();
    if (!(packet->buf = av_buffer_alloc(_mfxBitStream.DataLength)))
        throw std::bad_alloc();
    memcpy(packet->buf->data, _mfxBitStream.Data, _mfxBitStream.DataLength);
    packet->data = packet->buf->data;
    packet->size = _mfxBitStream.DataLength;
    packet->pts = _mfxVideoParam.mfx.FrameInfo.FrameRateExtN * _mfxBitStream.TimeStamp / 90000;
    packet->dts = _mfxVideoParam.mfx.FrameInfo.FrameRateExtN * _mfxBitStream.DecodeTimeStamp / 90000;
    if (_mfxBitStream.FrameType & MFX_FRAMETYPE_IDR)
        packet->flags = AV_PKT_FLAG_KEY;  // TODO: there exists a "corrupt" flag, pass to writer instead of failing and stop writing
      // NB! This is critcal to get sane output! It seems that DataLength is increased afte each encode operation,
      // and encode returns with DataOffset==0 if we forget to clear this field.
    _mfxBitStream.DataLength = 0;
    return packet;
}

EncodedPacket::Payload IntelVideoEncoder::Encode(const RawPacket& raw)
{
    if (_failed)
        throw std::logic_error("Intel encoder already failed.");

    EncodedPacket::Payload ep;

    auto t0 = std::chrono::system_clock::now();

    int surface_index = GetFreeSurfaceIndex();
    if (surface_index < 0) {
        _failed = true;
        throw std::runtime_error("IntelVideoEncoder: no free surfaces");
    }

    if (_mfxFrameAllocator.Lock(_mfxFrameAllocator.pthis, _pmfxSurfaces[surface_index]->Data.MemId, &_pmfxSurfaces[surface_index]->Data) < MFX_ERR_NONE) {
        _failed = true;
        throw std::runtime_error("MfxFrameAllocator::Lock");
    }

    switch (raw.frame->stream->pixel_format) {
    case AV_PIX_FMT_YUV420P: LoadRaw420Frame(_pmfxSurfaces[surface_index], raw.frame); break;
    case AV_PIX_FMT_GRAY8: LoadRaw400Frame(_pmfxSurfaces[surface_index], raw.frame); break;
    case AV_PIX_FMT_YUV422P10LE: LoadRaw422P10Frame(_pmfxSurfaces[surface_index], raw.frame); break;
    case AV_PIX_FMT_YUV422P: LoadRaw422Frame(_pmfxSurfaces[surface_index], raw.frame); break;
    default: throw std::logic_error("IntelVideoEncoder: unsupported frame type");
    }

    if (_mfxFrameAllocator.Unlock(_mfxFrameAllocator.pthis, _pmfxSurfaces[surface_index]->Data.MemId, &_pmfxSurfaces[surface_index]->Data) < MFX_ERR_NONE) {
        _failed = true;
        throw std::runtime_error("MfxFrameAllocator::Unlock");
    }

    _pmfxSurfaces[surface_index]->Data.TimeStamp = (uint64_t)90000 * raw.recording_length / _mfxVideoParam.mfx.FrameInfo.FrameRateExtN;
    mfxStatus status = EncodeFrameSync(_pmfxSurfaces[surface_index]);
    if (status == MFX_ERR_MORE_DATA) {
        ep.ok = true;
        return ep;
    }
    else if (status < MFX_ERR_NONE) {
        throw std::logic_error("IntelVideoEncoder::Encode: Unexpected return code from EncodeFrameSync");
    }

    // Encoder runs asynchronously with writing, so must copy the bitstream
    ep.packet = ExtractBitstream();

    auto td = std::chrono::system_clock::now() - t0;
    HAL_LOG(TRACE) << "Encoding took: " << std::chrono::duration_cast<std::chrono::milliseconds>(td).count();
    return ep;
}

EncodedPacket::Payload IntelVideoEncoder::Finalize()
{
    if (_failed)
        throw std::logic_error("Intel encoder already failed.");

    EncodedPacket::Payload ep;

    auto status = EncodeFrameSync(nullptr);
    switch (status) {
    case MFX_ERR_NONE: ep.packet = ExtractBitstream(); break;
    case MFX_ERR_MORE_DATA: ep.packet = nullptr; break;
    default: throw std::logic_error("IntelVideoEncoder::Finalize: unexpected return code from EncodeFrameSync");
    }

    return ep;
}

int IntelVideoEncoder::GetFreeSurfaceIndex()
{
    auto end = _pmfxSurfaces + _mfxFrameAllocResponse.NumFrameActual;
    auto it = std::find_if(_pmfxSurfaces, end, [](mfxFrameSurface1* s) { return !s->Data.Locked; });
    if (it == end)
        return MFX_ERR_NOT_FOUND;
    return it - _pmfxSurfaces;
}

// TODO: use SWS?
void IntelVideoEncoder::LoadRaw400Frame(mfxFrameSurface1* pSurface, VideoFrame_ptr frame)
{
    mfxU16 w, h, i, pitch;
    mfxU8* ptr;
    mfxFrameInfo* pInfo = &pSurface->Info;
    mfxFrameData* pData = &pSurface->Data;

    if (pInfo->CropH > 0 && pInfo->CropW > 0) {
        w = pInfo->CropW;
        h = pInfo->CropH;
    }
    else {
        w = pInfo->Width;
        h = pInfo->Height;
    }

    pitch = pData->Pitch;
    ptr = pData->Y + pInfo->CropX + pInfo->CropY * pData->Pitch;

    // read luminance plane
    for (i = 0; i < h; i++)
        memcpy(ptr + i * pitch, frame->plane[0] + i * frame->stride[0], w);

    // Set grayscale
    w /= 2;
    h /= 2;
    ptr = pData->UV + pInfo->CropX + (pInfo->CropY / 2) * pitch;
    memset(ptr, 128, w * h * 2);
}

// TODO: use SWS?
void IntelVideoEncoder::LoadRaw420Frame(mfxFrameSurface1* pSurface, VideoFrame_ptr frame)
{
    mfxU16 w, h, i, pitch;
    mfxU8* ptr;
    mfxFrameInfo* pInfo = &pSurface->Info;
    mfxFrameData* pData = &pSurface->Data;

    if (pInfo->CropH > 0 && pInfo->CropW > 0) {
        w = pInfo->CropW;
        h = pInfo->CropH;
    }
    else {
        w = pInfo->Width;
        h = pInfo->Height;
    }

    pitch = pData->Pitch;
    ptr = pData->Y + pInfo->CropX + pInfo->CropY * pData->Pitch;

    // read luminance plane
    for (i = 0; i < h; i++)
        memcpy(ptr + i * pitch, frame->plane[0] + i * frame->stride[0], w);

    w /= 2;
    h /= 2;
    ptr = pData->UV + pInfo->CropX + (pInfo->CropY / 2) * pitch;
    if (w > 2048)
        throw std::logic_error("IntelVideoEncoder: frame size too large");

    // load U interleaved NV12
    for (i = 0; i < h; ++i)
        for (int j = 0; j < w; ++j)
            ptr[i * pitch + j * 2 + 0] = *(char*)(frame->plane[1] + i * frame->stride[1] + j);

    // load Y interleaved NV12
    for (i = 0; i < h; ++i)
        for (int j = 0; j < w; ++j)
            ptr[i * pitch + j * 2 + 1] = *(char*)(frame->plane[2] + i * frame->stride[2] + j);
}

void IntelVideoEncoder::LoadRaw422P10Frame(mfxFrameSurface1* pSurface, VideoFrame_ptr frame)
{
    mfxU16 w, h, pitch;
    mfxFrameInfo* pInfo = &pSurface->Info;
    mfxFrameData* pData = &pSurface->Data;

    if (pInfo->CropH > 0 && pInfo->CropW > 0) {
        w = pInfo->CropW;
        h = pInfo->CropH;
    }
    else {
        w = pInfo->Width;
        h = pInfo->Height;
    }

    pitch = pData->Pitch;
    mfxU8* ptry = pData->Y + pInfo->CropX + pInfo->CropY * pData->Pitch;
    mfxU8* ptruv = pData->UV + pInfo->CropX + pInfo->CropY * pData->Pitch;

    // Convert from YUV422P10LE to NV12
    if (!(_sws = sws_getCachedContext(_sws, w, h, AV_PIX_FMT_YUV422P10LE, w, h, AV_PIX_FMT_NV12, SWS_FAST_BILINEAR, 0, 0, 0)))
        throw std::runtime_error("IntelVideoEncoder: sws_getCachedContext");

    uint8_t* dst[] = { ptry, ptruv, 0 };
    const int dststride[] = { pitch, pitch, 0 };
    sws_scale(_sws, frame->plane, frame->stride, 0, h, dst, dststride);
}

void IntelVideoEncoder::LoadRaw422Frame(mfxFrameSurface1* pSurface, VideoFrame_ptr frame)
{
    mfxU16 w, h, pitch;
    mfxFrameInfo* pInfo = &pSurface->Info;
    mfxFrameData* pData = &pSurface->Data;

    if (pInfo->CropH > 0 && pInfo->CropW > 0) {
        w = pInfo->CropW;
        h = pInfo->CropH;
    }
    else {
        w = pInfo->Width;
        h = pInfo->Height;
    }

    pitch = pData->Pitch;
    mfxU8* ptry = pData->Y + pInfo->CropX + pInfo->CropY * pData->Pitch;
    mfxU8* ptruv = pData->UV + pInfo->CropX + pInfo->CropY * pData->Pitch;

    // Convert from YUV422 to NV12
    if (!(_sws = sws_getCachedContext(_sws, w, h, AV_PIX_FMT_YUV422P, w, h, AV_PIX_FMT_NV12, SWS_FAST_BILINEAR, 0, 0, 0)))
        throw std::runtime_error("IntelVideoEncoder: sws_getCachedContext");

    uint8_t* dst[] = { ptry, ptruv, 0 };
    const int dststride[] = { pitch, pitch, 0 };
    sws_scale(_sws, frame->plane, frame->stride, 0, h, dst, dststride);
}

/////////////////////////////////////////////////////////////////////////////

class NullVideoEncoder : public AVCodecVideoEncoder
{
public:
    NullVideoEncoder(const VideoStream_ptr& stream, const config::OutputCodecPreset& params)
      : AVCodecVideoEncoder("NullVideoEncoder", params)
    {
        SetContextParameters(stream, params);
    }
    EncodedPacket::Payload Encode(const RawPacket&) override
    {
        return EncodedPacket::Payload{};
    }
    EncodedPacket::Payload Finalize() override
    {
        return EncodedPacket::Payload{};
    }
};

// FACTORIES ////////////////////////////////////////////////////////////////

using EncoderFactory = std::function<std::shared_ptr<AVCodecContextHolder>()>;

class AVCodecEncoderBody
{
    hal_logger_t _logger;
    config::OutputCodecPreset _params;
    VideoStream_ptr _stream;
    void (AVCodecEncoderBody::*_state)(const RawPacket&, AVCodecEncoderNode::output_ports_type&);
    std::shared_ptr<AVCodecContextHolder> _encoder[2];

    void Reset();
    void Waiting(const RawPacket&, AVCodecEncoderNode::output_ports_type&);
    void Writing(const RawPacket&, AVCodecEncoderNode::output_ports_type&);
    void Finalize(AVCodecEncoderNode::output_ports_type&, EncodedPacket::Stream);

public:
    AVCodecEncoderBody(VideoStream_ptr stream, const config::OutputCodecPreset& params);
    void operator()(const RawPacket& rp, AVCodecEncoderNode::output_ports_type& ports);
};

AVCodecEncoderBody::AVCodecEncoderBody(VideoStream_ptr stream, const config::OutputCodecPreset& params) :
    _logger(boost::log::keywords::channel = std::string("AVCodecEncoderBody/") + stream->name),
    _stream(stream),
    _params(params),
    _state(&AVCodecEncoderBody::Waiting)
{
    HAL_LOG(INFO) << "Created for stream " << stream->name;
}

void AVCodecEncoderBody::operator()(const RawPacket& rp, AVCodecEncoderNode::output_ports_type& ports)
{
    try {
        (this->*_state)(rp, ports);
    }
    catch (std::exception& e) {
        HAL_LOG(ERROR) << "Failed; no more output will be generated: " << e.what();
        if (_state != &AVCodecEncoderBody::Waiting) {   // Codec wasn't constructed, so don't send anything at all.
            EncodedPacket ep(rp);
            ep.payload[0].ok = ep.payload[1].ok = false;
            std::get<0>(ports).try_put(ep);
        }
        Reset();
    }
}

void AVCodecEncoderBody::Reset()
{
    _state = &AVCodecEncoderBody::Waiting;
    _encoder[0].reset();
    _encoder[1].reset();
}

void AVCodecEncoderBody::Waiting(const RawPacket& rp, AVCodecEncoderNode::output_ports_type& ports)
{
    if (rp.recording != RawPacket::new_file)
        return;
    if (_encoder[0] || _encoder[1])
        throw std::logic_error("AVCodecEncoderBody::Waiting: invalid state");

    HAL_LOG(INFO) << "Creating encoder; file=" << rp.frame->filename;
    
    if (_params.video_codec == AV_CODEC_ID_H264)
        _encoder[EncodedPacket::video] = std::make_shared<IntelVideoEncoder>(_stream, _params, false);
    else
        _encoder[EncodedPacket::video] = std::make_shared<AVCodecVideoEncoder>(_stream, _params);

    _encoder[EncodedPacket::audio] = std::make_shared<AVCodecAudioEncoder>(_stream, _params);

    _state = &AVCodecEncoderBody::Writing;
    (this->*_state)(rp, ports);
}

void AVCodecEncoderBody::Writing(const RawPacket& rp, AVCodecEncoderNode::output_ports_type& ports)
{
    if (!_encoder[0] || !_encoder[1])
        throw std::logic_error("AVCodecEncoderBody::Writing: invalid state");
    
    // Don't reinitialize encoder if filename changes during recording.
    if (rp.recording == RawPacket::off) {
        Finalize(ports, EncodedPacket::audio);
        Finalize(ports, EncodedPacket::video);
        Reset();
        return;
    }

    EncodedPacket ep(rp);
    ep.payload[EncodedPacket::audio] = _encoder[EncodedPacket::audio]->Encode(rp);
    ep.payload[EncodedPacket::video] = _encoder[EncodedPacket::video]->Encode(rp);
    ep.payload[EncodedPacket::audio].codec = _encoder[EncodedPacket::audio];
    ep.payload[EncodedPacket::video].codec = _encoder[EncodedPacket::video];
    std::get<0>(ports).try_put(ep);
}

void AVCodecEncoderBody::Finalize(AVCodecEncoderNode::output_ports_type& ports, EncodedPacket::Stream si)
{
    auto& encoder = _encoder[si];
    EncodedPacket ep;

    // NB! This assumes that audio is finalized BEFORE video. AVFormatWriter will stop writing as
    // soon as it receives packet with recording != on.
    do {
        ep.payload[si] = encoder->Finalize();
        ep.payload[si].codec = _encoder[si];
        if (si == EncodedPacket::audio || ep.payload->packet) ep.recording = RawPacket::on;
        else ep.recording = RawPacket::off;
        std::get<0>(ports).try_put(ep);
    } while (ep.payload[si].packet);
}

AVCodecEncoderNodeP MakeAVEncoderNode(tbb::flow::graph& g, VideoStream_ptr stream, const config::OutputCodecPreset& params)
{
    return AVCodecEncoderNodeP(new AVCodecEncoderNode(g, 1, AVCodecEncoderBody(stream, params)));
}

} // hal
