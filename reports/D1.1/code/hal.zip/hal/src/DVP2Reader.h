// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include "VideoTypes.h"
#include <vector>
#include <string>
#include <DVPCamera.h>

namespace hal
{

class DVP2Reader : public VideoStream
{
  int _dvp_index;
  dvpHandle _dvp_handle;
  std::chrono::microseconds _exposure;
  float _gain;
  int _trigger_count;

  template<typename F, typename... Args>
  void call_dvp(const char*, F, Args...);

  std::vector<dvpFormatSelection> GetSourceFormats();
  std::vector<dvpFormatSelection> GetTargetFormats();

  std::vector<dvpQuickRoi> GetResolutionPresets();
  unsigned SelectResolution();
  static unsigned SelectGray8Format(const std::vector<dvpFormatSelection>&);
  
  static dvpInt32 StreamCallback(dvpHandle, dvpStreamEvent, void*, dvpFrame*, void*);
  dvpInt32 OnFrameArrived(dvpStreamEvent event, dvpFrame* frame, void* buffer);

protected:
  void StartExternalSource() override;
  void StopExternalSource() override;
  void TriggerExternalSource() override;

public:
  DVP2Reader(RecordingObserver&, const config::WitnessCamera& camera, int index/*TODO: config options*/);
  ~DVP2Reader();

  void SetExposure(std::chrono::microseconds);
  std::chrono::microseconds GetExposure() const { return _exposure; }

  void SetGain(float);
  float GetGain() const { return _gain; }

  //! Returns a list of serial numbers for all connected cameras.
  static std::vector<std::string> Enumerate();
};

} // hal
