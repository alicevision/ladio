// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "GraphTypes.h"
#include "VideoTypes.h"
#include "FontManager.h"

namespace hal
{

#ifdef _WIN32
static const char* FONT_PATH = "C:\\Windows\\Fonts\\consola.ttf";
#else
static const char* FONT_PATH = "/usr/share/fonts/google-roboto-mono/RobotoMono-Regular.ttf";
#endif

class VideoOverlayBody
{
  std::shared_ptr<FontManager> _fontmgr;

public:
  VideoOverlayBody();
  VideoFrame_ptr operator()(const VideoFrame_ptr&);
};

VideoOverlayBody::VideoOverlayBody() :
  _fontmgr(new FontManager(FONT_PATH, 40, 75))
{ }

VideoFrame_ptr VideoOverlayBody::operator()(const VideoFrame_ptr& frame)
{
  if (frame->stream->pixel_format != AV_PIX_FMT_GRAY8) _fontmgr->OverlaySDIFrame(frame);
  else _fontmgr->OverlayWCFrame(frame);
  return frame;
}

/////////////////////////////////////////////////////////////////////////////

VideoOverlayNodeP MakeVideoOverlayNode(tbb::flow::graph& g)
{
  return VideoOverlayNodeP(new VideoOverlayNode(g, tbb::flow::unlimited, VideoOverlayBody()));
}

} // hal
