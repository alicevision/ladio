#pragma once
#include "ForwardDecls.h"

namespace hal
{
namespace arri
{
// Refer to "Metadata in the ALEXA white paper - for ALEXA SUP 8.0 - DRAFT - May 16th 2013"
// Note: Many fields defined in the above document have been changed to "reserved" in
// "Metadata for ALEXA SUP 11 / ALEXA 65 SUP 1.0 / AMIRA 2.0"
// In particular, recording state can be reliably inferred from these fields only on ALEXA.
// The code here is based on SUP11, EXCEPT for the record flag hack.
bool PopulateMetadata(const uint8_t* blob, VideoFrame* frame);

}

}