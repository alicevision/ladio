// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "V210Decoder.h"

namespace hal{

AVCodec *V210Decoder::codec = nullptr;

V210Decoder::V210Decoder() : _sws(0), _logger(boost::log::keywords::channel = "SDI")
{
    if (!codec && !(codec = avcodec_find_decoder(AV_CODEC_ID_V210)))
      throw std::runtime_error("V210 codec not found");
    
    av_init_packet(&_packet);
    _context = avcodec_alloc_context3(codec);
    _frame = av_frame_alloc();
    if (avcodec_open2(_context, codec, 0) < 0)
      throw std::runtime_error("avcodec_open2");
}

V210Decoder::~V210Decoder()
{
    avcodec_close(_context);
    avcodec_free_context(&_context);
    av_frame_free(&_frame);
    sws_freeContext(_sws);
}

bool V210Decoder::decodeFrame(uint8_t *data, size_t len, int width, int height)
{
    _packet.size = len;
    _packet.data = data;
    int got_picture;

    _context->width = width;
    _context->height = height;

    if (avcodec_decode_video2(_context, _frame, &got_picture, &_packet) < 0)
      throw std::runtime_error("avcodec_decode_video2");

    if (!got_picture) {
        HAL_LOG(DEBUG) << "V210Decoder: empty frame,skipping.";
        return false;
    }

    return true;
}
}