// (c) 2014-2016 Labo Mixedrealities AS
// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <signal.h>
#include <sstream>
#include <iomanip>
#ifndef _WIN32
#include <sys/mman.h>
#else
#include <malloc.h>
#endif

#include "GraphTypes.h"
#include "VideoTypes.h"
#include "Config.h"

extern "C"
{
#include <libavutil/error.h>
}

namespace hal
{

std::string to_string(const TimecodeTime& tc)
{
    char buf[24];
    timecode_time_to_string(buf, &tc);
    return std::string(buf);
}

std::string ffmpeg_error::GetErrorString(int av_err_code)
{
    char errstr[512];
    static_assert(sizeof(errstr) >= 2 * AV_ERROR_MAX_STRING_SIZE, "Static buffer too small.");
    return av_make_error_string(errstr, sizeof(errstr), av_err_code);
}

constexpr int VideoFrame::MAX_AUDIO_SAMPLES;
constexpr int VideoFrame::MAX_AUDIO_CHANNELS;

VideoFrame::VideoFrame(const VideoStream* stream)
{
  auto pixel_format = stream->pixel_format;
  auto width = stream->width;
  auto height = stream->height;
  
  size_t audio_size = MAX_AUDIO_SAMPLES * MAX_AUDIO_CHANNELS * 4; // 32 bit quantities
  _framesize = audio_size;  // NB: code below uses += to _framesize !

  // Set up picture frame planes.
  if (pixel_format == AV_PIX_FMT_YUV420P) {
    _framesize += (width * height * 2) + (128 * height);  // We allocate some extra memory for padding
    yuv_data = static_cast<unsigned char*>(mapalloc(_framesize));

    stride[0] = width;
    stride[1] = stride[2] = (width + 1) / 2;
    rows[0] = height;
    rows[1] = rows[2] = (height + 1) / 2;

    plane[0] = yuv_data;
    plane[1] = plane[0] + (stride[0] * rows[0]);
    plane[2] = plane[1] + (stride[1] * rows[1]);
  }
  else if (pixel_format == AV_PIX_FMT_GRAY8) {
    _framesize += (width * height) + (128 * height);  // We allocate some extra memory for padding
    yuv_data = static_cast<unsigned char*>(mapalloc(_framesize));

    stride[0] = width;
    stride[1] = stride[2] = 0;
    rows[0] = height;

    plane[0] = yuv_data;
    plane[1] = plane[2] = 0;
  }
  else if (pixel_format == AV_PIX_FMT_YUV422P) {
    _framesize += (width * height) * 2 + (128 * height);
    yuv_data = static_cast<unsigned char*>(mapalloc(_framesize));

    stride[0] = width;
    stride[1] = stride[2] = width / 2;
    rows[0] = height;
    rows[1] = rows[2] = height;

    plane[0] = yuv_data;
    plane[1] = plane[0] + (stride[0] * rows[0]);
    plane[2] = plane[1] + (stride[1] * rows[1]);
  }
  else if (pixel_format == AV_PIX_FMT_YUV422P10LE) {
    _framesize += width * height * 2 * sizeof(uint16_t) + (128 * height);
    yuv_data = static_cast<unsigned char*>(mapalloc(_framesize));

    stride[0] = width * 2;
    stride[1] = stride[2] = width;
    rows[0] = rows[1] = rows[2] = height;

    plane[0] = reinterpret_cast<uint8_t *>(yuv_data);
    plane[1] = plane[0] + (stride[0] * rows[0]);
    plane[2] = plane[1] + (stride[1] * rows[1]);
  }
  else {
    throw std::invalid_argument("VideoFrame: pixel_format");
  }

  // Set up audio frame planes.  Storage is allocated in one contiguous chunk with picture data.
  audio_plane[0] = yuv_data + (_framesize - audio_size);
  for (int i = 1; i < MAX_AUDIO_CHANNELS; ++i)
    audio_plane[i] = audio_plane[i - 1] + (MAX_AUDIO_SAMPLES * 4);
}

VideoFrame::~VideoFrame()
{
  mapfree(yuv_data, _framesize);
}

void* VideoFrame::mapalloc(size_t sz)
{
#ifndef _WIN32
  const size_t szext = (2 + (sz - 1) / PAGESIZE + 1) * PAGESIZE;

  char *base = static_cast<char*>(mmap(0, szext, PROT_READ | PROT_WRITE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0));
  char *end = base + (szext - PAGESIZE);

  if (base == MAP_FAILED)
    throw std::bad_alloc();

  mprotect(base, PAGESIZE, PROT_NONE);
  mprotect(end, PAGESIZE, PROT_NONE);

  // Align end of the returned buffer with the start of the redzone
  assert(end - sz >= base + PAGESIZE);
  return end - sz;
#else
  void* ret = _aligned_malloc(sz, PAGESIZE);
  if (!ret)
      throw std::bad_alloc();
  return ret;
#endif
}

void VideoFrame::mapfree(void *ptr, size_t sz)
{
#ifndef _WIN32
  const size_t szext = (2 + (sz - 1) / PAGESIZE + 1) * PAGESIZE;
  char *base = static_cast<char*>(ptr) - PAGESIZE;
  munmap(base, szext);
#else
  _aligned_free(ptr);
#endif
}

/////////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////////////////
// Stream frame allocation/queue management: When a preallocated frame is popped,
// its shared_ptr deleter remembers the queue it was taken from, so upon freeing,
// it is placed back into the originating queue.
// Supports migration of frames between queues: a popped frame can be put into
// a queue other than its creator, yet it will be pushed back to the creator
// upon destruction.
//
// Destruction of frames is tricky: when FrameQueue dtor runs, its shared_ptr
// refcount has reached 0, so locking the weak_ptr will return nullptr.  Therefore,
// running the container's dtor will also free the allocated frames when calling
// the provided frame_deleter.

void VideoStream::frame_deleter::operator()(VideoFrame* frame)
{
  auto p = owner.lock();
  if (p) p->push(VideoFrame_ptr(frame, frame_deleter(p)));
  else delete frame;
}

VideoStream::VideoStream(RecordingObserver& recording_observer, const config::Camera& camera) :
  _recording_observer(recording_observer),
  _unused_frames_q(std::make_shared<FrameQueue>()),
  _ord(0),
  _trigger_frame(-1),
  _running(false),
  _frame_arrival_acc(boost::accumulators::tag::rolling_mean::window_size = 25),
  _frame_latency_acc(boost::accumulators::tag::rolling_mean::window_size = 25),
  _logger(boost::log::keywords::channel = std::string("VideoStream/") + camera.name),
  name(camera.name),
  pixel_format(camera.input_pixel_format),
  width(camera.width),
  height(camera.height),
  fps(Config->fps),
  tc_frame_offset(camera.tc_offset),
  strict(camera.strict),
  trigger_master(camera.trigger_master),
  sample_format(camera.sample_format),
  channel_count(camera.channel_count),
  sample_rate(camera.sample_rate)
{
    HAL_LOG(INFO) << "Created.";
    if (name.empty() || pixel_format < 0 || width < 0 || height < 0 || fps < 0 || sample_format < 0 || sample_rate < 0 || channel_count < 0)
        throw std::logic_error("VideoStream: not initialized");
    if (trigger_master && tc_frame_offset)
        throw std::invalid_argument("VideoStream: invalid tc_frame_offset (cannot be set for trigger master)");
    if (tc_frame_offset < 0)
        throw std::invalid_argument("VideoStream: tc_frame_offset < 0");
    for (int i = 0; i < Config->buffer_size; ++i)
        _unused_frames_q->push(VideoFrame_ptr(new VideoFrame(this), frame_deleter(_unused_frames_q)));
}

VideoStream::~VideoStream()
{
    HAL_LOG(INFO) << "Destroyed.";
}

VideoFrame_ptr VideoStream::PopUnusedFrame()
{
    VideoFrame_ptr frame = nullptr;
    if (!_unused_frames_q->try_pop(frame))
        throw std::runtime_error(std::string("No empty frames for stream ") + this->name);
    if (!frame->stream)
        frame->stream = shared_from_this();
    else if (frame->stream.get() != this)
        throw std::logic_error("invalid frame owner");
    return frame;
}

void VideoStream::PushRawFrame(VideoFrame_ptr frame)
{
  using namespace std::chrono;

  UpdateArrivalStatistics();
  frame->ord = _ord++;
  frame->empty = false;
  frame->timestamp = duration_cast<milliseconds>(_last_arrival_time.time_since_epoch()).count();
  _trigger_frame = -1;
  _recording_observer.PushFrame(frame);
}

void VideoStream::PushEmptyFrame(VideoFrame_ptr frame)
{
  using namespace std::chrono;
  
  UpdateArrivalStatistics();
  frame->ord = _ord++;
  frame->empty = true;
  frame->timestamp = duration_cast<milliseconds>(_last_arrival_time.time_since_epoch()).count();
  frame->num_audio_samples = 0;

  // Add blank frame text
  if (this->pixel_format == AV_PIX_FMT_YUV422P10LE) {
    for (int i = 0; i < this->height; ++i) {
      memset(frame->plane[0] + i * frame->stride[0], 0, frame->stride[0]);
      for (int j = 0; j < frame->stride[1]; j += 2) {
        *(uint16_t*)&frame->plane[1][i * frame->stride[1] + j] = 512;
        *(uint16_t*)&frame->plane[2][i * frame->stride[2] + j] = 512;
      }
    }
    //_stream->_fontmgr->DrawText(700, _stream->height/ 2, "SDI Stream Unavailable", frame);
  }
  else {
    HAL_LOG(ERROR) << "Unsupported pixel_format";
  }
  HAL_LOG(TRACE) << "Emitting BLANK frame";
  _recording_observer.PushFrame(frame);
  _trigger_frame = -1;
}

void VideoStream::UpdateArrivalStatistics()
{
    using namespace std::chrono;
    using namespace boost::accumulators;

    auto now = std::chrono::system_clock::now();
    if (_last_arrival_time != std::chrono::system_clock::time_point()) {
        _frame_arrival_acc(duration_cast<milliseconds>(now - _last_arrival_time).count());
        _frame_latency_acc(duration_cast<milliseconds>(now - _last_trigger_time).count());
    }
    _last_arrival_time = now;

    if (_ord % 25 == 0) {
        HAL_LOG(INFO) << "Inter-frame arrival times over 25 frames: mean=" << rolling_mean(_frame_arrival_acc);
        HAL_LOG(INFO) << "Frame trigger->delivery latency times over 25 frames: mean=" << rolling_mean(_frame_latency_acc);
    }
}

void VideoStream::Start()
{
  if (_running)
    throw std::logic_error("VideoStream: already started");
  _running = true;
  StartExternalSource();
}

void VideoStream::Stop()
{
  if (!_running)
    throw std::logic_error("VideoStream: already stopped");
  StopExternalSource();
  _running = false;
}

bool VideoStream::Trigger(int32_t trigger_frame)
{
    if (trigger_master)
        throw std::logic_error("VideoStream: cannot trigger master.");
    if (trigger_frame < 0)
        throw std::invalid_argument("VideoStream: trigger_frame<0");
    if (_trigger_frame >= 0) {
        HAL_LOG(ERROR) << "Trigger: previous frame not arrived, ignoring; pending_trigger=" << _trigger_frame;
        return false;
    }
    else {
        _trigger_frame = _ord = trigger_frame;
	HAL_LOG(TRACE) << "Triggering; ord=" << trigger_frame;
        TriggerExternalSource();
        _last_trigger_time = std::chrono::system_clock::now();
    }
    return true;
}

void VideoStream::TriggerExternalSource()
{
    throw std::logic_error("External trigger not supported");
}

} //hal
