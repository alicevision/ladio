#include "MetadataUtilities.h"
#include "VideoTypes.h"
#include "../contrib/json.hpp"

namespace hal
{
namespace arri 
{

template<typename T>
static T GetMetaField(const uint8_t* blob, size_t offset)
{
    T t;
    memcpy(&t, blob + offset, sizeof(T));
    return t;
}

static std::string GetMetaField(const uint8_t* blob, size_t offset, size_t length)
{
    std::string t(length + 1, '\x00');
    memcpy(&t[0], blob + offset, length);
    return t;
}

template<typename T = uint32_t>
static nlohmann::json GetMetaArray(const uint8_t* blob, size_t b_offset, size_t e_offset)
{
    if ((e_offset - b_offset) % 4 || e_offset <= b_offset)
        throw std::invalid_argument("ArriParser: invalid array offfsets");
    auto j = nlohmann::json::array();
    for (; b_offset < e_offset; b_offset += sizeof(T))
        j.push_back(GetMetaField<T>(blob, b_offset));
    return j;
}

// Refer to "Metadata in the ALEXA white paper - for ALEXA SUP 8.0 - DRAFT - May 16th 2013"
// Note: Many fields defined in the above document have been changed to "reserved" in
// "Metadata for ALEXA SUP 11 / ALEXA 65 SUP 1.0 / AMIRA 2.0"
// In particular, recording state can be reliably inferred from these fields only on ALEXA.
// The code here is based on SUP11, EXCEPT for the record flag hack.
bool PopulateMetadata(const uint8_t * blob, VideoFrame* frame)
{
    if (!blob) {
        HAL_GLOBAL_LOG(INFO) << "arri::PopulateMetaData blob ptr was nullptr";
        return false;
    }

    using namespace nlohmann;
   
    if (GetMetaField<uint32_t>(blob, 0) != 0x49525241)  // 'ARRI' in little-endian
        return false;

    auto& arri = frame->parsed_metadata["arri"] = json::object();

    arri["image-width"] = GetMetaField<uint32_t>(blob, 0x14);
    arri["image-height"] = GetMetaField<uint32_t>(blob, 0x18);
    arri["active-image-left"] = GetMetaField<uint32_t>(blob, 0x24);
    arri["active-image-top"] = GetMetaField<uint32_t>(blob, 0x28);
    arri["active-image-width"] = GetMetaField<uint32_t>(blob, 0x2C);
    arri["active-image-height"] = GetMetaField<uint32_t>(blob, 0x30);
    arri["full-image-width"] = GetMetaField<uint32_t>(blob, 0x3C);
    arri["full-image-height"] = GetMetaField<uint32_t>(blob, 0x40);
    arri["color-processing-version"] = GetMetaField<uint32_t>(blob, 0x58);
    arri["white-balance"] = GetMetaField<uint32_t>(blob, 0x5C);
    arri["white-balance-cc"] = GetMetaField<uint32_t>(blob, 0x60);
    arri["white-balance-factor-r"] = GetMetaField<uint32_t>(blob, 0x64);
    arri["white-balance-factor-g"] = GetMetaField<uint32_t>(blob, 0x68);
    arri["white-balance-factor-b"] = GetMetaField<uint32_t>(blob, 0x6C);
    arri["white-balance-applied"] = GetMetaField<uint32_t>(blob, 0x70);
    arri["exposure-index-asa"] = GetMetaField<uint32_t>(blob, 0x74);
    arri["target-color-space"] = GetMetaField<uint32_t>(blob, 0xBC);
    arri["sharpness"] = GetMetaField<uint32_t>(blob, 0xC0);
    arri["lens-squeeze-factor"] = GetMetaField<uint32_t>(blob, 0xC4);
    arri["image-orientation"] = GetMetaField<uint32_t>(blob, 0xC8);
    arri["look-file"] = GetMetaField(blob, 0xCC, 0xEC - 0xCC);
    arri["look-lut-mode"] = GetMetaField<uint32_t>(blob, 0xEC);
    arri["look-lut-offset"] = GetMetaField<uint32_t>(blob, 0xF0);
    arri["look-lut-size"] = GetMetaField<uint32_t>(blob, 0xF4);
    arri["look-saturation"] = GetMetaField<uint32_t>(blob, 0xFC);
    arri["cdl-slope-rgb"] = GetMetaArray(blob, 0x100, 0x10C);
    arri["cdl-offset-rgb"] = GetMetaArray(blob, 0x10C, 0x118);
    arri["cdl-power-rgb"] = GetMetaArray(blob, 0x118, 0x124);
    arri["printer-lights-rgb"] = GetMetaArray<uint8_t>(blob, 0x124, 0x130);
    arri["cdl-mode"] = GetMetaField<uint32_t>(blob, 0x130);
    arri["image-data-checksum"] = GetMetaField<uint32_t>(blob, 0x138);
    // BEGIN SUP8/undocumented
    arri["camera-type-id"] = GetMetaField<uint32_t>(blob, 0x164);
    arri["camera-revision"] = GetMetaField<uint32_t>(blob, 0x168);
    arri["firmware-version"] = GetMetaField<uint32_t>(blob, 0x16C);
    // END SUP8/undocumented
    arri["camera-serial-number"] = GetMetaField(blob, 0x170, 4);
    arri["camera-id"] = GetMetaField(blob, 0x174, 4);
    arri["camera-index"] = GetMetaField<uint32_t>(blob, 0x178);
    arri["sys-image-creation-date"] = GetMetaField<uint32_t>(blob, 0x17C);
    arri["sys-image-creation-time"] = GetMetaField<uint32_t>(blob, 0x180);
    arri["sys-image-tz-offset"] = GetMetaField<uint32_t>(blob, 0x184);
    arri["sys-image-tz-dst"] = GetMetaField<uint32_t>(blob, 0x188);
    arri["exposure-time"] = GetMetaField<uint32_t>(blob, 0x18C);
    arri["shutter-angle"] = GetMetaField<uint32_t>(blob, 0x190);
    arri["speed-ramp-duration"] = GetMetaField<uint32_t>(blob, 0x194);
    arri["speed-ramp-start-frame"] = GetMetaField<uint32_t>(blob, 0x198);
    arri["speed-ramp-end-frame"] = GetMetaField<uint32_t>(blob, 0x19C);
    arri["sensor-fps"] = GetMetaField<uint32_t>(blob, 0x1A0);
    arri["project-fps"] = GetMetaField<uint32_t>(blob, 0x1A4);
    arri["master-tc"] = GetMetaField<uint32_t>(blob, 0x1A8);
    arri["master-tc-frame-count"] = GetMetaField<uint32_t>(blob, 0x1AC);
    arri["master-tc-time-base"] = GetMetaField<uint32_t>(blob, 0x1B0);
    arri["master-tc-user-info"] = GetMetaField<uint32_t>(blob, 0x1B4);
    // BEGIN SUP8/undocumented
    arri["ext-ltc-free-run"] = GetMetaArray(blob, 0x1B8, 0x1C8);
    arri["ext-vitc-free-run"] = GetMetaArray(blob, 0x1C8, 0x1D8);
    arri["int-free-run-tod-tc"] = GetMetaArray(blob, 0x1D8, 0x1E8);
    arri["int-free-run-user-defined-tc"] = GetMetaArray(blob, 0x1E8, 0x1F8);
    arri["rec-run-edge-code-tc"] = GetMetaArray(blob, 0x1F8, 0x208);
    arri["rec-run-clip-code-tc"] = GetMetaArray(blob, 0x208, 0x218);
    arri["rec-run-regen-tc"] = GetMetaArray(blob, 0x218, 0x228);
    arri["tc-reserved"] = GetMetaArray(blob, 0x228, 0x268);
    // END SUP8/undocumented
    arri["magazine-serial-number"] = GetMetaField<uint64_t>(blob, 0x268);
    arri["smpte-umid"] = GetMetaField(blob, 0x27C, 32);
    arri["mirror-shutter-running"] = (GetMetaField<uint32_t>(blob, 0x2C4) & 1) != 0;
    arri["vari-frame-duplicate"] = (GetMetaField<uint32_t>(blob, 0x2C4) & 2) != 0;
    arri["uuid"] = GetMetaField(blob, 0x2D0, 16);
    arri["camera-sup-name"] = GetMetaField(blob, 0x2E0, 24);
    arri["camera-model"] = GetMetaField(blob, 0x2F8, 20);
    arri["camera-product"] = GetMetaField<uint16_t>(blob, 0x30C);
    arri["camera-sub-product"] = GetMetaField<uint16_t>(blob, 0x30E);
    arri["lens-distance-unit"] = GetMetaField<uint32_t>(blob, 0x374);
    arri["lens-focus-distance"] = GetMetaField<uint32_t>(blob, 0x378);
    arri["lens-focal-length"] = GetMetaField<uint32_t>(blob, 0x37C);
    arri["lens-serial-number"] = GetMetaField<uint32_t>(blob, 0x380);
    arri["lens-iris"] = GetMetaField<uint32_t>(blob, 0x384);
    arri["nd-filter-type"] = GetMetaField<uint16_t>(blob, 0x388);
    arri["nd-filter-density"] = GetMetaField<uint16_t>(blob, 0x38A);
    arri["lens-model"] = GetMetaField(blob, 0x398, 32);
    arri["raw-encoder-focus-raw-lds"] = GetMetaField<uint16_t>(blob, 0x3B8);
    arri["raw-encoder-focus-raw-motor"] = GetMetaField<uint16_t>(blob, 0x3BA);
    arri["raw-encoder-focal-raw-lds"] = GetMetaField<uint16_t>(blob, 0x3BC);
    arri["raw-encoder-focal-raw-motor"] = GetMetaField<uint16_t>(blob, 0x3BE);
    arri["raw-encoder-iris-raw-lds"] = GetMetaField<uint16_t>(blob, 0x3C0);
    arri["raw-encoder-iris-raw-motor"] = GetMetaField<uint16_t>(blob, 0x3C2);
    arri["encoder-lim-focus-lds-min"] = GetMetaField<uint16_t>(blob, 0x3C4);
    arri["encoder-lim-focus-lds-max"] = GetMetaField<uint16_t>(blob, 0x3C6);
    arri["encoder-lim-focal-lds-min"] = GetMetaField<uint16_t>(blob, 0x3C8);
    arri["encoder-lim-focal-lds-max"] = GetMetaField<uint16_t>(blob, 0x3CA);
    arri["encoder-lim-iris-lds-min"] = GetMetaField<uint16_t>(blob, 0x3CC);
    arri["encoder-lim-iris-lds-max"] = GetMetaField<uint16_t>(blob, 0x3CE);
    arri["encoder-lim-focus-motor-min"] = GetMetaField<uint16_t>(blob, 0x3D0);
    arri["encoder-lim-focus-motor-max"] = GetMetaField<uint16_t>(blob, 0x3D2);
    arri["encoder-lim-focal-motor-min"] = GetMetaField<uint16_t>(blob, 0x3D4);
    arri["encoder-lim-focal-motor-max"] = GetMetaField<uint16_t>(blob, 0x3D6);
    arri["encoder-lim-iris-motor-min"] = GetMetaField<uint16_t>(blob, 0x3D8);
    arri["encoder-lim-iris-motor-max"] = GetMetaField<uint16_t>(blob, 0x3DA);
    arri["lds-lag-type"] = GetMetaField<uint8_t>(blob, 0x3DC);
    arri["lds-lag-value"] = GetMetaField<uint8_t>(blob, 0x3DD);
    arri["camera-tilt"] = GetMetaField<uint32_t>(blob, 0x45C);
    arri["camera-roll"] = GetMetaField<uint32_t>(blob, 0x460);
    arri["master-slave-setup"] = GetMetaField<uint32_t>(blob, 0x464);
    arri["3d-eye"] = GetMetaField<uint32_t>(blob, 0x468);
    arri["circle-take"] = GetMetaField<uint32_t>(blob, 0x4F4);  // Only for Alexa XT
    arri["reel"] = GetMetaField(blob, 0x4F8, 8);
    arri["scene"] = GetMetaField(blob, 0x500, 16);
    arri["take"] = GetMetaField(blob, 0x510, 16);
    // director, cinematographer, production, company omitted
    arri["location-user-info"] = GetMetaField(blob, 0x598, 256);
    arri["clip-name"] = GetMetaField(blob, 0x698, 24);
    arri["sound-roll"] = GetMetaField(blob, 0x74C, 32);
    // "Frame line info" omitted

    return true;
}

} //arri

}//hal
