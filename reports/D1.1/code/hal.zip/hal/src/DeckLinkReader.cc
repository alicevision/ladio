// (c) 2014-2016 Labo Mixedrealities AS
// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <memory>
#include <vector>
#include <atomic>
#include "Config.h"
#include "DeckLinkReader.h"
#include "V210Decoder.h"
#include "MetadataUtilities.h"

extern "C" {
#include <libswscale/swscale.h>
#include <libavcodec/avcodec.h>
#include <stdlib.h>
}

#include <nmmintrin.h>

#ifdef _WIN32
#include <objbase.h>
#include "DeckLinkAPI_h.h"
#else
#include "DeckLinkAPI.h"
#endif

#undef PixelFormat
#undef ERROR

namespace hal
{

class DeckLinkReaderImpl : public DeckLinkReader, public IDeckLinkInputCallback
{
  // Capture delegate
  std::atomic<unsigned> _refcount;
  std::unique_ptr<V210Decoder> _v210dec;
  struct SwsContext *_sws;
  bool _flowing;

  virtual HRESULT STDMETHODCALLTYPE QueryInterface(REFIID iid, LPVOID *ppv)
  {
    return E_NOINTERFACE;
  }
  virtual ULONG STDMETHODCALLTYPE AddRef(void)
  {
    return ++_refcount;
  }
  virtual ULONG STDMETHODCALLTYPE Release(void)
  {
    unsigned refcount = --_refcount;
    if (!refcount)
      delete this;
    return refcount;
  }
  virtual HRESULT STDMETHODCALLTYPE VideoInputFormatChanged(BMDVideoInputFormatChangedEvents, IDeckLinkDisplayMode *, BMDDetectedVideoInputFormatFlags)
  {
    return S_OK;
  }
  virtual HRESULT STDMETHODCALLTYPE VideoInputFrameArrived(IDeckLinkVideoInputFrame *, IDeckLinkAudioInputPacket *);

  IDeckLink *deckLink;
  IDeckLinkInput *deckLinkInput;

  // MediaReader.
  bool _running;
  void StartExternalSource() override;
  void StopExternalSource() override;
  
public:
  DeckLinkReaderImpl(RecordingObserver& recording_observer, const config::Camera& camera, std::unique_ptr<GenericParser> meta_parser);
  ~DeckLinkReaderImpl();
};

DeckLinkReaderImpl::DeckLinkReaderImpl(RecordingObserver& recording_observer, const config::Camera& camera, std::unique_ptr<GenericParser> meta_parser) :
  DeckLinkReader(recording_observer, camera, std::move(meta_parser)),
  _refcount(0),
  _v210dec(V210Decoder::create()),
  _sws(nullptr),
  _flowing(false),
  _running(false)
{
  HAL_LOG(INFO) << "DeckLinkReaderImpl started.";

  BMDDisplayMode displayMode;
  switch (this->fps)
  {
  case 24: displayMode = bmdModeHD1080p24; break;
  case 25: displayMode = bmdModeHD1080p25; break;
  case 30: displayMode = bmdModeHD1080p30; break;
  default: throw std::invalid_argument("DeckLinkReaderImpl: unsupported framerate");
  }

  BMDPixelFormat pixelFormat;
  switch (this->pixel_format)
  {
  case AV_PIX_FMT_YUV422P:
    HAL_LOG(INFO) << "Using 8-bit pixel format";
    pixelFormat = bmdFormat8BitYUV;
    break;
  case AV_PIX_FMT_YUV422P10LE:
    HAL_LOG(INFO) << "Using 10-bit pixel format";
    pixelFormat = bmdFormat10BitYUV;
    break;
  default:
    throw std::invalid_argument("DeckLinkReaderImpl: invalid pixel format");
  }

#ifndef _WIN32
  IDeckLinkIterator *deckLinkIterator = CreateDeckLinkIteratorInstance();
#else
  IDeckLinkIterator *deckLinkIterator = nullptr;
  throw std::logic_error("DeckLink not implemented for Windows");
#endif
  if (deckLinkIterator->Next(&deckLink) != S_OK)  // Use the first instance
    throw std::runtime_error("DeckLinkReaderImpl: no DeckLink card found");
  HAL_LOG(INFO) << "Found DeckLink SDI Card.";

  if (deckLink->QueryInterface(IID_IDeckLinkInput, (void **)&deckLinkInput) != S_OK)
    throw std::runtime_error("DeckLinkReaderImpl: IDeckLinkInput interface not supported");
  if (deckLinkInput->EnableVideoInput(displayMode, pixelFormat, 0) != S_OK)
    throw std::runtime_error("DeckLinkReaderImpl: Failed to enable video input.");
  if (this->sample_format != AV_SAMPLE_FMT_S16 || this->channel_count != 2 || this->sample_rate != 48000)
    throw std::invalid_argument("Unsupported audio format.");
  if (deckLinkInput->EnableAudioInput(bmdAudioSampleRate48kHz, bmdAudioSampleType16bitInteger, this->channel_count) != S_OK)
    throw std::runtime_error("Failed to enable audio input (2-channel, 16bit @ 48kHz)");
}

DeckLinkReaderImpl::~DeckLinkReaderImpl()
{
  sws_freeContext(_sws);
}

void DeckLinkReaderImpl::StartExternalSource()
{
  if (_running)
    throw std::logic_error("DeckLinkReaderImpl: already running");

  deckLinkInput->SetCallback(this);
  if (deckLinkInput->StartStreams() != S_OK)
    throw std::runtime_error("DeckLinkReaderImpl: failed to start streaming.");

  _running = true;
}

void DeckLinkReaderImpl::StopExternalSource()
{
  deckLinkInput->StopStreams();
}

HRESULT DeckLinkReaderImpl::VideoInputFrameArrived(IDeckLinkVideoInputFrame *videoFrame, IDeckLinkAudioInputPacket *audioFrame)
{
  void *frameBytes = NULL;
  void *audioBytes = NULL;
  int num_audio_samples = 0;

  // Get an available VideoFrame
  VideoFrame_ptr frame = this->PopUnusedFrame();
  if (!frame) {
    HAL_LOG(ERROR) << "No empty frames.";
    return S_OK;
  }

  if (videoFrame) {
    if (videoFrame->GetFlags() & bmdFrameHasNoInputSource) {
      HAL_LOG(DEBUG) << "Received empty frame";
      if (_flowing) {
        HAL_LOG(WARNING) << "SDI Stream lost.";
        _flowing = false;
      }
      PushEmptyFrame(frame);
      return S_OK;
    }
    else  if (!_flowing) {
      HAL_LOG(INFO) << "SDI Stream acquired.";
      _flowing = true;
    }
  }

  // Get audio
  if (audioFrame) {
    audioFrame->GetBytes(&audioBytes);
    num_audio_samples = audioFrame->GetSampleFrameCount();
  }


  // Add audio packets to the VideoFrame
  if (num_audio_samples < 0 || (2 * num_audio_samples) > VideoFrame::MAX_AUDIO_SAMPLES) {
    HAL_LOG(WARNING) << "discarding audio samples; invalid number: " << num_audio_samples;
    num_audio_samples = 0;
  }

  memcpy(frame->audio_plane[0], audioBytes, 2 * num_audio_samples * sizeof(int16_t));
  frame->num_audio_samples = num_audio_samples;

  // Get video
  videoFrame->GetBytes(&frameBytes);

  if (this->pixel_format == AV_PIX_FMT_YUV422P) { // Decode UYVY to target color space
    int w = videoFrame->GetWidth();
    int h = videoFrame->GetHeight();
    _sws = sws_getCachedContext(_sws, w, h, AV_PIX_FMT_UYVY422, w, h, this->pixel_format, SWS_FAST_BILINEAR, 0, 0, 0);
    uint8_t *src[] = { (uint8_t *)frameBytes, 0, 0 };
    const int srcstride[] = { (const int)videoFrame->GetRowBytes(), 0, 0 };
    sws_scale(_sws, src, srcstride, 0, h, frame->plane, frame->stride);
  }
  else if (this->pixel_format == AV_PIX_FMT_YUV422P10LE) { // Decode V210 to AV_PIX_FMT_YUV422P10LE format
    size_t len = videoFrame->GetRowBytes() * videoFrame->GetHeight();
    _v210dec->decodeFrame((uint8_t*)frameBytes, len, videoFrame->GetWidth(), videoFrame->GetHeight());

    // XXX: This should be made zero copy
    memcpy(frame->plane[0], boost::asio::buffer_cast<const uint8_t*>(_v210dec->rawPixels(0)), boost::asio::buffer_size(_v210dec->rawPixels(0)));
    memcpy(frame->plane[1], boost::asio::buffer_cast<const uint8_t*>(_v210dec->rawPixels(1)), boost::asio::buffer_size(_v210dec->rawPixels(1)));
    memcpy(frame->plane[2], boost::asio::buffer_cast<const uint8_t*>(_v210dec->rawPixels(2)), boost::asio::buffer_size(_v210dec->rawPixels(2)));
  }
  else {
    throw std::logic_error("Invalid pixel format");
  }

  _meta_parser->Parse(videoFrame, frame);
  PushRawFrame(frame);
  return S_OK;
}

/////////////////////////////////////////////////////////////////////////////

IDeckLinkTimecode* DeckLinkReader::GenericParser::ParseTimecode(IDeckLinkVideoInputFrame* vf, VideoFrame_ptr frame)
{
  IDeckLinkTimecode *timecode;
  if (vf->GetTimecode(bmdTimecodeRP188Any, &timecode) != S_OK) {
    HAL_LOG(WARNING) << "Failed to get RP188 timecode";
    return nullptr;
  }

  uint8_t h, m, s, f;
  timecode->GetComponents(&h, &m, &s, &f);

  frame->timecode.hour = h;
  frame->timecode.minute = m;
  frame->timecode.second = s;
  frame->timecode.frame = f;
  frame->timecode.subframe = 0;

  return timecode;
}

void DeckLinkReader::GenericParser::Parse(IDeckLinkVideoInputFrame* vf, VideoFrame_ptr frame)
{
  frame->record_flag = false;
  auto timecode = ParseTimecode(vf, frame);
  if (timecode)
    timecode->Release();
}

/////////////////////////////////////////////////////////////////////////////

class RedParser : public DeckLinkReader::GenericParser
{
  // RED starts delivering reliable SDI data only at the 3rd frame after record start.
  static constexpr int RECORD_DELAY_FRAMES = 3;
  int _letter, _reel, _clip, _month, _day, _wld1, _wld2;
  int _recording_length;
  
public:
  RedParser() : GenericParser("RedParser"), _recording_length(0)
  {}
  void Parse(IDeckLinkVideoInputFrame*, VideoFrame_ptr) override;
};

void RedParser::Parse(IDeckLinkVideoInputFrame* vf, VideoFrame_ptr frame)
{
  frame->record_flag = false;
  auto timecode = ParseTimecode(vf, frame);
  if (!timecode)
    return;

  BMDTimecodeUserBits userbits;
  timecode->GetTimecodeUserBits(&userbits);
  timecode->Release();

  // NB: RED documents metadata layout in HANC, but not in userbits.
  // Userbits layout has been reverse-engineered by Haavard.

  uint8_t *buf = (uint8_t *)&userbits;

  {
    bool sdi_record_flag = buf[0] & 0x08;
    if (!sdi_record_flag) {
        frame->record_flag = false;
        _recording_length = 0;
    }
    else {
      frame->record_flag = _recording_length++ > 2;
    }
  }

  // Get metadata indicator. Inverted every frame.
  if ((buf[2] & 0x1) == 0) {
    // Camera letter
    {
      uint8_t cl = (buf[2] & 0x8) >> 3;
      uint8_t caml = (buf[3] & 0xf0) >> 4;
      _letter = 'A' + caml + (cl << 4);
    }

    // Reel number
    {
      uint8_t reel1 = (buf[0] & 0xf0) >> 4;
      uint8_t reel10 = (buf[1] & 0x0f);
      uint8_t reel100 = (buf[1] & 0xf0) >> 4;
      _reel = reel100 * 100 + reel10 * 10 + reel1;
    }

    // Date
    {
      uint8_t month = (buf[2] & 0xf0) >> 4;
      uint8_t dayn = (buf[3] & 0x0f);
      uint8_t dn = (buf[2] & 0x04) >> 2;
      _month = month;
      _day = dayn + (dn << 4);
    }
  }
  else {
    // Clip number
    {
      uint8_t clip1 = (buf[0] & 0xf0) >> 4;
      uint8_t clip10 = (buf[1] & 0x0f);
      uint8_t clip100 = (buf[1] & 0xf0) >> 4;
      _clip = clip100 * 100 + clip10 * 10 + clip1;
    }

    // Random characters
    {
      uint8_t wld1 = (buf[3] & 0xf0) >> 4;
      uint8_t aw1 = (buf[2] & 0xc0) >> 6;
      wld1 |= (aw1 << 4);
      if (wld1 < 26) _wld1 = 'A' + wld1;
      else _wld1 = '0' + wld1 - 26;

      uint8_t wld2 = (buf[3] & 0x0f);
      uint8_t aw2 = (buf[2] & 0x30) >> 4;
      wld2 |= (aw2 << 4);
      if (wld2 < 26) _wld2 = 'A' + wld2;
      else _wld2 = '0' + wld2 - 26;
    }
  }

  char filename[256];
  sprintf(filename, "%c%03d_C%03d_%02d%02d%c%c", _letter, _reel, _clip, _month, _day, _wld1, _wld2);
  frame->filename = std::string(filename);
}

/////////////////////////////////////////////////////////////////////////////

class ArriParser : public DeckLinkReader::GenericParser
{
  std::unique_ptr<V210Decoder> _v210dec;
  std::vector<uint16_t> _raw_vanc;
  std::vector<uint8_t> _decoded_vanc;

  struct decode_error : public std::runtime_error
  {
    decode_error(const char* what) : runtime_error(what) {}
  };

  size_t ExtractRawVANC(IDeckLinkVideoFrameAncillary* vanc, size_t rowbytes);

  // TODO: These 3 methods should be common with DekTecReader.
  void DecodeRawVANC(size_t num_words);
  static uint8_t DecodeWord(uint16_t);
  static void SetFrameMetadata(const nlohmann::json&, const VideoFrame_ptr&);

public:
  ArriParser() :
    GenericParser("ArriParser"), _v210dec(V210Decoder::create()),
    _raw_vanc(8192), _decoded_vanc(4096)
  { }
  void Parse(IDeckLinkVideoInputFrame*, VideoFrame_ptr) override;
};

void ArriParser::Parse(IDeckLinkVideoInputFrame* vf, VideoFrame_ptr frame)
{
  // Extract timecode as usual.
  {
    frame->record_flag = false;
    auto timecode = ParseTimecode(vf, frame);
    if (!timecode)
      return;
    timecode->Release();
  }

  // Metadata is stored in VANC lines 9-11.
  {
    IDeckLinkVideoFrameAncillary* vanc;
    if (vf->GetAncillaryData(&vanc) != S_OK) {
      HAL_LOG(WARNING) << "Failed to get VANC data";
      return;
    }
    size_t num_words = ExtractRawVANC(vanc, vf->GetRowBytes());
    if (num_words) try {
      DecodeRawVANC(num_words);
      if (!arri::PopulateMetadata(_decoded_vanc.data(), frame.get())) {
          throw decode_error("Invalid magic number");
      }
      SetFrameMetadata(frame->parsed_metadata.at("arri"), frame);
    }
    catch (decode_error& err) {
      HAL_LOG(WARNING) << "Failed to decode VANC for frame " << to_string(frame->timecode) << ": " << err.what();
    }
    vanc->Release();
  }
}

size_t ArriParser::ExtractRawVANC(IDeckLinkVideoFrameAncillary* vanc, size_t rowbytes)
{
  size_t num_words = 0;
  uint8_t *buf;
  
  for (int lineId = 0; lineId < 3; ++lineId) {
    if (vanc->GetBufferForVerticalBlankingLine(lineId + 9, (void**)&buf) != S_OK)
      return 0;
  
    _v210dec->decodeFrame((uint8_t*)buf, rowbytes, 1920, 1);
    const uint16_t *words = boost::asio::buffer_cast<const uint16_t*>(_v210dec->rawPixels(0));
    size_t len = boost::asio::buffer_size(_v210dec->rawPixels(0));
    memcpy(_raw_vanc.data() + num_words, words, len);
    num_words += len / 2; // shorts
  }
  return num_words;
}

void ArriParser::DecodeRawVANC(size_t num_words)
{
  static const uint8_t KLV_HEADER[20] = { 0x06, 0x0e, 0x2b, 0x34, 0x02, 0x05, 0x01, 0x0d, 0x0e, 0x17, 0x00, 0x00, 0x00, 0x11, 0x01, 0x01, 0x83, 0x00, 0x10, 0x00 };

  size_t out_len = 0;
  int klv_mid = -1;
  int klv_psc = 1;

  for (size_t i = 0; i < num_words - 3; ++i) {
    if (_raw_vanc[i] != 0x00 || _raw_vanc[i + 1] != 0x3FF || _raw_vanc[i + 2] != 0x3FF) // Search for ANC packet
      continue;

    const uint16_t *anc_start = &_raw_vanc[i + 3];
    uint8_t did = DecodeWord(anc_start[0]);
    uint8_t sdid = DecodeWord(anc_start[1]);
    uint8_t dc = DecodeWord(anc_start[2]);
    uint8_t mid = DecodeWord(anc_start[3]);
    uint16_t psc = DecodeWord(anc_start[4]) | (DecodeWord(anc_start[5]) << 8); // XXX: Docs say this is DECIMAL, but here it's used as binary...!

    if (did != 0x44 || sdid != 0x04)
      throw decode_error("Unexpected did or sdid in vanc packet.");
    if (dc != 233)
      throw decode_error("Unexpected data length in vanc packet.");
    if (klv_psc++ != psc)
      throw decode_error("ANC packet out of sequence");
    if (psc == 1) klv_mid = mid;
    else if (mid != klv_mid)
      throw decode_error("ANC packet with different mid");

    const uint16_t *payload = &anc_start[6];
    size_t payload_len = dc - 3;

    if (psc == 1) {                               // Verify KLV header present in the 1st packet.
      for (size_t j = 0; j < sizeof(KLV_HEADER); ++j)
      if (DecodeWord(payload[j]) != KLV_HEADER[j])
        throw decode_error("Invalid KLV header");
      payload += sizeof(KLV_HEADER);
      payload_len -= sizeof(KLV_HEADER);
    }

    if (payload_len + out_len > 4096)             // Last packet is zero-padded; discard padding.
      payload_len = 4096 - out_len;

    for (size_t j = 0; j < payload_len; ++j)
      _decoded_vanc[out_len++] = DecodeWord(payload[j]);

    // TODO: Calculate checksum and compare with the checksum in the ANC packet.

    i += dc;                                      // NB! Combined with ++i in the for-loop, skips over the checksum
  }

  if (out_len != 4096)
    throw decode_error("Invalid length of metadata");
}

uint8_t ArriParser::DecodeWord(uint16_t word)
{
  uint8_t byte = word & 0xff;
  return byte; // XXX: FIX


  uint32_t nbits = _mm_popcnt_u32(word);
  uint8_t parity = word >> 8;

  if (nbits & 1) {                                // Odd parity
    if ((~parity & 1) || (parity & 2))
      throw decode_error("bit parity error");
  }
  else {                                          // Even parity
    if ((parity & 1) || (~parity & 2))
      throw decode_error("bit parity error");
  }
  return byte;
}

void ArriParser::SetFrameMetadata(const nlohmann::json& arri, const VideoFrame_ptr& frame)
{
  static const auto bcd = [](uint8_t v) { return (v >> 4) * 10 + (v & 15); };

  {
    uint32_t recording_length = arri.at("rec-run-edge-code-tc").at(0);
    frame->record_flag = recording_length != 0xFFFFFFFF && recording_length;
  }
  frame->vari_flag = arri.at("vari-frame-duplicate");
  frame->filename = arri.at("clip-name").get<std::string>();
  {
    auto it = std::find(frame->filename.begin(), frame->filename.end(), '\0');
    frame->filename.erase(it, frame->filename.end());
  }

  uint32_t tc_bcd = arri.at("master-tc");
  frame->timecode.hour = bcd(tc_bcd >> 24);
  frame->timecode.minute = bcd(tc_bcd >> 16);
  frame->timecode.second = bcd(tc_bcd >> 8);
  frame->timecode.frame = bcd(tc_bcd);
  frame->timecode.subframe = 0;
}



/////////////////////////////////////////////////////////////////////////////

std::unique_ptr<DeckLinkReader::GenericParser> DeckLinkReader::CreateParser(config::CameraID camera_type)
{
  switch (camera_type)
  {
  case config::SDI_CAMERA_GENERIC: return std::unique_ptr<GenericParser>(new GenericParser); break;
  case config::SDI_CAMERA_RED: return std::unique_ptr<GenericParser>(new RedParser); break;
  case config::SDI_CAMERA_ARRI: return std::unique_ptr<GenericParser>(new ArriParser); break;
  }
  throw std::invalid_argument("DeckLinkReader::Create: unsupported camera_type");
}

std::shared_ptr<DeckLinkReader> DeckLinkReader::Create(RecordingObserver& recording_observer, const config::Camera& camera)
{
    const config::SDICamera* sdiCamConf = dynamic_cast<const config::SDICamera*>(&camera);
    if (!sdiCamConf)
        throw std::logic_error("DeckLinkReader::Create got Camera config object that was not SDICamera");
    return std::make_shared<DeckLinkReaderImpl>(recording_observer, camera, CreateParser(sdiCamConf->sdi_camera_id));
}

} // hal

