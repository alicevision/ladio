// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "GraphTypes.h"
#include "VideoTypes.h"
#include "Config.h"

#ifndef _WIN32
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <openssl/md5.h>
#endif

#include <array>
#include <memory>
#include <iomanip>
#include <thread>
#include <fstream>
#include <boost/filesystem.hpp>
#include <boost/uuid/uuid.hpp>
#include <boost/uuid/string_generator.hpp>
#include <boost/uuid/uuid_io.hpp>
#include <boost/property_tree/json_parser.hpp>


extern "C"
{
#include <libswscale/swscale.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
}

namespace hal
{

class AVFormatWriter
{
    hal_logger_t _logger;
    int _ec;
    bool _header_written;
    boost::filesystem::path _file_path;
    AVFormatContext* _context;
    std::array<AVStream*, 2> _streams;  // Owned by the context

    void AddVideoStream(AVCodecContext*);
    void AddAudioStream(AVCodecContext*);

public:
    AVFormatWriter(const std::string& stream_name, const std::string& file_path, int fps, AVCodecContext* video_codec, AVCodecContext* audio_codec);
    ~AVFormatWriter();
    void Write(const EncodedPacket&, EncodedPacket::Stream);
    void Finalize();
};

AVFormatWriter::AVFormatWriter(const std::string& stream_name, const std::string& file_path, int fps, AVCodecContext* video_codec, AVCodecContext* audio_codec) :
    _logger(boost::log::keywords::channel = "AVFormatWriter/" + stream_name),
    _ec(0),
    _header_written(false),
    _file_path(file_path)
{
    HAL_LOG(INFO) << "Initializing AVFormatWriter: " << _file_path;

    {
        auto pp = _file_path.parent_path();
        if (!pp.empty() && !exists(pp))
            create_directories(pp);
    }

    {
        AVOutputFormat *fmt = av_guess_format(NULL, ".mov", NULL);
        if (!fmt)
            throw std::invalid_argument(std::string("AVFormatWriter: can't guess format for path: ") + file_path);
        if (!(_context = avformat_alloc_context()))
            throw std::runtime_error("avformat_alloc_context");
        _context->oformat = fmt;
    }

    if (file_path.size() >= sizeof(_context->filename)) {
        avformat_free_context(_context);
        throw std::length_error(std::string("Path too long: ") + _file_path.string());
    }
    strcpy(_context->filename, _file_path.string().c_str());

    _context->packet_size = 1400;

    _streams.fill(nullptr);
    AddVideoStream(video_codec);
    AddAudioStream(audio_codec);

    // Setup output file
    av_dump_format(_context, 0, _context->filename, 1);

    if (!(_context->oformat->flags & AVFMT_NOFILE) && (_ec = avio_open(&_context->pb, _context->filename, AVIO_FLAG_WRITE)) < 0)
        throw ffmpeg_error("avio_open", _ec);
}

void AVFormatWriter::AddVideoStream(AVCodecContext* c)
{
    if (!c)
        throw std::invalid_argument("AVFormatWriter::AddVideoStream: null context");
    if (c->codec_type != AVMEDIA_TYPE_VIDEO)
        throw std::invalid_argument("AVFormatWriter::AddVideoStream: not video codec");
    if (_streams[EncodedPacket::video])
        throw std::logic_error("AVFormatWriter::AddVideoStream: already added");
    if (!(_streams[EncodedPacket::video] = avformat_new_stream(_context, c->codec)))
        throw std::runtime_error(std::string("avformat_new_stream"));
    avcodec_parameters_from_context(_streams[EncodedPacket::video]->codecpar, c);

    _streams[EncodedPacket::video]->codec->codec_type = AVMEDIA_TYPE_VIDEO;
    _streams[EncodedPacket::video]->codec->codec_id = c->codec_id;
    _streams[EncodedPacket::video]->codec->flags = CODEC_FLAG_GLOBAL_HEADER;
    _streams[EncodedPacket::video]->codec->bit_rate = c->bit_rate;
    _streams[EncodedPacket::video]->codec->width = c->width;
    _streams[EncodedPacket::video]->codec->height = c->height;
    _streams[EncodedPacket::video]->codec->time_base = c->time_base;
    _streams[EncodedPacket::video]->codec->gop_size = c->gop_size;
    _streams[EncodedPacket::video]->codec->pix_fmt = c->pix_fmt;
    _streams[EncodedPacket::video]->time_base = c->time_base;
}

void AVFormatWriter::AddAudioStream(AVCodecContext* c)
{
    if (!c)
        throw std::invalid_argument("AVFormatWriter::AddAudioStream: null context");
    if (c->codec_type != AVMEDIA_TYPE_AUDIO)
        throw std::invalid_argument("AVFormatWriter::AddAudioStream: not audio codec");
    if (_streams[EncodedPacket::audio])
        throw std::logic_error("AVFormatWriter::AddAudioStream: already added");
    if (!(_streams[EncodedPacket::audio] = avformat_new_stream(_context, c->codec)))
        throw std::runtime_error(std::string("avformat_new_stream"));
    avcodec_parameters_from_context(_streams[EncodedPacket::audio]->codecpar, c);

    _streams[EncodedPacket::audio]->codec->codec_type = AVMEDIA_TYPE_AUDIO;
    _streams[EncodedPacket::audio]->codec->codec_id = c->codec_id;
    _streams[EncodedPacket::audio]->codec->flags = CODEC_FLAG_GLOBAL_HEADER;
    _streams[EncodedPacket::audio]->codec->bit_rate = c->bit_rate;
    _streams[EncodedPacket::audio]->codec->sample_rate = c->sample_rate;
    _streams[EncodedPacket::audio]->codec->channels = c->channels;
    _streams[EncodedPacket::audio]->codec->sample_fmt = c->sample_fmt;
    _streams[EncodedPacket::audio]->codec->channel_layout = c->channel_layout;
}

void AVFormatWriter::Write(const EncodedPacket& ep, EncodedPacket::Stream si)
{
    if (_ec < 0)
        throw std::logic_error("Writer already failed.");

    if (!ep.payload[si].ok) {
        _ec = AVERROR_UNKNOWN;
        throw std::runtime_error("Encoder failed");
    }

    if (!_header_written) {
        char txt[80];
        strcpy(txt, to_string(ep.frame->timecode).c_str());
        av_dict_set(&_context->metadata, "timecode", txt, 0);
        if ((_ec = avformat_write_header(_context, nullptr)) < 0)
            throw ffmpeg_error("avformat_write_header", _ec);
        _header_written = true;
    }

    const EncodedPacket::Payload& payload = ep.payload[si];

    if (!payload.packet)  // Codec generated empty packet, don't write it.
        return;

    // AVPacket must come with pts/dts/etc. filled in.
    payload.packet->pts = av_rescale_q(payload.packet->pts, payload.codec->CodecContext()->time_base, _streams[si]->time_base);
    payload.packet->dts = av_rescale_q(payload.packet->dts, payload.codec->CodecContext()->time_base, _streams[si]->time_base);
    payload.packet->stream_index = _streams[si]->index;
    if ((_ec = av_interleaved_write_frame(_context, payload.packet.get())) < 0)
        throw ffmpeg_error("av_interleaved_write_frame", _ec);
}

void AVFormatWriter::Finalize()
{
    if (_ec < 0)
        throw std::logic_error("Writer already failed.");

    HAL_LOG(INFO) << "Closing AVFormatWriter: " << _file_path;

    if (_context->pb) {
        if ((_ec = av_write_trailer(_context)) < 0)
            throw ffmpeg_error("av_write_trailer", _ec);
        if (!(_context->oformat->flags & AVFMT_NOFILE) && (_ec = avio_closep(&_context->pb)) < 0)
            throw ffmpeg_error("avio_closep", _ec);
    }
}

AVFormatWriter::~AVFormatWriter()
{
    avformat_free_context(_context);
}

/////////////////////////////////////////////////////////////////////////////

// NB! Concurrency level must be 1! (Otherwise, multiple files for the same recording could be created.)
class AVFormatWriterBody
{
    hal_logger_t _logger;
    const std::string _path_prefix;
    void (AVFormatWriterBody::*_state)(const EncodedPacket&, AVFormatWriterNode::output_ports_type& ports);
    TemporaryFileSet _output_paths;
    std::shared_ptr<AVFormatWriter> _media_writer;  // shared_ptr because body must be copyable
    std::shared_ptr<std::ofstream> _metadata_writer;

    void Reset();
    void Waiting(const EncodedPacket&, AVFormatWriterNode::output_ports_type& ports);
    void Writing(const EncodedPacket&, AVFormatWriterNode::output_ports_type& ports);
    void Finalize(AVFormatWriterNode::output_ports_type& ports);
    std::string GetTempFilepath(const EncodedPacket& ep, const char* ext);

public:
    AVFormatWriterBody(const std::string& path_prefix);
    void operator()(const EncodedPacket&, AVFormatWriterNode::output_ports_type&);
};

AVFormatWriterBody::AVFormatWriterBody(const std::string& path_prefix) :
    _logger(boost::log::keywords::channel = "AVFormatWriterNode"),
    _path_prefix(path_prefix),
    _state(&AVFormatWriterBody::Waiting)
{}

void AVFormatWriterBody::operator()(const EncodedPacket& ep, AVFormatWriterNode::output_ports_type& ports)
{
    try {
        HAL_LOG(TRACE) << "GOT PACKET; recording_length=" << ep.recording_length;
        (this->*_state)(ep, ports);
    }
    catch (std::exception& e) {
        HAL_LOG(ERROR) << "Failed; no more output will be generated: " << e.what();
        if (_state != &AVFormatWriterBody::Waiting) {
            _output_paths.ok = false;
            std::get<0>(ports).try_put(_output_paths);
        }
        Reset();
    }
}

void AVFormatWriterBody::Reset()
{
    _state = &AVFormatWriterBody::Waiting;
    _output_paths.media_file.clear();
    _output_paths.metadata_file.clear();
    _media_writer.reset();
    _metadata_writer.reset();
}

void AVFormatWriterBody::Waiting(const EncodedPacket& ep, AVFormatWriterNode::output_ports_type& ports)
{
    if (ep.recording != RawPacket::new_file)
        return;
    if (_media_writer || _metadata_writer)
        throw std::logic_error("AVFormatWriterBody::Waiting: invalid state");

    if (!ep.payload[EncodedPacket::video].ok) {
        HAL_LOG(ERROR) << "Initial packet invalid, NOT writing; file=" << ep.frame->filename << "; destination=" << _path_prefix;
        return;
    }

    _output_paths.media_file = GetTempFilepath(ep, ".mov");
    _media_writer = std::make_shared<AVFormatWriter>(ep.frame->stream->name, _output_paths.media_file.string(),
        ep.frame->stream->fps, ep.payload[0].codec->CodecContext(), ep.payload[1].codec->CodecContext());

    // To write metadata, the first recorded frame must populate it.
    if (!ep.frame->parsed_metadata.empty()) {
        _output_paths.metadata_file = GetTempFilepath(ep, ".json");
        _metadata_writer = std::make_shared<std::ofstream>(_output_paths.metadata_file.string());
    }

    _state = &AVFormatWriterBody::Writing;
    (this->*_state)(ep, ports);
}

void AVFormatWriterBody::Writing(const EncodedPacket& ep, AVFormatWriterNode::output_ports_type& ports)
{
    if (!_media_writer)
        throw std::logic_error("AVFormatWriterBody::Writing: invalid state");

    // TODO: Don't switch files if filename changes during recording.
    if (ep.recording == RawPacket::off) {
        Finalize(ports);
        Reset();
        return;
    }

    _media_writer->Write(ep, EncodedPacket::video);
    _media_writer->Write(ep, EncodedPacket::audio);
    if (_metadata_writer) {
        ep.frame->parsed_metadata["hal"]["timecode"] = to_string(ep.frame->timecode);
        (*_metadata_writer) << ep.frame->parsed_metadata;
    }
}

void AVFormatWriterBody::Finalize(AVFormatWriterNode::output_ports_type& ports)
{
    _media_writer->Finalize();

    if (_metadata_writer) {
        _metadata_writer->close();
        if (!*_metadata_writer)
            HAL_LOG(WARNING) << "Failed to close metadata file: " << _output_paths.metadata_file;
    }
    
    _output_paths.ok = true;
    std::get<0>(ports).try_put(_output_paths);
}

std::string AVFormatWriterBody::GetTempFilepath(const EncodedPacket& ep, const char* ext)
{
    std::ostringstream oss;
    auto now = std::chrono::system_clock::now();
    auto tmt = std::chrono::system_clock::to_time_t(now);

    if (ext[0] != '.')
        throw std::invalid_argument("Extension must begin with a dot");

    oss << _path_prefix << "/" << ep.frame->filename << "_" << ep.frame->stream->name;
    oss << "_" << std::put_time(std::localtime(&tmt), "%y%m%d");
    oss << ext << "." << ep.uuid;
    return oss.str();
}


// FACTORY //////////////////////////////////////////////////////////////////

AVFormatWriterNodeP MakeAVFormatWriterNode(tbb::flow::graph& g, const std::string& path_prefix)
{
    return AVFormatWriterNodeP(new AVFormatWriterNode(g, 1, AVFormatWriterBody(path_prefix)));
}

} // hal
