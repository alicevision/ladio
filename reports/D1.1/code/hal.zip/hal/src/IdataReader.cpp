// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//

#include "IdataReader.h"

namespace hal
{

IdataReader::IdataReader(const std::string & portName) :
    timeout(timeout),
    timer(_ioService),
    read_error(true),
    _serialPort(_ioService)
{
    _serialPort.open(portName);
    _serialPort.set_option(boost::asio::serial_port_base::baud_rate(115200));
}

cooke_messages::N IdataReader::GetN()
{
    cooke_messages::N NReply;
    NReply.data = GetData(cooke_commands::N);
    return NReply;
}

cooke_messages::D IdataReader::GetD()
{
    cooke_messages::D DReply;
    DReply.data = GetData(cooke_commands::D);
    return DReply;
}

void IdataReader::read_complete(const boost::system::error_code & error, size_t bytes_transferred)
{
    read_error = (error || bytes_transferred == 0);
    timer.cancel();
}

void IdataReader::time_out(const boost::system::error_code & error) {
    if (error)
        return;
    _serialPort.cancel();
}

bool IdataReader::read_char(char & val) {

    val = c = '\0';

    // After a timeout and cancel, a reset might be required
    _ioService.reset();

    // Asynchronously read 1 character.
    boost::asio::async_read(_serialPort, boost::asio::buffer(&c, 1),
        boost::bind(&IdataReader::read_complete,
        this,
        boost::asio::placeholders::error,
        boost::asio::placeholders::bytes_transferred));

    timer.expires_from_now(boost::posix_time::milliseconds(timeout));
    timer.async_wait(boost::bind(&IdataReader::time_out,
        this, boost::asio::placeholders::error));

    _ioService.run();

    if (!read_error)
        val = c;

    return !read_error;
}

std::string IdataReader::GetData(const std::string & command)
{
    std::string data;
    char _c;
    while (read_char(_c))
    {
        data += _c;
        if (data.size() > 2)
            if (data.substr(data.size() - 2, 2) == "\n\r")
                break;
    }

    return data.substr(0, data.size() - 2);
}

} // hal