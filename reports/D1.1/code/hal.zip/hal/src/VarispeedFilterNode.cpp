#include "GraphTypes.h"
#include "VideoTypes.h"
#include "Config.h"

#include <deque>

namespace hal
{
class VariSpeedFilterBody
{
private:
    std::deque<EncodedPacket> _buffer;
    bool _filterLogicComplete;
    bool _isVarispeed;

    void onVarispeed(EncodedPacket& fp)
    {
        fp.payload[EncodedPacket::audio].packet = nullptr;
        fp.frame->filename.insert(0, "VS_");
    }

    void FlushQueue(VarispeedFilterNode::output_ports_type& ports)
    {
        while (!_buffer.empty()) {
            EncodedPacket& ep = _buffer.front();
            if (_isVarispeed)
                onVarispeed(ep);
            std::get<0>(ports).try_put(ep);
            _buffer.pop_front();
        }
    }
public:
    VariSpeedFilterBody() : 
        _filterLogicComplete(false),
        _isVarispeed(false)
    {
    }

    void operator()(EncodedPacket ep, VarispeedFilterNode::output_ports_type& ports)
    {
        // If not recording, packets are forwardet immediately
        if (ep.recording == EncodedPacket::off) {
            // flush the buffer first, if we were in recording on previous call
            FlushQueue(ports);
            // send the current packet. Recording is off so we don't change audio packet
            std::get<0>(ports).try_put(ep);
            
            // Resetting so next time we get a packet with recording==on
            // we start the filter logic again
            _filterLogicComplete = false;
            _isVarispeed = false;
            return;
        }

        if (!_filterLogicComplete) {
            if (ep.frame->vari_flag) {
                _filterLogicComplete = true;
                _isVarispeed = true;
            }
            else if (_buffer.size() >= Config->fps) {
                _filterLogicComplete = true;
            }
            else {
                _buffer.push_back(ep);
            }
        }
        
        if(_filterLogicComplete) {
            FlushQueue(ports);
            // send the current packet
            if (_isVarispeed) {
                onVarispeed(ep);
            }
            std::get<0>(ports).try_put(ep);
        }
    }

};

VarispeedFilterNodeP MakeVarispeedFilterNode(tbb::flow::graph& g) {
    return VarispeedFilterNodeP(new VarispeedFilterNode(g, 1, VariSpeedFilterBody()));
}

}