// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "VideoTypes.h"
#include "GraphTypes.h"
#include "GraphBuilder.h"
#include "Config.h"
#include "IOController.h"

#ifndef _WIN32
#include <sched.h>
#include "../io-controller/IOControllerProxy.h"
#endif
#include <deque>
#include <tuple>
#include <mutex>
#include <condition_variable>
#include <boost/uuid/random_generator.hpp>

namespace
{
static TimecodeRate GetTimecodeRate()
{
    switch (hal::Config->fps)
    {
    case 24: return tcfps24;
    case 25: return tcfps25;
    case 30: return tcfps30;
    case 60: return tcfps60;
    }
    throw std::runtime_error("Unsupported frame rate");
}
}

namespace hal
{

static constexpr double MAX_EMPTY_DURATION_S = 10;  // Allow max 10s of empty frames before stopping recording

class SoftwareTrigger
{
    GraphBuilder& _gb;
    hal_logger_t _logger;
    
    std::thread _thread;
    std::mutex _mutex;
    std::condition_variable _cv;

    std::chrono::steady_clock::time_point _wakeup_time;
    int32_t _last_sdi_trigger;
    int32_t _last_delivered_trigger;
    bool _triggered;
    bool _running;
    
    void Thread();
    void DoTrigger();
    
public:
    SoftwareTrigger(GraphBuilder&);
    void Start();
    void Stop();
    void Trigger(int32_t sdi_trigger);
};

SoftwareTrigger::SoftwareTrigger(GraphBuilder& gb) :
    _gb(gb),
    _logger(boost::log::keywords::channel = "SoftTrigger"),
    _last_sdi_trigger(-1),
    _last_delivered_trigger(-1),
    _triggered(false),
    _running(false)
{
    _wakeup_time = std::chrono::steady_clock::now();
}

void SoftwareTrigger::Start()
{
    HAL_LOG(INFO) << "Starting";
    if (_thread.joinable())
        throw std::logic_error("SoftwareTrigger: already running");
    
    _running = true;
    _thread = std::thread(&SoftwareTrigger::Thread, this);
#ifndef _WIN32
#endif
    HAL_LOG(INFO) << "Started";
}

void SoftwareTrigger::Stop()
{
    HAL_LOG(INFO) << "Stopping";
    if (!_thread.joinable())
        throw std::logic_error("SoftwareTrigger: not running");
    {
        std::lock_guard<std::mutex> lk(_mutex);
        _running = false;
        _cv.notify_one();
    }
    _thread.join();
    HAL_LOG(INFO) << "Stopped";
}

void SoftwareTrigger::Trigger(int32_t sdi_trigger)
{
    std::lock_guard<std::mutex> lk(_mutex);

    if (_last_sdi_trigger != -1 && sdi_trigger != _last_sdi_trigger+1)
        throw std::logic_error("SoftwareTrigger: non-monotonic trigger ord");

    if (_last_sdi_trigger == -1) {
        HAL_LOG(INFO) << "First trigger=" << sdi_trigger;
        _last_delivered_trigger = sdi_trigger-1;
    }

    _last_sdi_trigger = sdi_trigger;
    
    if (sdi_trigger <= _last_delivered_trigger) {
        HAL_LOG(TRACE) << "Ignoring late SDI trigger; trigger=" << sdi_trigger << "; last_delivered_trigger=" << _last_delivered_trigger;
        return;
    }
    if (_last_sdi_trigger != -1 && sdi_trigger != _last_delivered_trigger + 1) {
        HAL_LOG(DEBUG) << "Synchronization lost; continuing with timer trigger; trigger=" << sdi_trigger << "; last_delivered_trigger=" << _last_delivered_trigger;
        return;
    }

    HAL_LOG(TRACE) << "Triggering: " << sdi_trigger;
    _triggered = true;
    _cv.notify_one();
}

void SoftwareTrigger::Thread()
{
    using namespace std::chrono;
    steady_clock::time_point t_before_wait, t_after_wait;
    std::cv_status ws;
    {
        struct sched_param sp;
        sp.sched_priority = 10;
        if (pthread_setschedparam(pthread_self(), SCHED_FIFO, &sp) < 0)
            throw std::runtime_error("pthread_setschedparam");
    }

forever:
    std::unique_lock<std::mutex> lk(_mutex);
    t_before_wait = steady_clock::now();
spurious_wakeup:
    ws = _cv.wait_until(lk, _wakeup_time);
    t_after_wait = steady_clock::now();
    HAL_LOG(TRACE) << "Woke up after; ms=" << duration_cast<milliseconds>(t_after_wait - t_before_wait).count();

    if (!_running) {
        HAL_LOG(INFO) << "Exiting on signal.";
        return;
    }
    
    if (!_triggered && t_after_wait < _wakeup_time) {
        HAL_LOG(WARNING) << "Spurious wakeup";
        goto spurious_wakeup;
    }

    if (ws == std::cv_status::no_timeout) {
        if (!_triggered) HAL_LOG(ERROR) << "Unhandled spurious wakeup?";
        else HAL_LOG(TRACE) << "SDI trigger";
        _triggered = false;
    }
    else {
        HAL_LOG(TRACE) << "Timer trigger";
    }
    
    if (_last_sdi_trigger < 0) HAL_LOG(INFO) << "Waiting for first SDI trigger";
    else DoTrigger();
    
    _wakeup_time = t_after_wait + milliseconds(42); // XXX: HARDCODED!
    goto forever;
}

void SoftwareTrigger::DoTrigger()
{
    HAL_LOG(TRACE) << "TRIGGER BEGIN: " << _last_delivered_trigger+1;
    bool ok = true;
    for (const auto& reader: _gb.Readers())
    if (!reader->trigger_master && !reader->Trigger(_last_delivered_trigger+1))
        ok = false;
    if (ok) ++_last_delivered_trigger;
    HAL_LOG(TRACE) << "TRIGGER END";
}

/////////////////////////////////////////////////////////////////////////////

class RecordingObserverImpl : public RecordingObserver
{
    GraphBuilder& _gb;
    SoftwareTrigger _trigger;
    hal_logger_t _logger;

    // Data independent of recording.
    boost::uuids::random_generator _uuidgen;
    TimecodeRate _tc_rate;
    bool _forced_recording;
    std::vector<std::deque<RawPacket>> _in_queues;  // These are used for synchronizing the cameras.
    std::vector<std::deque<RawPacket>> _out_queues; // These are used for output; elements correspond to GraphBuilder::Readers elements.
    VideoStream* _trigger_master;                   // nullptr if no SDI
    int _trigger_master_index;
    bool _frame_pushed;

    // Recording state delivered by trigger master.
    bool _recording;
    TimecodeTime _jam_timecode;
    int32_t _jam_ord;
    boost::uuids::uuid _uuid;
    std::string _filename;
    int32_t _empty_frame_count;
    int32_t _recording_length;
    
    void FirstFrameInitialization();
    void HandleEmptyFrame(RawPacket&);
    void HandleForcedRecording(RawPacket&);
    void HandleRecording(RawPacket& rp);
    bool SynchronizeQueues(int32_t ref_ord = -1);
    void ClearRecordingState();
    inline int QueueIndex(const VideoFrame_ptr&);

    // Queues are flushed in another thread.
    std::thread _thread;
    mutable std::mutex _mutex;
    std::condition_variable _cv;
    int _online_stream_count;
    bool _running;

    void FlushQueues();
    void CheckOnlineStreams();

public:
    RecordingObserverImpl(GraphBuilder& gb);
    ~RecordingObserverImpl() override;
    void Start() override;
    void Run() override;
    void Stop() override;
    void PushFrame(VideoFrame_ptr) override;
    void SetForcedRecording(bool) override;
    bool GetForcedRecording() const override;
};

RecordingObserverImpl::RecordingObserverImpl(GraphBuilder& gb) :
    _gb(gb),
    _trigger(_gb),
    _logger(boost::log::keywords::channel = "RecordingObserver"),
    _tc_rate(GetTimecodeRate()),
    _forced_recording(false),
    _trigger_master(nullptr),
    _trigger_master_index(-1),
    _frame_pushed(false),
    _jam_ord(-1),
    _online_stream_count(0),
    _running(false)
{
    ClearRecordingState();
    HAL_LOG(INFO) << "Initialized.";
}

RecordingObserverImpl::~RecordingObserverImpl()
{
    if (_thread.joinable())
        HAL_LOG(ERROR) << "Destroying while running";
    HAL_LOG(INFO) << "Destroyed.";
}

void RecordingObserverImpl::Start()
{
    if (_thread.joinable())
        throw std::logic_error("RecordingObserver: already started");
    _in_queues.resize(_gb.Readers().size());
    _out_queues.resize(_gb.Readers().size());
}

void RecordingObserverImpl::Run()
{
    HAL_LOG(INFO) << "Processing frames.";
    _running = true;
    _thread = std::thread(&RecordingObserverImpl::FlushQueues, this);
    _thread.join();
    HAL_LOG(INFO) << "Exited frame processing loop.";
}

void RecordingObserverImpl::Stop()
{
  {
    std::unique_lock<std::mutex> lk(_mutex);
    _running = false;
    _cv.notify_one();
  }
  _trigger.Stop();
}

void RecordingObserverImpl::PushFrame(VideoFrame_ptr frame)
{
    std::lock_guard<std::mutex> lk(_mutex);

    FirstFrameInitialization();

    HAL_LOG(TRACE) << "GOT FRAME; stream=" << frame->stream->name << "; ord=" << frame->ord;
    
    if (_trigger_master) {
        const auto& readers = _gb.Readers();
        {
            auto& q = _in_queues[QueueIndex(frame)];
            RawPacket rp{ _uuid, frame, -1, RawPacket::off };
            auto it = std::lower_bound(
                q.begin(), q.end(), rp,
                [](const RawPacket& rp1, const RawPacket& rp2) {
                    return rp1.frame->ord < rp2.frame->ord;
            });
            if (it != q.end()) HAL_LOG(WARNING) << "Frame out of order; ord=" << frame->ord;
            q.insert(it, rp);
        }

        if (_online_stream_count < readers.size()) {
            HAL_LOG(TRACE) << "Waiting for streams to come online; got frame from stream " << frame->stream->name;
            CheckOnlineStreams();
            return;
        }
        if (_jam_ord < 0) {
            if (frame->stream->trigger_master) _jam_ord = frame->ord + 1;
            else return;
        }
        if (frame->stream->trigger_master)
            _trigger.Trigger(frame->ord+1); // Current SDI frame triggers NEXT WC frame.
        if (SynchronizeQueues(_jam_ord)) {
            timecode_time_increment(&_jam_timecode, &_tc_rate);
            ++_jam_ord;
            _cv.notify_one();
        }
    }
    else if (_forced_recording) {
        auto& q = _out_queues[QueueIndex(frame)];
        q.push_back(RawPacket{ _uuid, frame, -1, RawPacket::off });
        HandleForcedRecording(q.front());
        _cv.notify_one();
    }
}

void RecordingObserverImpl::FirstFrameInitialization()
{
    if (_frame_pushed)
        return;
    _frame_pushed = true;

    const auto& readers = _gb.Readers();
    for (size_t i = 0; i < readers.size(); ++i) {
        if (!readers[i]->trigger_master)
            continue;
        if (_trigger_master)
            throw std::logic_error("RecordingObserver: multiple trigger masters configured");
        _trigger_master = readers[i].get();
        _trigger_master_index = int(i);
    }
}

void RecordingObserverImpl::CheckOnlineStreams()
{
    for (size_t i = 0; i < _out_queues.size(); ++i) {
        if (!_in_queues[i].empty()) {
            if (_out_queues[i].empty()) {
                auto rp = _in_queues[i].front();
                _out_queues[i].push_back(rp);
                ++_online_stream_count;
                HAL_LOG(INFO) << "Got first frame for stream " << _out_queues[i].front().frame->stream->name;
            }
            _in_queues[i].pop_front();
        }
    }
    if (_online_stream_count != _gb.Readers().size())
        return;
    
    // No clear() on std::queue, and gcc won't swap with rvalue-reference.
    _in_queues.clear();
    _in_queues.resize(_gb.Readers().size());
    _out_queues.clear();
    _out_queues.resize(_gb.Readers().size());
    
    HAL_LOG(INFO) << "All streams online; ready to record.";
    _trigger.Start();
    // TODO: green LED.
}

void RecordingObserverImpl::HandleEmptyFrame(RawPacket& rp)
{
    auto& frame = rp.frame;

    if (frame->stream.get() != _trigger_master)
        throw std::logic_error("HandleEmptyFrame: not trigger master frame");
    if (_forced_recording)
        throw std::logic_error("HandleEmptyFrame: forced recording");
    
    if (!frame->empty) _empty_frame_count = 0;
    else ++_empty_frame_count;

    double d = _empty_frame_count / timecode_rate_to_double(&_tc_rate);
    if (d > MAX_EMPTY_DURATION_S) {
        frame->record_flag = false;         // XXX: This will finish recording, but it will be restarted when the stream is back if the cam is still recording.
        IOController->SetErrorLevel(0, IOControllerImpl::FAILED);
    }
    else {
        IOController->SetErrorLevel(0, IOControllerImpl::OK);
    }
}

void RecordingObserverImpl::HandleForcedRecording(RawPacket& rp)
{
    auto& frame = rp.frame;

    if (_recording)
        throw std::logic_error("HandleForcedRecording: trigger master is recording");
    
    if (_forced_recording) {
        frame->timecode = _jam_timecode;
        frame->filename = _filename;
        frame->vari_flag = false;
        rp.uuid = _uuid;
        rp.recording = !_recording_length ? RawPacket::new_file : RawPacket::on;
        rp.recording_length = _recording_length++;
    }
    else {
        rp.recording = RawPacket::off;
        rp.recording_length = -1;
    }
}

void RecordingObserverImpl::HandleRecording(RawPacket& rp)
{
    auto& frame = rp.frame;

    if (frame->stream.get() != _trigger_master)
        throw std::logic_error("HandleRecording: not trigger master frame");

    if (!frame->record_flag) {
        rp.recording = RawPacket::off;
        rp.recording_length = -1;
        if (_recording) {
            ClearRecordingState();
            IOController->SetRecording(false);
            HAL_LOG(INFO) << "RECORDING OFF";
        }
        return;
    }
    IOController->SetRecording(true);

    // Preserve filename in case of missing frames.
    std::string filename = frame->empty ? _filename : frame->filename;

    if (_recording) {
        if (filename == _filename) {
            rp.recording = RawPacket::on;
            rp.recording_length = _recording_length++;
        }
        else {
            HAL_LOG(WARNING) << "Camera info changed during recording; old filename: " << _filename << "; new filename: " << filename;
            ClearRecordingState();
        }
    }
    else {                                  // First frame with record_flag on.  Jam timecode.
        _jam_timecode = frame->timecode;
        _jam_ord = frame->ord;
    }

    if (!_recording) {                      // NB! Previous if() will change _recording if filename changes during recording.
        rp.recording = RawPacket::new_file;
        rp.recording_length = _recording_length++;
        HAL_LOG(INFO) << "RECORDING ON";
    }
    rp.uuid = _uuid;
    _recording = true;
    _filename = filename;
}

void RecordingObserverImpl::ClearRecordingState()
{
    _recording = false;
    _jam_timecode = TimecodeTime{ 0, 0, 0, 0, 0 };
    _uuid = _uuidgen();
    _filename = "FORCED_RECORDING";
    _empty_frame_count = 0;
    _recording_length = 0;
}

bool RecordingObserverImpl::SynchronizeQueues(int32_t ref_ord)
{
    if (!_trigger_master)
        throw std::logic_error("SynchronizeQueues: no trigger master");

    // XXX: ord calculations here assume that (SDI delay >= WC delay)
    
#if 1
    {
        std::ostringstream oss;
        for (const auto& q : _in_queues) {
            if (q.empty()) oss << -1;
            else oss << q.front().frame->ord;
            oss << ",";
        }
        HAL_LOG(DEBUG) << "REF: " << ref_ord << "; INQUEUE HEADS: " << oss.str();
    }
#endif

    // Make fronts of the queues have same ref_ord
    size_t sync_count = 0;
    for (size_t i = 0; i < _in_queues.size(); ++i) {
        int32_t reader_offset = _gb.Readers()[i]->tc_frame_offset;
        while (!_in_queues[i].empty()) {
            int d = _in_queues[i].front().frame->ord - reader_offset;
            if (d < ref_ord) {
                _in_queues[i].pop_front();
            }
            else if (d == ref_ord) {
                ++sync_count;
                break;
            }
            else {
                HAL_LOG(WARNING) << "Missing frame detected for stream: " << _in_queues[i].front().frame->stream->name;
                break;
            }
        }
    }

    if (sync_count != _in_queues.size())
        return false;

    {
        auto& q = _in_queues[_trigger_master_index];
        if (!_forced_recording)
            HandleEmptyFrame(q.front());
        HandleRecording(q.front());
        if (!_recording && _forced_recording)   // At on->off transition, forced recording will force a filename change.
            HandleForcedRecording(q.front());
    }

    // Copy SDI frame metadata to other frames in the queue.
    const auto ref = _in_queues[_trigger_master_index].front();
    for (size_t i = 0; i < _out_queues.size(); ++i) {
        int32_t reader_offset = _gb.Readers()[i]->tc_frame_offset;
        if (_in_queues[i].front().frame->ord - reader_offset != ref_ord)
            throw std::logic_error("Mismatched ref_ord in in queue");

        auto rp = _in_queues[i].front();
        _in_queues[i].pop_front();
        
        rp.uuid                 = ref.uuid;
        rp.recording_length     = ref.recording_length;
        rp.recording            = ref.recording;
        rp.frame->timecode      = ref.frame->timecode;
        rp.frame->filename      = ref.frame->filename;
        rp.frame->record_flag   = ref.frame->record_flag;
        rp.frame->vari_flag     = ref.frame->vari_flag;
        _out_queues[i].push_back(rp);
    }

    HAL_LOG(DEBUG) << "SYNC ORD: " << ref_ord;
    return true;
}

void RecordingObserverImpl::FlushQueues()
{
    std::string error_msg;

    {
    struct sched_param sp;
     sp.sched_priority = 0;
    if (pthread_setschedparam(pthread_self(), SCHED_OTHER, &sp) < 0)
    //if (pthread_setschedprio(pthread_self(), RT_PRIO_LOW) < 0)
        throw std::runtime_error("TBBThreadObserver: pthread_setschedprio");
    }

    while (error_msg.empty()) {
        {
            std::unique_lock<std::mutex> lk(_mutex);
            if (_cv.wait_for(lk, std::chrono::milliseconds(500)) == std::cv_status::timeout) {
                if (!_running)
                    break;
                HAL_LOG(ERROR) << "FlushQueues: timed out waiting for signal";
            }

	    for (size_t ir = 0; ir < _gb.Readers().size(); ++ir) {
	        while (!_out_queues[ir].empty()) {
		    auto rp = _out_queues[ir].front();
		    _out_queues[ir].pop_front();
		    for (const auto& rep: _gb.Encoders())
 		        if (std::get<0>(rep) == ir)
			    std::get<1>(rep)->try_put(rp);
		}
	    }
        }
        try {
            _gb.Graph().wait_for_all();
            HAL_LOG(TRACE) << "Graph finished.";
        }
        catch (std::exception& e) {
            error_msg = e.what();
            break;
        }
        catch (...) {
            error_msg = "UNKNOWN EXCEPTION";
            break;
        }
    }

    if (!error_msg.empty()) {
        HAL_LOG(ERROR) << "GRAPH EXECUTION FAILED: " << error_msg;
        IOController->SetErrorLevel(0, IOControllerImpl::FAILED);
    }
}

int RecordingObserverImpl::QueueIndex(const VideoFrame_ptr& frame)
{
    const auto& readers = _gb.Readers();
    auto it = std::find(readers.begin(), readers.end(), frame->stream);
    if (it == readers.end())
        throw std::invalid_argument("QueueIndex: received frame from unregistered stream");
    return int(it - readers.begin());
}

void RecordingObserverImpl::SetForcedRecording(bool f)
{
    std::lock_guard<std::mutex> lk(_mutex);
    if (f != _forced_recording) {
        _forced_recording = f;
        if (!_recording)    // Don't touch recording state if master is recording.
            ClearRecordingState();
    }
}

bool RecordingObserverImpl::GetForcedRecording() const
{
    std::lock_guard<std::mutex> lk(_mutex);
    return _forced_recording;
}

std::unique_ptr<RecordingObserver> RecordingObserver::Create(GraphBuilder& gb)
{
    return std::make_unique<RecordingObserverImpl>(gb);
}

}   // hal
