// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <memory>
#include <mutex>
#include <ft2build.h>
#include FT_FREETYPE_H
#include "ForwardDecls.h"

namespace hal
{

/*
THREAD-SAFETY MODEL: https://sourceforge.net/projects/freetype/files/freetype2/2.6/
- Behdad  Esfahbod contributed  code  for improved  thread-safety,
which results in the following model.

* An `FT_Face' object can only be safely used from one thread at
a time.

* An `FT_Library'  object can  now be used  without modification
from multiple threads at the same time.

* `FT_Face' creation and destruction  with the same `FT_Library'
object can only be done from one thread at a time.

One can use a single  `FT_Library' object across threads as long
as a mutex lock is used around `FT_New_Face' and `FT_Done_Face'.
Any calls to `FT_Load_Glyph' and similar API are safe and do not
need the lock  to be held as  long as the same  `FT_Face' is not
used from multiple threads at the same time.
*/

class FontManager
{
  FT_Face _face;
  FT_GlyphSlot _slot;
  std::mutex _mutex;

  void DrawGlyph(int x, int y, FT_Bitmap* glyph, VideoFrame_ptr videoframe);

public:
  FontManager(std::string font, float size, float dpi);
  ~FontManager();

  void OverlaySDIFrame(VideoFrame_ptr frame);
  void OverlayWCFrame(VideoFrame_ptr frame);
  void DrawText(int x, int y, std::string text, VideoFrame_ptr videoframe);
};

};
