// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include "Logger.h"
#include "VideoTypes.h"
#include <memory>

struct IDeckLinkVideoInputFrame;
struct IDeckLinkTimecode;

namespace hal
{

class DeckLinkReader : public VideoStream
{
public:
  class GenericParser
  {
  protected:
    hal_logger_t _logger;

    // Returns pointer on success, must be Release()d
    IDeckLinkTimecode* ParseTimecode(IDeckLinkVideoInputFrame*, VideoFrame_ptr);

  public:
    GenericParser(const char* name = "GenericParser") :
      _logger(boost::log::keywords::channel = std::string("DeckLinkReader/") + name)
    {}
    virtual ~GenericParser() {}
    // Default implementation parses just the timecode.
    virtual void Parse(IDeckLinkVideoInputFrame*, VideoFrame_ptr);
  };

  static std::shared_ptr<DeckLinkReader> Create(RecordingObserver& recording_observer, const config::Camera& camera);

protected:
  DeckLinkReader(RecordingObserver& recording_observer, const config::Camera& camera, std::unique_ptr<GenericParser> meta_parser) :
    VideoStream(recording_observer, camera), _meta_parser(std::move(meta_parser))
  {}
  std::unique_ptr<GenericParser> _meta_parser;

private:
  static std::unique_ptr<GenericParser> CreateParser(config::CameraID);
};

} // hal
