// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once
#include <memory>

namespace hal
{

class VideoFrame;
class VideoStream;
struct AVCodecContextHolder;

using VideoFrame_ptr = std::shared_ptr<VideoFrame>;
using VideoStream_ptr = std::shared_ptr<VideoStream>;

} // hal
