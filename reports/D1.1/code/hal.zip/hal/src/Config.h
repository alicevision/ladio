// (c) 2014-2016 Labo Mixedrealities AS
// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include "Logger.h"
#include <string>
#include <vector>
#include <boost/filesystem/path.hpp>

extern "C"
{
#include <libavcodec/avcodec.h>
}

namespace hal
{
namespace config
{
enum FanMode { OFF, MAX, ADAPTIVE, HYSTALWAYS };
enum CaptureSource {
    DECKLINK = 1,
    DEKTEC = 2,
    SYNTHETIC = 3,
    PTGREY = 4,
    DVP2 = 5
};
enum CameraID
{
    SDI_CAMERA_GENERIC = 0,
    SDI_CAMERA_RED = 1,
    SDI_CAMERA_ARRI = 2,
};
enum OverlayMode { NO_OVERLAY, OVERLAY, OVERLAY_WITH_CROP };
enum UploadType { FTP };

struct OutputCodecPreset
{
    unsigned width;
    unsigned height;
    int video_bitrate;
    int h264_gop_size;
    AVCodecID video_codec;
    std::string threads = "0";
    std::string profile;
    AVPixelFormat output_pixel_format;

    AVCodecID audio_codec = AV_CODEC_ID_PCM_S16LE;
    int audio_sample_rate = 48000;
    int audio_bitrate = audio_sample_rate * 1 * sizeof(int16_t);  // one channel/mono
    AVSampleFormat audio_sample_format = AV_SAMPLE_FMT_S16;
    int audio_channel_count = 1;
};


struct UploadInfo {
    //todo: info required by ftpUploader
    std::string address;
    std::string username;
    std::string password;
};

struct VideoOutput {
    bool enabled;
    bool generate_hash;
    OutputCodecPreset preset;
    std::string output_name; //output-name becomes folder name in /var/CamBox/output/<output_name>
    std::string lut_name;    //Luts are found through lut_name in /var/CamBox/lut/<lut_name>
    OverlayMode overlay_mode;
    std::vector<UploadInfo> upload_destinations;
};

struct Camera {
    Camera(const std::string& name, bool master) : name(name), trigger_master(master) {}
    virtual ~Camera() {}
    bool enable;
    std::string name;
    bool trigger_master; //SDI is generally the master
    unsigned width;
    unsigned height;
    AVPixelFormat input_pixel_format;
    bool strict; // assert that config-defined format matches format parsed from camera
    CaptureSource capture_source;
    //https://github.com/FFmpeg/FFmpeg/blob/master/libavutil/samplefmt.c#L34
    AVSampleFormat sample_format;
    int channel_count; //dektec 8, deklink 2, wc: >=1
    int sample_rate; // dektec&deklink: 48k, wc: any valid samplerate
    int tc_offset;
    std::vector<VideoOutput> video_outputs;
    
};

struct SDICamera : public Camera {
    SDICamera() : Camera("SDI", false) {}
    CameraID sdi_camera_id; 
};

struct WitnessCamera : public Camera {
    WitnessCamera() : Camera("WC", false) {}
    std::string serial_number;

    float shutter;
    float gain;
    bool auto_exposure;
    bool external_trigger;
    bool flip;
};

struct ConfigFile
{
    static constexpr const char* preset_dir = "preset/";
    static constexpr const char* lut_dir = "lut/";
    static constexpr const char* output_dir = "output/";

    boost::filesystem::path path;
    bool log_to_journal;
    severity_level log_level;
    int sync_after_write;
    FanMode fanmode;
    unsigned framerate;
    bool warm_shuttersync;
    int fps;
    int jam_frame;
    int buffer_size;
    std::string working_dir;
    SDICamera sdi_camera;
    std::vector<WitnessCamera> witness_cameras;
};

std::unique_ptr<ConfigFile> Read(const boost::filesystem::path& path);

} // config

extern std::unique_ptr<config::ConfigFile> Config;

} // hal
