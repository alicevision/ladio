#pragma once
#include <memory>

namespace hal
{
class IOControllerPrivate;
class IOControllerImpl
{
public:
    enum ErrorStatus{OK=0, FAILED=1};
    void SetErrorLevel(int facility, ErrorStatus status);
    void SetRecording(bool on);
    
    ~IOControllerImpl();
    IOControllerImpl();
private:

    IOControllerPrivate* impl;
};
extern std::unique_ptr<IOControllerImpl> IOController;

} // namespace hal
