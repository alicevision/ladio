#include "IOController.h"

#ifndef _WIN32
#include "../io-controller/IOControllerProxy.h"
#endif

namespace hal
{

#ifndef _WIN32

static DBus::Connection& GetDBusSession()
{
    static std::unique_ptr<DBus::Connection> bus;
    static DBus::BusDispatcher dispatcher;
   
    if (!bus) {
        DBus::default_dispatcher = &dispatcher;
        bus.reset(new DBus::Connection(DBus::Connection::SystemBus()));
    }
    return *bus;
}

class IOControllerPrivate :
    public no::quine::CamBox::IOController_proxy,
    public DBus::IntrospectableProxy,
    public DBus::ObjectProxy
{
public:
    IOControllerPrivate(DBus::Connection& connection, const char* path, const char* name) :
        DBus::ObjectProxy(connection, path, name)
    {

    };
};
#endif 
std::unique_ptr<IOControllerImpl> IOController;
IOControllerImpl::IOControllerImpl()
{
#ifndef _WIN32
    impl = new IOControllerPrivate(GetDBusSession(), "/no/quine/CamBox/IOController", "no.quine.CamBox");
#endif
}

IOControllerImpl::~IOControllerImpl()
{
}

void IOControllerImpl::SetErrorLevel(int facility, ErrorStatus status)
{
#ifndef _WIN32
    impl->SetErrorLevel(facility, status);
#endif
}
void IOControllerImpl::SetRecording(bool on)
{
#ifndef _WIN32
    impl->SetRecording(on);
#endif

}

} // namespace hal