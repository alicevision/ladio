// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "GraphTypes.h"
#include "SyntheticReader.h"

namespace hal
{
SyntheticReader::SyntheticReader(RecordingObserver& recording_observer, const config::Camera& camera) :
    VideoStream(recording_observer, camera),
    _frame(nullptr),
    _counter(0),
    _running(true),
    _tcr(tcfps25),
    _current_tc{ 12, 34, 56, 0, 0 },
    _rngEngine((uintptr_t)this),
    _rngDistPos(-6, 6),
    _rngDistCol(-32, 32)
{
    if (this->pixel_format != AV_PIX_FMT_GRAY8 && this->pixel_format != AV_PIX_FMT_YUV422P)
        throw std::invalid_argument("unsupported frame type");

    resetPosition();
}

void SyntheticReader::StartExternalSource()
{
    if (!(_frame = PopUnusedFrame())) {
        throw std::runtime_error("Couldn't pop working frame from stream");
    }
    clearFrame();
    _thread = std::thread([this]() {
        HAL_LOG(INFO) << "Started.";
        while (_running) {
            generateFrame();
            std::this_thread::sleep_for(std::chrono::milliseconds(40));
        }
        HAL_LOG(INFO) << "Stopped.";
    });
}

void SyntheticReader::StopExternalSource()
{
    _running = false;
    _thread.join();
}

void SyntheticReader::generateFrame()
{
    VideoFrame_ptr frame = this->PopUnusedFrame();
    if (!frame) {
        HAL_LOG(WARNING) << "No empty frames";
        return;
    }

    generateMotion(7);
    copy(frame);

    frame->timecode = _current_tc;
    timecode_time_increment(&_current_tc, &_tcr);

    frame->record_flag = (_counter++ % 100) < 50 && _counter > 127;
    frame->vari_flag = false;
    frame->num_audio_samples = 0;
    frame->filename = "Z999_C999";
    PushRawFrame(frame);
}

void SyntheticReader::copy(VideoFrame_ptr dst)
{
    if (dst->stream != _frame->stream)
        throw std::runtime_error("invalid target frame dequeued from stream");

    for (int i = 0; i < 3; ++i) {
        if (_frame->plane[i]) {
            if (dst->stride[i] != _frame->stride[i] || dst->rows[i] != _frame->rows[i])
                throw std::runtime_error("invalid target frame dequeued from stream");
            memcpy(dst->plane[i], _frame->plane[i], _frame->stride[i] * _frame->rows[i]);
        }
    }
}

void SyntheticReader::generateMotion(int nsteps)
{
    for (int i = 0; i < nsteps; ++i) {
        int oldx = _x, oldy = _y;
        if (!updatePosition()) {
            clearFrame();
            break;
        }
        linedda(oldx, oldy, _x, _y);
    }
}

void SyntheticReader::linedda(int x1, int y1, int x2, int y2)
{
    float dx = abs(x2 - x1), dy = abs(y2 - y1);
    float p = dx >= dy ? dx : dy;
    dx /= p; dy /= p;

    float x = x1, y = y1;

    for (int i = 1; i <= p; ++i) {
        putPixel(x, y);
        x += dx; y += dy;
    }
}

void SyntheticReader::putPixel(int x, int y)
{
    switch (_frame->stream->pixel_format)
    {
    case AV_PIX_FMT_YUV422P:
    {
        int u = _rngDistCol(_rngEngine);
        int v = _rngDistCol(_rngEngine);
        addColor(pixel(1, x / 2, y), u);  // x/2: horizontal downsampling for YUV422
        addColor(pixel(2, x / 2, y), v);
    }
    // fallthrough
    case AV_PIX_FMT_GRAY8:
        pixel(0, x, y) = 128;
        break;
    default:
        throw std::logic_error("unsupported frame type");
    }
}

void SyntheticReader::clearFrame()
{
    switch (_frame->stream->pixel_format)
    {
    case AV_PIX_FMT_YUV422P:
        memset(_frame->plane[1], 128, _frame->stride[1] * _frame->rows[1]);
        memset(_frame->plane[2], 128, _frame->stride[2] * _frame->rows[2]);
        // fallthrough
    case AV_PIX_FMT_GRAY8:
        memset(_frame->plane[0], 0, _frame->stride[0] * _frame->rows[0]);
        break;
    default:
        throw std::logic_error("unsupported frame type");
    }
}

bool SyntheticReader::updatePosition()
{
    _x += _rngDistPos(_rngEngine);
    _y += _rngDistPos(_rngEngine);
    if (_x < 0 || _x >= (int)_frame->stream->width || _y < 0 || _y >= (int)_frame->stream->height) {
        resetPosition();
        return false;
    }
    return true;
}

void SyntheticReader::resetPosition()
{
    // Adjusted to _rngDstPos interval
    _x = this->width / 3;
    _y = this->height / 3;
}

void SyntheticReader::addColor(unsigned char& c, int amount)
{
    int r = (int)c + amount;
    if (r < 0) c = 0;
    else if (r > 255) c = 255;
    else c = (unsigned char)r;
}

inline unsigned char& SyntheticReader::pixel(int p, int x, int y)
{
    assert(p >= 0 && p < 3);
    assert(_frame->plane[p]);
    return _frame->plane[p][y * _frame->stride[p] + x];
}

} // hal
