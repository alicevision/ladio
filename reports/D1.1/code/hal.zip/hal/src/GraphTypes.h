// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <memory>
#include <tuple>
#include <vector>
#include <boost/filesystem/path.hpp>
#include <boost/optional.hpp>
#include <boost/uuid/uuid.hpp>
#include <tbb/flow_graph.h>
#include <timecode/timecode.h>
#include "ForwardDecls.h"
#include "Config.h"
#include "Logger.h"

namespace hal
{

struct RawPacket
{
  enum RecordingStatus { off, on, new_file };
  boost::uuids::uuid uuid;          // regenerated on each recording on <-> off on transition; default nil
  VideoFrame_ptr frame;             // frame raw data; can be null during codec flushing
  int32_t recording_length = -1;    // increasing during rec; reset to 0 on each on/new_file event
  RecordingStatus recording = off;
};

struct AVPacketHolder : public AVPacket
{
  AVPacketHolder(const AVPacket& p) {
    static_cast<AVPacket&>(*this) = p;
  }

  AVPacketHolder(const AVPacketHolder&) = delete;
  AVPacketHolder& operator=(const AVPacketHolder&) = delete;

  AVPacketHolder()
  {
    av_init_packet(this);
    this->data = nullptr;
    this->size = 0;
  }
  ~AVPacketHolder() { av_packet_unref(this); }
};

struct EncodedPacket : RawPacket
{
  enum Stream { video, audio };                     //  Indexes payload array

  struct Payload
  {
    std::shared_ptr<AVCodecContextHolder> codec;
    std::shared_ptr<AVPacketHolder> packet;         // nullptr in case of empty packet
    bool ok = true;                                 // default-initialized empty packet => all ok
  } payload[2];

  EncodedPacket() = default;
  EncodedPacket(const RawPacket& rp) : RawPacket(rp)
  { }
};

struct AVCodecContextHolder
{
  virtual ~AVCodecContextHolder() { }
  virtual AVCodecContext* CodecContext() const = 0;
  virtual EncodedPacket::Payload Encode(const RawPacket&) = 0;
  virtual EncodedPacket::Payload Finalize() = 0;
};

struct TemporaryFileSet
{
  boost::filesystem::path media_file;     // Will be renamed and hashed
  boost::filesystem::path metadata_file;  // Will renamed but NOT hashed
  bool ok;                                // Neither renaming nor hashing is done if !ok
};

/////////////////////////////////////////////////////////////////////////////

using VideoOverlayNode = tbb::flow::function_node<VideoFrame_ptr, VideoFrame_ptr>;
using AVCodecEncoderNode = tbb::flow::multifunction_node<RawPacket, std::tuple<EncodedPacket>>;
using VarispeedFilterNode = tbb::flow::multifunction_node<EncodedPacket, std::tuple<EncodedPacket>>;
using AVFormatWriterNode = tbb::flow::multifunction_node<EncodedPacket, std::tuple<TemporaryFileSet>>;
using FileHasherNode = tbb::flow::function_node<TemporaryFileSet>;

using VideoOverlayNodeP = std::unique_ptr<VideoOverlayNode>;
using AVCodecEncoderNodeP = std::unique_ptr<AVCodecEncoderNode>;
using VarispeedFilterNodeP = std::unique_ptr<VarispeedFilterNode>;
using AVFormatWriterNodeP = std::unique_ptr<AVFormatWriterNode>;
using FileHasherNodeP = std::unique_ptr<FileHasherNode>;

VideoOverlayNodeP MakeVideoOverlayNode(tbb::flow::graph& g);
AVCodecEncoderNodeP MakeAVEncoderNode(tbb::flow::graph& g, VideoStream_ptr stream, const config::OutputCodecPreset& params);
VarispeedFilterNodeP MakeVarispeedFilterNode(tbb::flow::graph& g);
//AVCodecEncoderNodeP MakeIntelEncoderNode(tbb::flow::graph& g, VideoStream_ptr stream, const EncoderPreset& params);
AVFormatWriterNodeP MakeAVFormatWriterNode(tbb::flow::graph& g, const std::string& path_prefix);
FileHasherNodeP MakeFileHasherNode(tbb::flow::graph& g, bool calculate_hash);

}
