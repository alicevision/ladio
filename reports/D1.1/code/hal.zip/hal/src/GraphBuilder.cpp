// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "GraphBuilder.h"
#include "DVP2Reader.h"
#include "DekTecReader.h"
#include "SyntheticReader.h"
#include "DeckLinkReader.h"
#include "GraphTypes.h"

#include <tbb/concurrent_queue.h>
#include <tbb/flow_graph.h>

#undef ERROR

namespace hal
{
static std::shared_ptr<DekTecReader> GetDekTecReader(RecordingObserver& recObs, const config::SDICamera& camera)
{
    switch (camera.sdi_camera_id)
    {
    case config::SDI_CAMERA_GENERIC:
        return std::make_shared<DekTecReader>(recObs, camera, std::make_unique<DekTecReader::NullParser>());
    case config::SDI_CAMERA_RED:
        //throw std::logic_error("DekTecReader::GetReader RED_PARSER Unimplemented");
        return std::make_shared<DekTecReader>(recObs, camera, std::make_unique<DekTecReader::RedParser>());
    case config::SDI_CAMERA_ARRI:
        return std::make_shared<DekTecReader>(recObs, camera, std::make_unique<DekTecReader::ArriParser>());
    default:
        HAL_GLOBAL_LOG(ERROR) << "GetReader got unsupported sdi_camera_id: " << camera.sdi_camera_id;
        throw std::logic_error("Unsupported camera_id in GetReader");
    }
}

static std::shared_ptr<VideoStream> CreateVideoStream(RecordingObserver& recObs, tbb::flow::graph& g, const config::Camera& camCfg, int wcid)
{
    switch (camCfg.capture_source) 
    {
    case config::DECKLINK:
    case config::DEKTEC:
        if (wcid >= 0)
            throw std::logic_error("SDI camera cannot have WC id");
        if (const config::SDICamera* sdiCam = dynamic_cast<const config::SDICamera*>(&camCfg)) {
            if(camCfg.capture_source == config::DECKLINK)
                return DeckLinkReader::Create(recObs, camCfg);
            else
                return GetDekTecReader(recObs, *sdiCam);
        }
        else {
            throw std::logic_error("std::shared_ptr<VideoStream> CreateVideoStream() got SDI camera, but camCfg was not SDICamera");
        }
    case config::SYNTHETIC:
        return std::make_shared<SyntheticReader>(recObs, camCfg);
    case config::PTGREY:
        //return std::make_shared<PtGreyReader>(recObs, camCfg);
        throw std::logic_error("std::shared_ptr<VideoStream> CreateVideoStream not implemented for type PTGREY");
    case config::DVP2:
        return std::make_shared<DVP2Reader>(recObs, static_cast<const config::WitnessCamera&>(camCfg), wcid);
    default:
        throw std::logic_error("std::shared_ptr<VideoStream> CreateVideoStream unknown capture_source: " + std::to_string(camCfg.capture_source));
        return false;
    }
}
void GraphBuilder::MakeOutput(const config::Camera& camCfg, int wcid)
{
    using namespace tbb::flow;
    
    // GetDekTecReader/BuildWCGraphs
    //std::shared_ptr<VideoStream> stream = std::make_shared<VideoStream>(_synchronizer, camCfg);
    std::shared_ptr<VideoStream> stream = CreateVideoStream(*_recording_observer, _graph, camCfg, wcid);
    int reader_id = _readers.size();
    _readers.push_back(stream);

    for (const auto& output : camCfg.video_outputs) {
        if (!output.enabled)
            continue;
        auto writer_node = MakeAVFormatWriterNode(_graph, output.output_name);
        //auto vari_filter_node = 
        auto hasher_node = MakeFileHasherNode(_graph, output.generate_hash);
        auto venc_node = MakeAVEncoderNode(_graph, stream, output.preset);
        make_edge(*venc_node, *writer_node);
        make_edge(*writer_node, *hasher_node);
    
        _stream_encoders.push_back(std::make_tuple(reader_id, venc_node.get()));
    
        _nodes.push_back(std::move(writer_node));
        _nodes.push_back(std::move(hasher_node));
        _nodes.push_back(std::move(venc_node));
    }
}

GraphBuilder::GraphBuilder()
{
    _recording_observer = RecordingObserver::Create(*this);

    auto stuff = DVP2Reader::Enumerate();
    
    if (Config->sdi_camera.enable)
        MakeOutput(Config->sdi_camera, -1);

    for (int i = 0; i < Config->witness_cameras.size(); ++i) {
        const auto& wc = Config->witness_cameras[i];
        if (wc.enable)
            MakeOutput(wc, i);
    }
}

void GraphBuilder::Run()
{
    _recording_observer->Start();
    for (const auto& r : _readers)
        r->Start();
    _recording_observer->Run();
}


} // hal
