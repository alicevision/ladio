// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "DVP2Reader.h"
#undef ERROR

namespace hal
{

template<typename F, typename... Args>
void DVP2Reader::call_dvp(const char* name, F fn, Args... args)
{
  dvpStatus status = fn(args...);
  if (status != DVP_STATUS_OK) {
    HAL_LOG(ERROR) << name << " failed; code=" << status;
    throw std::runtime_error(name);
  }
}

#define DVP2(fn, ...) call_dvp(#fn, fn, __VA_ARGS__)

DVP2Reader::DVP2Reader(RecordingObserver& recording_observer, const config::WitnessCamera& camera, int index) :
  VideoStream(recording_observer, camera),
  _dvp_index(index),
  _trigger_count(0)
{
  // NB: dvpOpen fails unless preceded by at least one dvpRefresh.
  DVP2(dvpOpen, _dvp_index, OPEN_NORMAL, &_dvp_handle);
  //DVP2(dvpSetQuickRoiSel, _dvp_handle, SelectResolution());
  DVP2(dvpSetSourceFormat, _dvp_handle, S_RAW8);
  DVP2(dvpSetTargetFormat, _dvp_handle, S_RAW8);
  DVP2(dvpSetAntiFlick, _dvp_handle, ANTIFLICK_DISABLE);
  DVP2(dvpSetAeMode, _dvp_handle, AE_MODE_AG_ONLY);                     // Long exposure prolongs capture time, so only gain can be auto.
  DVP2(dvpSetAeOperation, _dvp_handle, AE_OP_OFF);

  {
    dvpRegion roi;
    roi.X = 0; roi.W = 1280;
    roi.Y = (960-720)/2; roi.H = 720;
    DVP2(dvpSetRoi, _dvp_handle, roi);
  }

  // TODO: Configure hardware trigger.
  if (camera.external_trigger)
      DVP2(dvpSetTriggerState, _dvp_handle, true);

  _exposure = std::chrono::microseconds(int(camera.shutter * 1000));    // Exposure in the config file is milliseconds
  _gain = camera.gain;

  {
      dvpCameraInfo ci;
      DVP2(dvpGetCameraInfo, _dvp_handle, &ci);
      HAL_LOG(INFO)
          << "Vendor: " << ci.Vendor
          << "; Manufacturer: " << ci.Manufacturer
          << "; Model: " << ci.Model
          << "; Family: " << ci.Family
          << "; LinkName: " << ci.LinkName
          << "; SensorInfo: " << ci.SensorInfo
          << "; HardwareVersion: " << ci.HardwareVersion
          << "; FirmwareVersion: " << ci.FirmwareVersion
          << "; KernelVersion: " << ci.KernelVersion
          << "; DscamVersion: " << ci.DscamVersion
          << "; FriendlyName: " << ci.FriendlyName
          << "; PortInfo: " << ci.PortInfo
          << "; SerialNumber: " << ci.SerialNumber
          << "; CameraInfo: " << ci.CameraInfo
          << "; UserID: " << ci.UserID;
  }

  {
      bool b_setting;
      dvpInt32 i_setting;
      double d_setting;

      DVP2(dvpGetTriggerJitterFilter, _dvp_handle, &d_setting);
      HAL_LOG(INFO) << "Trigger jitter filter(us): " << d_setting;

      DVP2(dvpGetTriggerDelay, _dvp_handle, &d_setting);
      HAL_LOG(INFO) << "Trigger delay(us): " << d_setting;

      DVP2(dvpGetStrobeDelay, _dvp_handle, &d_setting);
      HAL_LOG(INFO) << "Strobe delay(us): " << d_setting;

      DVP2(dvpGetStrobeDuration, _dvp_handle, &d_setting);
      HAL_LOG(INFO) << "Strobe duration(us): " << d_setting;

      DVP2(dvpGetTriggerState, _dvp_handle, &b_setting);
      HAL_LOG(INFO) << "Trigger state: " << b_setting;

      DVP2(dvpGetFramesPerTrigger, _dvp_handle, &i_setting);
      HAL_LOG(INFO) << "Frames per trigger: " << i_setting;

      dvpAeMode ae_setting;
      DVP2(dvpGetAeMode, _dvp_handle, &ae_setting);
      HAL_LOG(INFO) << "AE mode: " << ae_setting;

      dvpAeOperation aeop_setting;
      DVP2(dvpGetAeOperation, _dvp_handle, &aeop_setting);
      HAL_LOG(INFO) << "AE operation: " << aeop_setting;

      dvpIntDescr aet_setting;
      DVP2(dvpGetAeTargetDescr, _dvp_handle, &aet_setting);
      HAL_LOG(INFO) << "AE Target: step=" << aet_setting.iStep << "; min=" << aet_setting.iMin
          << "; max=" << aet_setting.iMax << "; default=" << aet_setting.iDefault;

      dvpDoubleDescr exp_setting;
      DVP2(dvpGetExposureDescr, _dvp_handle, &exp_setting);
      HAL_LOG(INFO) << "Exposure: step=" << exp_setting.fStep << "; min=" << exp_setting.fMin
          << "; max=" << exp_setting.fMax << "; default=" << exp_setting.fDefault;
  }
}

DVP2Reader::~DVP2Reader()
{
  if (_dvp_index >= 0) {
    HAL_LOG(ERROR) << "DVP2Reader: destroyed while running";
    abort();
  }
  if (dvpClose(_dvp_handle) != DVP_STATUS_OK)
    HAL_LOG(ERROR) << "Failed to close camera " << _dvp_index;
}

unsigned DVP2Reader::SelectResolution()
{
  auto presets = GetResolutionPresets();
  for (size_t i = 0; i < presets.size(); ++i) {
    const auto& preset = presets[i];
    if (std::string(preset.mode.selection.string) != "NORMAL")  // XXX: what is this?
      continue;
    //if (preset.roi.X > 0 || preset.roi.Y > 0)
    //  continue;
    if (preset.roi.W == this->width && preset.roi.H == this->height)
      return i;
  }
  throw std::runtime_error("DVP2Reader: requested resolution not available");
}

std::vector<dvpQuickRoi> DVP2Reader::GetResolutionPresets()
{
  dvpSelectionDescr sel_descr;
  std::vector<dvpQuickRoi> roi_presets;
  
  DVP2(dvpGetQuickRoiSelDescr, _dvp_handle, &sel_descr);
  for (unsigned i = 0; i < sel_descr.uCount; ++i) {
    roi_presets.emplace_back();
    DVP2(dvpGetQuickRoiSelDetail, _dvp_handle, i, &roi_presets.back());
  }
  return roi_presets;
}


unsigned DVP2Reader::SelectGray8Format(const std::vector<dvpFormatSelection>& formats)
{
  for (size_t i = 0; i < formats.size(); ++i) {
    if (std::string(formats[i].selection.string) == "RAW8")
      return i;
  }
  throw std::runtime_error("DVP2Reader: gray8 source/target format not available");
}

std::vector<dvpFormatSelection> DVP2Reader::GetSourceFormats()
{
  dvpSelectionDescr sel_descr;
  std::vector<dvpFormatSelection> ret;

  DVP2(dvpGetSourceFormatSelDescr, _dvp_handle, &sel_descr);
  for (unsigned i = 0; i < sel_descr.uCount; ++i) {
    ret.emplace_back();
    DVP2(dvpGetSourceFormatSelDetail, _dvp_handle, i, &ret.back());
  }
  return ret;
}

std::vector<dvpFormatSelection> DVP2Reader::GetTargetFormats()
{
  dvpSelectionDescr sel_descr;
  std::vector<dvpFormatSelection> ret;

  DVP2(dvpGetTargetFormatSelDescr, _dvp_handle, &sel_descr);
  for (unsigned i = 0; i < sel_descr.uCount; ++i) {
    ret.emplace_back();
    DVP2(dvpGetTargetFormatSelDetail, _dvp_handle, i, &ret.back());
  }
  return ret;
}

void DVP2Reader::SetExposure(std::chrono::microseconds exposure)
{
  if (dvpSetExposure(_dvp_handle, exposure.count()) != DVP_STATUS_OK) {
    HAL_LOG(ERROR) << "Failed to set exposure to " << exposure.count();
  }
  else {
    HAL_LOG(INFO) << "Exposure set to " << exposure.count();
    _exposure = exposure;
  }
}

void DVP2Reader::SetGain(float gain)
{
  if (dvpSetAnalogGain(_dvp_handle, gain) != DVP_STATUS_OK) {
    HAL_LOG(ERROR) << "Failed to set gain to " << gain;
  }
  else {
    HAL_LOG(INFO) << "Gain set to " << gain;
    _gain = gain;
  }
}

void DVP2Reader::StartExternalSource()
{
  HAL_LOG(INFO) << "Starting";
  // DVP2(dvpResetDevice, _dvp_handle); XXX: NOT PRESENT IN THE DLL?!
  DVP2(dvpStart, _dvp_handle);

  DVP2(dvpSetExposure, _dvp_handle, _exposure.count());
  DVP2(dvpSetAnalogGain, _dvp_handle, _gain);

  double exposure;
  float gain;
  DVP2(dvpGetExposure, _dvp_handle, &exposure);
  DVP2(dvpGetAnalogGain, _dvp_handle, &gain);

  DVP2(dvpRegisterStreamCallback, _dvp_handle, &DVP2Reader::StreamCallback, STREAM_EVENT_PROCESSED, this);

  HAL_LOG(INFO) << "INITIAL TRIGGER; exposure=" << exposure << "; gain=" << gain;
  while (1) {
      auto status = dvpTriggerFire(_dvp_handle);
      if (status == DVP_STATUS_BUSY)
          continue;
      if (status == DVP_STATUS_OK)
          break;
      throw std::runtime_error("First trigger failed");
  }
  HAL_LOG(INFO) << "INITIAL TRIGGER DELIVERED";
}

void DVP2Reader::StopExternalSource()
{
  HAL_LOG(INFO) << "Stopping";
  DVP2(dvpStop, _dvp_handle);
  DVP2(dvpUnregisterStreamCallback, _dvp_handle, &DVP2Reader::StreamCallback, STREAM_EVENT_PROCESSED, this);
}

void DVP2Reader::TriggerExternalSource()
{
    int retry_count = 0;
retry:
    auto status = dvpTriggerFire(_dvp_handle);
    if (status == DVP_STATUS_OK) {
        ++_trigger_count;
        return;
    }
    if (status == DVP_STATUS_BUSY) {
        if (++retry_count > 10)
            throw std::runtime_error("Triggering failed.");
        HAL_LOG(ERROR) << "Couldn't deliver trigger, retrying";
        std::this_thread::yield();
        goto retry;
    }
    throw std::runtime_error("dvpTriggerFire; code=" + std::to_string(status));
}

dvpInt32 DVP2Reader::StreamCallback(dvpHandle h, dvpStreamEvent event, void* context, dvpFrame* frame, void* buffer)
{
  DVP2Reader* self = static_cast<DVP2Reader*>(context);
  if (self->_dvp_handle != h)
    throw std::logic_error("DVP2Reader::StreamCallback: handle/context mismatch");
  return self->OnFrameArrived(event, frame, buffer);
}

dvpInt32 DVP2Reader::OnFrameArrived(dvpStreamEvent event, dvpFrame* dvp_frame, void* buffer)
{
  if (event != STREAM_EVENT_PROCESSED)
    throw std::logic_error("DVP2Reader: got callback for unregistered event");
  if (dvp_frame->iWidth != this->width || dvp_frame->iHeight != this->height || dvp_frame->format != S_RAW8)
    throw std::runtime_error("DVP2Reader: frame with invalid parameters received");
#if 0
  if (--_trigger_count < 0) {
      HAL_LOG(ERROR) << "Received frame w/o corresponding trigger";
      _trigger_count = 0;
  }
#endif
  
  auto frame = this->PopUnusedFrame();
  if (!frame) {
    HAL_LOG(WARNING) << "No unused frame found; dropping frame.";
    return 0;
  }

  frame->timecode = TimecodeTime{ 0, 0, 0, 0, 0 };
  frame->vari_flag = false;
  frame->num_audio_samples = 0;
  frame->filename = "Z999_C999";
  memcpy(frame->plane[0], buffer, this->width * this->height);

  PushRawFrame(frame);
  return 0; // from the sample code: "return 0" represents the image data has been discarded and no longer been used.
}

std::vector<std::string> DVP2Reader::Enumerate()
{
  dvpUint32 count;
  if (dvpRefresh(&count) != DVP_STATUS_OK)
    throw std::runtime_error("dvpRefresh");

  std::vector<std::string> ret;
  for (unsigned i = 0; i < count; ++i) {
    dvpHandle handle;
    dvpCameraInfo info;
    memset(&info, 0, sizeof(info));
    if (dvpOpen(i, OPEN_OFFLINE, &handle) != DVP_STATUS_OK)
      throw std::runtime_error("dvpOpen");
    if (dvpGetCameraInfo(handle, &info) != DVP_STATUS_OK)
      throw std::runtime_error("dvpGetCameraInfo");
    if (dvpClose(handle) != DVP_STATUS_OK)
      throw std::runtime_error("dvpClose");

    static_assert(sizeof(info.SerialNumber) == 64, "Invalid size");
    ret.push_back(std::string(info.SerialNumber, info.SerialNumber + 64));
  }
  return ret;
}

} // hal
