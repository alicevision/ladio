// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once
#include "GraphTypes.h"
#include "VideoTypes.h"

#include <memory>
namespace hal
{

class GraphBuilder
{
public:
    // Output of reader at _readers[tuple.0] will be put to node at tuple.1
    using StreamEncoder = std::tuple<int, AVCodecEncoderNode*>;

private:
    tbb::flow::graph _graph;
    std::vector<VideoStream_ptr> _readers;
    std::vector<std::unique_ptr<tbb::flow::graph_node>> _nodes;
    std::vector<StreamEncoder> _stream_encoders;
    std::unique_ptr<RecordingObserver> _recording_observer;

    void MakeOutput(const config::Camera& camCfg, int wcid);

public:
    GraphBuilder();
    void Run();
    tbb::flow::graph& Graph() { return _graph; }
    const std::vector<VideoStream_ptr>& Readers() const { return _readers; }
    const std::vector<StreamEncoder>& Encoders() const { return _stream_encoders; }
};

} // hal
