// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "GraphTypes.h"
#include "VideoTypes.h"
#include "Config.h"
#include "../contrib/json.hpp"
#include <boost/filesystem.hpp>

#include <fstream>
extern "C" {
#include "libavutil/pixdesc.h"
}

namespace hal 
{

std::unique_ptr<config::ConfigFile> Config;

namespace config
{

constexpr const char* ConfigFile::preset_dir;
constexpr const char* ConfigFile::lut_dir;
constexpr const char* ConfigFile::output_dir;

using namespace nlohmann;
namespace bfs = boost::filesystem;

AVCodecID FindEncoderByName(const std::string& name)
{
    if (name == "h264") return AV_CODEC_ID_H264;
    if (auto p = avcodec_find_encoder_by_name(name.c_str())) {
        return p->id;
    }
    else {
        throw std::runtime_error("Could not find encoder by name: " + name);
    }
}


UploadInfo ParseUploadDestination(nlohmann::json& parent)
{
    UploadInfo o;
    //todo: this should be secured some way instead of plaintext
    o.address = parent["address"].get<std::string>();
    o.username = parent["username"].get<std::string>();
    o.password = parent["password"].get<std::string>();
    return o;
}

OutputCodecPreset ParseEncoderPreset(const bfs::path& config_file_path, const std::string& preset_name)
{
    auto path = config_file_path.parent_path() / ConfigFile::preset_dir / preset_name;
    std::cout << "Reading preset file: " << path << std::endl;
    
    json root;
    {
        std::ifstream file(path.string());
        if (!file)
            throw std::runtime_error("Failed to read preset file: " + path.string());
        file >> root;
    }

    OutputCodecPreset preset;
    preset.width                = root["width"].get<unsigned>();
    preset.height               = root["height"].get<unsigned>();
    preset.video_bitrate        = static_cast<int>(root["bitrate-mbps"].get<float>()*1e6);
    preset.h264_gop_size        = root["gop-size"].get<int>();
    preset.video_codec          = FindEncoderByName(root["video-codec-name"].get<std::string>());
    preset.profile              = root["profile"].get<std::string>();
    preset.output_pixel_format  = av_get_pix_fmt(root["output-pixel-format"].get<std::string>().c_str());
    preset.audio_codec          = FindEncoderByName(root["audio-codec-name"].get<std::string>());
    // TODO: threads, audio parameters if we ever want to change them
    
    if (preset.output_pixel_format == AV_PIX_FMT_NONE)
        throw std::runtime_error("invalid InputCodecPreset::output_pixel_format (AV_PIX_FMT_NONE)");
    return preset;
}

VideoOutput ParseVideoOutput(const bfs::path& config_file_path, nlohmann::json& parent)
{
    const auto& preset_name = parent["preset"].get<std::string>();

    VideoOutput o;
    o.enabled       = parent["enable"].get<bool>();
    o.generate_hash = parent["generate-hash"].get<bool>();
    o.preset        = ParseEncoderPreset(config_file_path, preset_name);
    o.output_name   = ConfigFile::output_dir + preset_name;
    o.overlay_mode  = (OverlayMode)parent["overlay-mode"].get<int>();

    if (parent.find("lut-name") != parent.end()) {
        std::string lut_filename = parent["lut-name"].get<std::string>();
        if (!lut_filename.empty()) {
            auto lut_path = config_file_path.parent_path() / ConfigFile::lut_dir / lut_filename;
            if (!exists(lut_path))
                throw std::runtime_error("Video output refers to non-existent LUT: " + lut_path.string());
            o.lut_name = ConfigFile::lut_dir + lut_filename;
        }
    }

    auto uit = parent.find("upload-destinations");
    if (uit != parent.end()) {
        json& upload_destinations = *uit;
        for (auto it = upload_destinations.begin(); it != upload_destinations.end(); ++it) {
            o.upload_destinations.push_back(std::move(ParseUploadDestination(*it)));
        }
    }

    return o;
}

void ReadCamera(const bfs::path& config_file_path, Camera* c, nlohmann::json& parent)
{
    c->enable = parent["enable"].get<bool>();
    c->width = parent["width"].get<int>();
    c->height = parent["height"].get<int>();
    c->strict = parent["strict"].get<bool>();
    c->input_pixel_format = av_get_pix_fmt(parent["input-pixel-format"].get<std::string>().c_str());
    if (c->input_pixel_format == AV_PIX_FMT_NONE)
        throw std::runtime_error("invalid InputCodecPreset::input_pixel_format (AV_PIX_FMT_NONE)");

    c->capture_source = (CaptureSource)parent["capture-source"].get<int>();


    c->sample_format = av_get_sample_fmt(parent["sample-format"].get<std::string>().c_str());
    if (c->sample_format == AV_SAMPLE_FMT_NONE)
        throw std::runtime_error("invalid InputCodecPreset::sample_format (AV_SAMPLE_FMT_NONE)");

    c->channel_count = parent["channel-count"].get<int>();
    c->sample_rate = parent["sample-rate"].get<int>();
    c->tc_offset = parent["tc-offset"];

    auto oit = parent.find("output");
    if (oit != parent.end()) {
        json& outputs = *oit;
        for (auto it = outputs.begin(); it != outputs.end(); ++it) {
            c->video_outputs.push_back(ParseVideoOutput(config_file_path, *it));
        }
    }
}

SDICamera ReadSDI(const bfs::path& config_file_path, nlohmann::json& parent)
{
    SDICamera o;
    auto it = parent.find("sdi");
    if (it == parent.end()) {
        o.enable = false;
        return o;
    }
    json& sdi = *it;
    o.name = "SDI";
    o.sdi_camera_id = (CameraID)sdi["sdi-camera-model"].get<int>();
    o.trigger_master = sdi["is-triggermaster"].get<bool>();
    ReadCamera(config_file_path, &o, sdi);
    return o;
}

WitnessCamera ReadWC(const bfs::path& config_file_path, nlohmann::json& parent)
{
    WitnessCamera o;
    ReadCamera(config_file_path, &o, parent);
    o.serial_number = parent["serial-number"].get<std::string>();
    o.name = "WC_" + o.serial_number;
    o.shutter = parent["shutter"].get<float>();
    o.gain = parent["gain"].get<float>();
    o.auto_exposure = parent["auto-exposure"].get<bool>();
    o.external_trigger = parent["external-trigger"].get<bool>();
    o.flip = parent["flip"].get<bool>();
    return o;
}

std::unique_ptr<ConfigFile> Read(const boost::filesystem::path& config_file_path)
{
    std::cout << "Reading config file: " << config_file_path << std::endl;

    json root;
    {
        std::ifstream file(config_file_path.string());
        if (!file)
            throw std::runtime_error(std::string("Failed to read config file: ") + config_file_path.string());
        file >> root;
    }

    std::unique_ptr<ConfigFile> cf(new ConfigFile);
    cf->path                = config_file_path;
    cf->log_level           = severity_level(root["log-threshold"].get<int>());
    cf->sync_after_write    = root["sync-after-write"].get<bool>();
    cf->fanmode             = FanMode(root["fan-mode"].get<int>());
    cf->framerate           = root["framerate"].get<unsigned>();
    cf->warm_shuttersync    = root["warn-shuttersync"].get<bool>();
    cf->fps                 = root["fps"].get<int>();
    cf->jam_frame           = root["jam-frame"].get<int>();
    cf->buffer_size         = root["buffer-size"].get<int>();
    cf->sdi_camera          = ReadSDI(config_file_path, root);

    auto wcNode = root.find("witness-cameras");
    if (wcNode != root.end()) {
        json& witnessCams = *wcNode;
        for (auto wc = witnessCams.begin(); wc != witnessCams.end(); wc++) {
            cf->witness_cameras.push_back(ReadWC(config_file_path, *wc));
        }
    }

    return cf;
}

} // config
} // hale
