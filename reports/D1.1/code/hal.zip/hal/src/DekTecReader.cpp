// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "DekTecReader.h"
#include "Config.h"
#include "MetadataUtilities.h"

#include <thread>
#include <iomanip>
#include <sstream>
#include <array>
namespace hal
{

class DekTecReaderExc : public std::runtime_error
{
public:
    DekTecReaderExc(DTAPI_RESULT  ErrorCode, const std::string& message)  : 
        runtime_error(message), m_ErrorCode(ErrorCode)
    {
    }
    
    DTAPI_RESULT  m_ErrorCode;

    static std::string FormatErrorMessage(DTAPI_RESULT  ErrorCode, const char*  pFile, int  Line, const char*  pMsg, ...)
    {
        int  Len = 0;
        char  Buffer[1024];
        Len = sprintf(Buffer, "%s(%d): ", pFile, Line);
        if (Len >= 0)
        {
            va_list  VaArgs;
            va_start(VaArgs, pMsg);
            Len += vsprintf(&Buffer[Len], pMsg, VaArgs);
            va_end(VaArgs);
        }
        if (ErrorCode != DTAPI_OK)
            Len += sprintf(&Buffer[Len], " (ERROR=%s)", ::DtapiResult2Str(ErrorCode));
        Buffer[Len++] = '\0';
        return std::string(Buffer);
    }
};
#define MX_THROW_EXC(ErrorCode, pMsg, ...)                                  \
do                                                                          \
{                                                                           \
    throw DekTecReaderExc(ErrorCode, DekTecReaderExc::FormatErrorMessage(ErrorCode, __FILE__, __LINE__, pMsg, ##__VA_ARGS__));    \
} while (0)
#define MX_THROW_EXC_NO_ERR(pMsg, ...)  MX_THROW_EXC(DTAPI_OK, pMsg, ##__VA_ARGS__)
//.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- MX_ASSERT -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-
//
#ifndef _DEBUG
#define MX_ASSERT(Expr)  ((void)0)
#else // _DEBUG
#ifdef _WIN32
#define MX_ASSERT(Expr)  _ASSERTE(Expr)
#else // _WIN32
#define MX_ASSERT(Expr)  if(!(Expr)) printf("Assertion failed @ %s, Line %d: (%s)\n", \
                                                               __FILE__, __LINE__, #Expr);
#endif // _WIN32
#endif // _DEBUG

const int DekTecReader::DEF_CARD_TYPE;
const int DekTecReader::DEF_CARD_NO;
const int DekTecReader::DEF_IN_PORT;
const int DekTecReader::DEF_IN_VIDSTD;
const int DekTecReader::IN_ROW;

DekTecReader::NullParser::NullParser(const std::string & parserName) :
    _logger(boost::log::keywords::channel = parserName)
{}

bool DekTecReader::NullParser::operator()(DtMxFrame* frame, VideoFrame* vf)
{
  vf->record_flag = framecount++ < 250;
  vf->filename = "Z999_C999";
  return TryReadSMPTE12MTC(frame, vf);
}

bool DekTecReader::NullParser::TryReadSMPTE12MTC(DtMxFrame * frame, VideoFrame * vf)
{
    DtMxAncPacket ancPacket;
    int numAncPackets = 1;
    DTAPI_RESULT res = frame->AncGetPacket(0x60, 0x60, &ancPacket, numAncPackets, DTAPI_SDI_HANC, DTAPI_SDI_LUM);
    if (res != DTAPI_OK && res != DTAPI_E_BUF_TOO_SMALL) {
        HAL_LOG(TRACE) << "TryReadSMPTE12MTC could not find DID/SDID 0x60, 0x60, error: " << res - DTAPI_E;
        return false;
    }
    
    numAncPackets = 1;
    res = frame->AncGetPacket(0x60, 0x60, &ancPacket, numAncPackets, DTAPI_SDI_HANC, DTAPI_SDI_LUM);
    unsigned short* udw = ancPacket.m_pUdw;
    vf->timecode.frame = p10(udw[0], udw[2]);
    vf->timecode.second = p10(udw[4], udw[6]);
    vf->timecode.minute = p10(udw[8], udw[10]);
    vf->timecode.hour = p10(udw[12], udw[14]);
    return true;
}

bool DekTecReader::NullParser::flag(unsigned short s, uint8_t bit)
{
    return ((s >> (4 + bit - 1)) & 1);
}

uint8_t DekTecReader::NullParser::binGrp(unsigned short s)
{
    return (uint8_t)((s >> 4) & 0xf);
}

uint8_t DekTecReader::NullParser::p1s(unsigned short bits) {
    return ((bits >> 4) & 0xf);
}

uint8_t DekTecReader::NullParser::p10(unsigned short s1, unsigned short s10) {
    return p1s(s10) * 10 + p1s(s1);
}

uint8_t DekTecReader::NullParser::p100(unsigned short s1, unsigned short s10, unsigned short s100)
{
    return p1s(s100) * 100 + p10(s1, s10);
}

bool DekTecReader::ArriParser::operator()(DtMxFrame* frame, VideoFrame* vf)
{
    TryReadSMPTE12MTC(frame, vf);

    {
        DtMxAncPacket ancPacket;
        int numAncPackets = 1;
        auto res = frame->AncGetPacket(0x52, 0x4d, &ancPacket, numAncPackets,
            DTAPI_SDI_HANC, DTAPI_SDI_LUM);
        if (res != DTAPI_OK && res != DTAPI_E_BUF_TOO_SMALL) {
            HAL_LOG(ERROR) << "AncGetPacket failed with error: " << (res - DTAPI_E);
        }
        else {
            vf->record_flag = (ancPacket.m_pUdw[10] & 2);
        }
    }

    {
        // http://blog.abelcine.com/wp-content/uploads/2011/07/ALEXA_Metadata_White_Paper_SUP8.pdf page 18

        int numAncPackets = 18;
        DtMxAncPacket ancPacket[18];
        auto res = frame->AncGetPacket(0x44, 0x04, ancPacket, numAncPackets, DTAPI_SDI_VANC, DTAPI_SDI_LUM);
        if (res != DTAPI_OK) {
            HAL_LOG(ERROR) << "AncGetPacket failed with error: " << (res - DTAPI_E);
        }
        // We don't care if buffer is too small. ARRI documentation say it should be 18
        if (res == DTAPI_OK || res == DTAPI_E_BUF_TOO_SMALL) {
            if (numAncPackets != 18) {
                HAL_LOG(ERROR) << "numAncPackets(" << numAncPackets << ") != 18";
            }
            for (int i = 0; i < numAncPackets; i++) {
                uint16_t psc1 = ancPacket[i].m_pUdw[1];
                uint16_t psc2 = ancPacket[i].m_pUdw[2];
                //0-17
                int packetNum = (psc1 & 255) * 10 + (psc2 & 255);

                // where we store the payload
                uint8_t* metaPtr = &metadata[packetNum * 230];

                if (ancPacket[i].m_Dc != 233) {
                    HAL_LOG(ERROR) << "ancPacket[" << i << "]." << "m_dc(" << ancPacket[i].m_Dc << ") != 233";
                }

                // Always skipping first 3 bytes, they are MID(1) and PSC(2)
                for (int j = 3; j < ancPacket[i].m_Dc; j++) {
                    metaPtr[j - 3] = (ancPacket[i].m_pUdw[j] & 255);
                }
            }
        }
        arri::PopulateMetadata(GetMetadataBlob(), vf);
    }

    return true;
}

uint8_t * DekTecReader::ArriParser::GetMetadataBlob() {
    if (memcmp(metadata, arriKey, 20) != 0) {
        HAL_LOG(WARNING) << "ArriParser arriKey does not match key found in metadata";
        return nullptr;
    }
    else {
        return &metadata[20];
    }
}

bool DekTecReader::RedParser::operator()(DtMxFrame* frame, VideoFrame* vf)
{
    DtMxAncPacket ancPacket[2];
    int numAncPackets = 2;
    auto res = frame->AncGetPacket(0x60, 0x60, ancPacket, numAncPackets, DTAPI_SDI_HANC, DTAPI_SDI_LUM);
    if (res != DTAPI_OK) {
        HAL_LOG(ERROR) << "Error getting ancPacket: " << res - DTAPI_E;
        return false;
    }
    if (numAncPackets != 2) {
        HAL_LOG(ERROR) << "numAncPackets != 2";
        return false;
    }
    const DtMxAncPacket& p = ancPacket[0];
    if (p.m_Dc != 16) {
        HAL_LOG(ERROR) << "p.m_Dc == " << p.m_Dc << "  when parsing red hanc timecode";
        return false;
    }
    unsigned short* udw = p.m_pUdw;

    vf->vari_flag = flag(udw[1], 3);

    {
        bool sdi_record_flag = flag(udw[1], 4);
        if (!sdi_record_flag) {
            vf->record_flag = false;
            recording_length = 0;
        }
        else {
            vf->record_flag = recording_length++ > 2;
        }
    }

    TryReadSMPTE12MTC(frame, vf);

    bool MI1 = flag(udw[9], 1);
    if (MI1) {
        clip = p100(udw[3], udw[5], udw[7]);
        lrc = ((udw[9] >> 2) & 0x3);

        wild1 = binGrp(udw[15]) | ((binGrp(udw[11]) & 0xC) << 2);
        if (wild1 < 10) wild1 += 48;
        else wild1 += 55;
        wild2 = binGrp(udw[13]) | ((binGrp(udw[11]) & 0x3) << 4);
        if (wild2 < 10) wild2 += 48;
        else wild2 += 55;
    }
    else {
        dayn = binGrp(udw[13]) | (flag(udw[9], 3) ? 0x10 : 0x0);
        camletter = 65 + binGrp(udw[15]) | (flag(udw[9], 4) ? 0x10 : 0x0);
        roll = p100(udw[3], udw[5], udw[7]);
        mon = p1s(udw[11]);
    }

    std::ostringstream fns;
    fns << std::setfill('0')
        << camletter << std::setw(3) << (int)roll
        << "_C" << std::setw(3) << (int)clip
        << "_" << std::setw(2) << (int)mon << std::setw(2) << (int)dayn << (char)wild1 << (char)wild2;

    // need .c_str(), something broken with string copy/move/whatever
    vf->filename = fns.str().c_str();
    if (vf->filename.size() != 16)
        throw std::logic_error("Red filename not of size 14");
    char tcs[20];
    timecode_time_to_string(tcs, &vf->timecode);
#if 0
    HAL_LOG(TRACE) << std::setfill('0')
        << "REC: " << (vf->record_flag ? "Y" : "N")
        << ", VF: " << (vf->vari_flag ? "Y" : "N")
        << ", MI: " << (MI1 ? "1" : "0")
        << ", " << tcs << " - " << fns.str();
#endif
    return true;
}

DekTecReader::DekTecReader(RecordingObserver& recording_observer, const config::Camera& camera, std::unique_ptr<NullParser> parser)
    :
    VideoStream(recording_observer, camera),
    metaParser(std::move(parser)),
    hasSignal(false),
    vidInfoPrinted(false)
{
    _v210dec = V210Decoder::create();
    Initialize();
}

void DekTecReader::Initialize()
{
    DTAPI_RESULT  dr;
    DtDevice dtDevice;
    dr = dtDevice.AttachToType(DEF_CARD_TYPE /*, deviceno=0*/);
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed to attach to DTA-%d", DEF_CARD_TYPE);

    //xxx: why DEF_IN_PORT - 1?
    if ((dtDevice.m_pHwf[(DEF_IN_PORT - 1)].m_Flags & DTAPI_CAP_MATRIX2) == 0)
        MX_THROW_EXC_NO_ERR("Port %d does not have the MATRIX2 capability", DEF_IN_PORT);

    HAL_LOG(hal::INFO) << "Using DTU -" << DEF_CARD_TYPE
        << ", Port = " << DEF_IN_PORT
        << ", Standard = " << ::DtapiVidStd2Str(DEF_IN_VIDSTD); // auto

    if (!dtDevice.IsAttached()) {
        MX_THROW_EXC_NO_ERR("DekTec card not attached");
        //HAL_LOG(hal::ERROR) << "DekTec card not attached";
        return;
    }
    if (!InitCard(dtDevice)) {
        MX_THROW_EXC_NO_ERR("Failed to init DtDevice");
        //HAL_LOG(hal::ERROR) << "Failed to init DtDevice";
        return;
    }
}

bool DekTecReader::InitCard(DtDevice& TheCard)
{
    DTAPI_RESULT  dr;

    //-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.- Prep card for matrix -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-

    // The card must have been attached
    if (!TheCard.IsAttached())
        return false;
    if (!PrepCard(TheCard))
        return false;

    //+=+=+=+=+=+=+=+=+=+=+=+=+=+=+ Configure the input row +=+=+=+=+=+=+=+=+=+=+=+=+=+=+=

    // Step 1: Attach row to the input
    DtMxPort  InPort;
    dr = InPort.AddPhysicalPort(&TheCard, IN_PORT());
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed to add port %d as physical in-port", IN_PORT());
    dr = m_TheMatrix.AttachRowToInput(IN_ROW, InPort);
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed to attach row %d to in-port %d", IN_ROW, IN_PORT());

    // Step 2: configure the row
    DtMxRowConfig  RowConfig;
    RowConfig.m_Enable = true;

    // Keep a history of one frame
    RowConfig.m_RowSize = 1;

    // Enable the video and get scaled full picture
    RowConfig.m_VideoEnable = true;

    RowConfig.m_Video.m_PixelFormat = DT_PXFMT_V210;

    RowConfig.m_Video.m_StartLine1 = RowConfig.m_Video.m_StartLine2 = 1;
    RowConfig.m_Video.m_NumLines1 = RowConfig.m_Video.m_NumLines2 = -1;
    RowConfig.m_Video.m_Scaling = DTAPI_SCALING_OFF;

    // FFmpeg complains if not large enough
    RowConfig.m_Video.m_LineAlignment = 32;
    RowConfig.m_Video.m_BufAlignment = 4096;

    RowConfig.m_AudioEnable = true;

    // We want to de-embed all available audio channels
    RowConfig.m_AudioDef.m_DeEmbed = true;
    RowConfig.m_AudioDef.m_Format = DT_AUDIO_SAMPLE_PCM;  // De-embed as PCM samples
                                                          // m_OutputMode is irrelevant for input-only rows

                                                          // Enable aux data
    RowConfig.m_AuxDataEnable = true;
    RowConfig.m_AuxData.m_DataType = DT_AUXDATA_SDI;
    RowConfig.m_AuxData.m_Sdi.m_AncPackets.m_DeEmbed = true;
    RowConfig.m_AuxData.m_Sdi.m_AncPackets.m_OutputMode = DT_OUTPUT_MODE_COPY;

    // Apply the row configuration
    dr = m_TheMatrix.SetRowConfig(IN_ROW, RowConfig);
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed set row %d config", IN_ROW);

    // Step 3: Final configuration

    // Register our callback
    dr = m_TheMatrix.AddMatrixCbFunc(OnNewFrame, this);
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed register audio callback function");

    return true;
}

void DekTecReader::OnNewFrame(DtMxData * pData, void * pOpaque)
{
    ((DekTecReader*)pOpaque)->ProcessNewFrame(pData);
}

bool DekTecReader::PrepCard(DtDevice&  TheCard)
{
    DTAPI_RESULT  dr;

    //-.-.-.-.-.-.-.-.-.-.-.-.-.- Configure port io-direction -.-.-.-.-.-.-.-.-.-.-.-.-.-.

    DtIoConfig  Cfg;

    Cfg.m_Port = IN_PORT();
    Cfg.m_Group = DTAPI_IOCONFIG_IODIR;
    Cfg.m_Value = DTAPI_IOCONFIG_INPUT;
    Cfg.m_SubValue = DTAPI_IOCONFIG_INPUT;
    Cfg.m_ParXtra[0] = Cfg.m_ParXtra[1] = -1;

    dr = TheCard.SetIoConfig(&Cfg, 1);
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed to apply IO-DIR for port");

    //-.-.-.-.-.-.-.-.-.-.-.-.-.- Configure port io-standard -.-.-.-.-.-.-.-.-.-.-.-.-.-.

    // Should we auto detect? 
    int  VidStd = IN_VIDSTD(), IoStdValue = -1, IoStdSubValue = -1;
    if (VidStd == DTAPI_VIDSTD_AUTO)
    {
        HAL_LOG(INFO) << "Waiting to auto-detect SDI signal";
        size_t iterations = 0;
        do
        {
            IoStdValue = -1, IoStdSubValue = -1;
            dr = TheCard.DetectIoStd(IN_PORT(), IoStdValue, IoStdSubValue);
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        } while (dr != DTAPI_OK && ++iterations < 200);

        ::DtapiIoStd2VidStd(IoStdValue, IoStdSubValue, VidStd);
        if (dr == DTAPI_OK) {
            HAL_LOG(INFO) << "Detected video standard = " << ::DtapiVidStd2Str(VidStd);
            HAL_LOG(DEBUG) << "Auto-detect video standard required " << iterations << " iterations";
        }
        else {
            HAL_LOG(INFO) << "Failed to auto-detect SDI signal";
        }
    }

    dr = ::DtapiVidStd2IoStd(VidStd, IoStdValue, IoStdSubValue);
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed to deduce IO-STD from video and link standard");

    Cfg.m_Port = IN_PORT();
    Cfg.m_Group = DTAPI_IOCONFIG_IOSTD;
    Cfg.m_Value = IoStdValue;
    Cfg.m_SubValue = IoStdSubValue;
    Cfg.m_ParXtra[0] = Cfg.m_ParXtra[1] = -1;

    dr = TheCard.SetIoConfig(&Cfg, 1);
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed to apply IO-STD for port");

    return (dr == DTAPI_OK);
}

void DekTecReader::StartExternalSource()
{
    DTAPI_RESULT  dr = m_TheMatrix.Start();
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed to start the matrix");
}

void DekTecReader::StopExternalSource()
{
    DTAPI_RESULT  dr = m_TheMatrix.Stop();
    if (dr != DTAPI_OK)
        MX_THROW_EXC(dr, "Failed to stop the matrix");
}

void DekTecReader::ProcessNewFrame(DtMxData * pData)
{
    VideoFrame_ptr frame = this->PopUnusedFrame();
    if (!frame) {
        HAL_LOG(WARNING) << "No empty frames";
        return;
    }

    // Get the frame data and check it is valid
    DtMxFrame*  pTheFrame = pData->m_Rows[IN_ROW].m_CurFrame;
    if (pTheFrame->m_Status != DT_FRMSTATUS_OK)
    {
        HAL_LOG(WARNING) << "[Frame " << pData->m_Frame << "] frame status ("
            << pTheFrame->m_Status << ") is not ok => skipping frame";
        PushEmptyFrame(frame);
        return;
    }

    // Get properties for video standard
    DtVidStdInfo  VidInfo;
    DTAPI_RESULT  dr = ::DtapiGetVidStdInfo(pTheFrame->m_VidStd, VidInfo);
    if (dr != DTAPI_OK) {
        HAL_LOG(WARNING) << "Unable to retreive VidStdInfo";
    }
    else if (!vidInfoPrinted) {
        vidInfoPrinted = true;
        HAL_LOG(INFO) << "Detected"
            << " Framerate: " << VidInfo.m_Fps
            << "; LinkStd: " << VidInfo.m_LinkStd
            << "; Width: " << VidInfo.m_VidWidth
            << "; Height: " << VidInfo.m_VidHeight;
    }

    if (!pTheFrame->m_VideoValid) {
        if (hasSignal) {
            HAL_LOG(INFO) << "SDI Stream lost.";
            hasSignal = false;
            //TimecodeManager::get().setUndefinedTime();
        }
        HAL_LOG(INFO) << "Frame not valid";
        PushEmptyFrame(frame);
        return;
    }
    else {
        if (!hasSignal)
            HAL_LOG(INFO) << "SDI Stream acquired.";
        hasSignal = true;
    }

    (*metaParser)(pTheFrame, frame.get());

    //unsigned char* pDest = frame->
    if (this->pixel_format != AV_PIX_FMT_YUV422P10LE) {
        throw std::logic_error("invalid stream frame_type");
    }

    // Do we have an interlaced or progessive format (i.e. 1 or 2 field)?
    int  NumFields = (VidInfo.m_IsInterlaced) ? 2 : 1;

    for (int i = 0; i < NumFields; i++) {
        const DtMxVideoBuf&  Video = pTheFrame->m_Video[i];

        if (Video.m_PixelFormat != DT_PXFMT_V210) {
            throw std::logic_error("invalid Video pixelFormat");
        }
        if (Video.m_NumPlanes != 1) {
            // DT_PXFMT_V210 outputs 1 plane
            throw std::logic_error("Video.m_NumPlanes != 1");
        }

        const DtMxVideoPlaneBuf&  Plane = Video.m_Planes[0];
        // Note: Video.m_Height is already original height/2 for interleaved data
        size_t len = Plane.m_BufSize;
        _v210dec->decodeFrame((uint8_t*)Plane.m_pBuf, len, Video.m_Width, Video.m_Height);

        for (int p = 0; p < 3; p++) {
            size_t sz = boost::asio::buffer_size(_v210dec->rawPixels(p));
            const uint8_t* buf = boost::asio::buffer_cast<const uint8_t*>(_v210dec->rawPixels(p));
            unsigned char* dst = frame->plane[p];
            if (NumFields == 1) {
                memcpy(dst, buf, sz);
            }
            else if (NumFields == 2) {
                for (size_t y = i; y < Video.m_Height*NumFields; y += NumFields) {
                    size_t fieldStride = _v210dec->rawStride()[p];
                    size_t fieldOffset = y*fieldStride;
                    size_t bufOff = (y / NumFields)*fieldStride;
                    memcpy(dst + fieldOffset, buf + bufOff, fieldStride);
                }
            }
            else {
                throw std::logic_error("NumFields not 1 or 2");
            }
        }
    }

    {
      frame->num_audio_samples = 0;
      if (pTheFrame->m_AudioValid) {
        auto& channels = pTheFrame->m_Audio.m_Channels;
        
        // XXX: Use service to set sound format.  Different channels can have different sampling rates/etc.
        // XXX: Assume for now 48kHZ, 32-bit PCM.
        // auto& service = pTheFrame->m_Audio.m_Services[channels[0].m_Service];
        
        int used_channels = 0;
        for (auto i = 0; i < channels.size() && used_channels < VideoFrame::MAX_AUDIO_CHANNELS; ++i) {
          if (!channels[i].m_Present || !channels[i].m_NumValidSamples)
            continue;

          if (!frame->num_audio_samples)
              frame->num_audio_samples = channels[i].m_NumValidSamples;
          else if (frame->num_audio_samples != channels[i].m_NumValidSamples)
            HAL_LOG(WARNING) << "Different sample count across channels";

          // TODO: if fewer samples, fill the rest of the plane with zeros
          memcpy(frame->audio_plane[used_channels], channels[i].m_pBuf,
            sizeof(int32_t) * std::min(frame->num_audio_samples, channels[i].m_NumValidSamples));

          ++used_channels;
        }
        // We get only mono sound, fill the other channel with zeros.
        for (int i = used_channels; i < VideoFrame::MAX_AUDIO_CHANNELS; ++i)
          memset(frame->audio_plane[i], 0, VideoFrame::MAX_AUDIO_SAMPLES * sizeof(int32_t));
      }
    }

    frame->empty = false;
    HAL_LOG(TRACE) << "Emitting frame";
    PushRawFrame(frame);
}

}

