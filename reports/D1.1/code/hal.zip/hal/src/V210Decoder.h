// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include "Logger.h"
#include <boost/asio/buffer.hpp>

extern "C" {
#include <libswscale/swscale.h>
#include <libavcodec/avcodec.h>
#include <stdlib.h>
}

namespace hal
{

class V210Decoder {
 public:
  static AVCodec *codec;

 private:
  AVCodecContext *_context;
  AVFrame *_frame;
  AVPacket _packet;
  struct SwsContext *_sws;
  std::string _rgbData;
  uint8_t *_swsDst[1];
  int _swsDstStride[1];
  int _decodedWidth;
  int _decodedHeight;

  hal_logger_t _logger;

  V210Decoder();
  void rescaleFrame();

 public:
  static std::unique_ptr<V210Decoder> create() {
    return std::unique_ptr<V210Decoder>(new V210Decoder);
  }

  ~V210Decoder();

  bool decodeFrame(uint8_t *data, size_t len, int width, int height);

  int rgbWidth() const { return _decodedWidth; }
  int rgbHeight() const { return _decodedHeight; }
  const std::string &rgbData() const { return _rgbData; }

  int rawWidth() const { return _frame->width; }
  int rawHeight() const { return _frame->height; }
  int *rawStride() const { return _frame->linesize; }

  boost::asio::const_buffer rawPixels(int plane) const {
    int length = _frame->linesize[plane] * _frame->height;
    return boost::asio::buffer((char *)_frame->data[plane], length);
  }

  enum AVPixelFormat rawPixelFormat() const {
    if (_frame->format < 0) throw std::runtime_error("unknown pixel format after decoding");
    return static_cast<enum AVPixelFormat>(_frame->format);
  }
};

}
