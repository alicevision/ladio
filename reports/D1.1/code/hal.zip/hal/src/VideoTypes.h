// (c) 2014-2016 Labo Mixedrealities AS
// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include <thread>
#include <memory>
#include <chrono>
#include <stdexcept>
#include <tbb/concurrent_queue.h>
#include <boost/accumulators/accumulators.hpp>
#include <boost/accumulators/statistics/stats.hpp>
#include <boost/accumulators/statistics/rolling_mean.hpp>
#include <timecode/timecode.h>
#include "Logger.h"
#include "ForwardDecls.h"
#include "GraphTypes.h"
#include "../contrib/json.hpp"
#include "Config.h"

extern "C" {
#include <libavutil/pixfmt.h>
#include <libavutil/samplefmt.h>
}

namespace hal
{

std::string to_string(const TimecodeTime&);

class ffmpeg_error : public std::runtime_error
{
    static std::string GetErrorString(int av_err_code);
public:
    ffmpeg_error(const std::string& what, int av_err_code) :
        std::runtime_error(what + ": " + GetErrorString(av_err_code))
    {}
};

class VideoFrame
{
  static constexpr size_t PAGESIZE = 4096;

  size_t _framesize;

  static void* mapalloc(size_t sz);
  static void mapfree(void *ptr, size_t sz);

public:
  VideoFrame(const VideoStream*);
  ~VideoFrame();

 public:
  static constexpr int MAX_AUDIO_SAMPLES = 8000;    // Assuming 96 khz, 24 fps stereo is worst case
  static constexpr int MAX_AUDIO_CHANNELS = AV_NUM_DATA_POINTERS;
  
  VideoStream_ptr stream;                           // Contains basic frame data (type, size, etc.)
 
  // Set by VideoStream.
  int32_t ord;                                      // Monotonically increasing, set by Push*Frame.
  bool empty;                                       // True if frame is empty (i.e., not received by camera).  Set by Push*Frame.
  uint64_t timestamp;	                            // System-timestamp for latency measurement, set by PushRawFrame.
  
  // Set by SDI reader or RecordingObserver (for WCs).
  TimecodeTime timecode;                            // Always from SDI.
  std::string filename;                             // Filename used when storing to disk; must reflect varispeed when in effect.
  bool record_flag;                                 // True if frame is recorded by SDI
  bool vari_flag;                                   // True if frame is to be dropped

  // Picture data 
  unsigned char *yuv_data;
  unsigned char *plane[3];
  int stride[3];
  unsigned int rows[3];

  // Audio data
  unsigned char* audio_plane[MAX_AUDIO_CHANNELS];
  int num_audio_samples;

  // HAL and camera-specific metadata.
  nlohmann::json parsed_metadata;
};

// This interface is the link between the periodic asynchronous video/audio sources and the rest of the graph.
// It is responsible for synchronizing the streams, generating jammed timecode, file name, and monitoring of
// stream presence.  It sends RawPacket objects to the rest of the graph and runs the graph.
//
// The same timecode is applied to all frames, possibly after applying per-camera offset.
//
// It also implements "forced recording" submode in which the stream is saved regardless of the state of
// record flag on the SDI camera.
//
// It has two main modes of operation:
// 1. Trigger master not present or not recording.  TC is free-running and file-name is constant. Recording
//    can be initiated by forced recording mode.
// 2. Trigger master present.  It is assumed that the first frame with record flag on has correct time-code;
//    the source has to arrange for this to be the case.  TC is jammed to that time-code and filename is
//    acquired from the SDI camera.
//
// Correct TC-sync between SDI and WCs can be achieved only when WCs are triggered by the SDI.  In this
// case we KNOW that each frame from WC has a corresponding "trigger frame" from SDI.  Then it remains
// only to measure the TC offset between WC and SDI.
//
// Frame-synchronization is based on frame-difference count instead of timestamp.  Each frame is labelled
// with a monotonically increasing index on the stream (VideoFrame::ord field).  
class GraphBuilder;
struct RecordingObserver
{
    static std::unique_ptr<RecordingObserver> Create(GraphBuilder&);

    virtual ~RecordingObserver() {}
    virtual void Start() = 0;
    virtual void Run() = 0;
    virtual void Stop() = 0;
    virtual void PushFrame(VideoFrame_ptr) = 0;
    virtual void SetForcedRecording(bool) = 0;
    virtual bool GetForcedRecording() const = 0;
};


// This is the abstract base class for media sources.
class VideoStream : public std::enable_shared_from_this<VideoStream>
{
  // Must be sync queue because free'd frames can be pushed into it from another thread.
  using FrameQueue = tbb::concurrent_bounded_queue<VideoFrame_ptr>;

  struct frame_deleter
  {
    std::weak_ptr<FrameQueue> owner;
    frame_deleter(const std::shared_ptr<FrameQueue>& owner) : owner(owner) { }
    void operator()(VideoFrame* frame);         // If owner is still alive, push into it with default deleter, otherwise delete immediately.
  };

  RecordingObserver& _recording_observer;       // Reference to break shared_ptr loops.  Observer always outlives the streams.
  std::shared_ptr<FrameQueue> _unused_frames_q; // Unused frame cache; when this goes empty, we just crash.
  int32_t _ord;                                 // Used to sync frames; reset by Jam when trigger master is present
  int32_t _trigger_frame;                       // Provided by trigger master.
  bool _running;

  std::chrono::system_clock::time_point _last_arrival_time;
  std::chrono::system_clock::time_point _last_trigger_time;

  using RollingMeanAcc = boost::accumulators::accumulator_set<double,
      boost::accumulators::stats<
        boost::accumulators::tag::rolling_mean>>;
  
  RollingMeanAcc _frame_arrival_acc;
  RollingMeanAcc _frame_latency_acc;

protected:
  hal_logger_t _logger;

  VideoStream(RecordingObserver& recording_observer, const config::Camera&);

  VideoFrame_ptr PopUnusedFrame();
  void UpdateArrivalStatistics();
  void PushRawFrame(VideoFrame_ptr);
  void PushEmptyFrame(VideoFrame_ptr);

  virtual void StartExternalSource() = 0;
  virtual void StopExternalSource() = 0;
  virtual void TriggerExternalSource();

public:
  virtual ~VideoStream();

  std::string name;

  // Stream video frame format.
  AVPixelFormat pixel_format;
  int width;
  int height;
  int fps;
  int tc_frame_offset;
  bool strict;
  bool trigger_master;

  // Stream audio frame format.  Layout implies number of channels.
  AVSampleFormat sample_format;
  int channel_count;
  int sample_rate;

  void Start();
  void Stop();
  bool Trigger(int32_t trigger_frame);
};

} //hal
