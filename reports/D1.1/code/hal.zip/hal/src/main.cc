// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include <iostream>
#include <fstream>
#include <array>
#include <functional>
#include <sstream>
#include <utility>
#include <signal.h>
#include <algorithm>
#include <string>
#ifndef _WIN32
#include <sched.h>
#endif
#include <boost/program_options.hpp>
#include <tbb/task_scheduler_observer.h>
#include "Config.h"
#include "Logger.h"
#include "GraphTypes.h"
#include "VideoTypes.h"
#include "SyntheticReader.h"
#include "DekTecReader.h"
#include "DVP2Reader.h"
#include "GraphBuilder.h"
#include "IOController.h"

#undef ERROR

using namespace hal;

static VideoStream_ptr G_Stream;
static std::vector<std::unique_ptr<tbb::flow::graph_node>> G_Nodes;

#ifndef _WIN32
#define RT_PRIO_LOW 1
#define RT_PRIO_HIGH 5
#endif

class TBBThreadObserver : public tbb::task_scheduler_observer
{
public:
    TBBThreadObserver() { observe(true); }
    void on_scheduler_entry(bool is_worker) override;
};

void TBBThreadObserver::on_scheduler_entry(bool is_worker)
{
    HAL_GLOBAL_LOG(INFO) << "Thread: " << std::this_thread::get_id() << "; WORKER: " << is_worker;
#ifndef _WIN32    
    struct sched_param sp;
     sp.sched_priority = 0;
    //if (pthread_setschedparam(pthread_self(), SCHED_OTHER, &sp) < 0)
    if (pthread_setschedprio(pthread_self(), RT_PRIO_LOW) < 0)
        throw std::runtime_error("TBBThreadObserver: pthread_setschedprio");
#endif
}

static void ParseCommandLine(int argc, char** argv)
{
    namespace po = boost::program_options;
    po::options_description desc("Options");
    std::string config_filename;
    bool log_to_journal = false;
    desc.add_options()
        ("config-file", po::value<std::string>(&config_filename), "")
        ("log-to-journal,j", po::bool_switch(&log_to_journal), "");

    po::variables_map vm;
    po::store(po::parse_command_line(argc, argv, desc), vm);
    //todo: other command-line args?
    vm.notify();
    Config = config::Read(config_filename);
    Config->log_to_journal = log_to_journal;
    IOController = std::unique_ptr<hal::IOControllerImpl>(new hal::IOControllerImpl());
}

static void SetRTPriority()
{
#ifndef _WIN32
    HAL_GLOBAL_LOG(INFO) << "Setting RT priority";
    struct sched_param sp;
    sp.sched_priority = RT_PRIO_HIGH;
    if (sched_setscheduler(0, SCHED_FIFO, &sp) < 0)
        throw std::runtime_error(std::string("sched_setscheduer: ") + strerror(errno));
#endif
}

int main(int argc, char** argv)
{
    TBBThreadObserver thread_observer;
    
    try {
        ParseCommandLine(argc, argv);
        auto logger_instance = hal::startLogger(Config->log_to_journal, "HAL");
        hal::setLogLevel(Config->log_level);
        SetRTPriority();
        GraphBuilder graphBuilder;
        graphBuilder.Run();   // Blocks until Stop is posted.
    }
    catch (boost::program_options::error& e) {
        std::cerr << "Error parsing options/config: " << e.what();
    }
    catch (std::exception& e) {
        std::cerr << "EXITING DUE TO ERROR: " << e.what();
        return 1;
    }

    HAL_GLOBAL_LOG(INFO) << "EXITING ON USER REQUEST";
    return 0;
}

