// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//

#pragma once
#include <boost/asio/serial_port.hpp>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <string>
namespace hal
{

namespace cooke_commands
{

static const std::string N   = "N";   //Retrieve Fixed Data � Required first Command
static const std::string D   = "D";   //Retrieve one set of ASCII Calculated Data
static const std::string Kd  = "Kd";  //Retrieve one set of Packed Binary Calculated Data
static const std::string K3  = "K3";  //Retrieve name of Lens Manufacturer
static const std::string K4  = "K4";  //Retrieve name of Lens Type
static const std::string P   = "P";   //Retrieve board Temperature
static const std::string B   = "B";   //Retrieve board Firmware Version
static const std::string Kbn = "Kbn"; //Set Baud Rate to n(where n = 1 - 7 See Chart) default = 115k2 or 9.6k
static const std::string C   = "C";   //Set "Continuous Send" mode & begin transmission of ASCII Calculated Data
static const std::string Kc  = "Kc";  //Set "Continuous Send" mode & begin transmission of Packed Binary Calculated Data
static const std::string G   = "G";   //Set "Checksum" mode
static const std::string Ka  = "Ka";  //Set "Inhibit Error Response" mode
static const std::string X   = "X";   //Set Display Units to Imperial
static const std::string Y   = "Y";   //Set Display Units to Metric
static const std::string V   = "V";   //Set "Film Size" to 35mm(default value)
static const std::string W   = "W";   //Set "Film Size" to 16mm
static const std::string Wnn = "Wnn"; //Set "Film Size" to nn(where nn = 00 - 09 refers to specified film size/circle of confusion.See chart.)
static const std::string H   = "H";   //Stop "Continuous Send"; clear "Checksum"; clear "Inhibit Error Response" mode
};

namespace cooke_messages
{

struct Message
{
    std::string data;
};

// Fixed Data in ASCII Format
// N must be the first command sent to the lens
struct N : public Message
{
    std::string getS() { return data.substr(0, 9); } // s ..sss Serial Number � 9 characters
    std::string getO() { return data.substr(9, 31); } // u..uuu Owner Data � 31 characters (XXX: possibly one extra character for zoom lens???)
    std::string getL() { return data.substr(40, 1); } // t Lens Type : t = P for Prime, Z for Zoom
    std::string getN() { return data.substr(41, 4); } // xxx Focal length(Primes) or minimum focal length(Zooms)[Tag = f for S4 /i Primes
    std::string getM() { return data.substr(45, 3); } // ddd Unspecified(Primes) or maximum focal length(Zooms)
    std::string getU() { return data.substr(48, 1); } // b Start - up units : I = imperial, M = metric, (b = metric or B = imperial when both available).
    std::string getT() { return data.substr(49, 2); } // ff Transmission factor(not yet available in S4I Primes - see Appendix)
    std::string getyy(){ return data.substr(51, 2); } //yy 2 SPACE characters
    std::string getB() { return data.substr(53, 3); } // v.vv Firmware version number
};

// Pre-Defined Set of Calculated Data in ASCII Format
struct D : public Message
{
    std::string getD() { return data.substr(0, 7); } // s s s s s s s Actual focus distance � units*
    std::string getT() { return data.substr(7, 4); } // a a a a Actual Aperture setting
    std::string gett() { return data.substr(11, 5); } // b b b b b Actual Aperture setting � conventional notation**
    std::string getZ() { return data.substr(16, 4); } // f f f f Zoom � EFL(mm)[0000 for Prime lenses]
    std::string getH() { return data.substr(20, 7); } // a a a a a a a HYPERFOCAL Setting �units*
    std::string getN() { return data.substr(27, 7); } // b b b b b b b NEAR FOCUS distance � units*
    std::string getF() { return data.substr(34, 7); } // c c c c c c c FAR FOCUS distance � units*
    std::string getV() { return data.substr(41, 4); } // v v v.v Horizontal Field of view - degrees
    std::string getE() { return data.substr(45, 4); } // s e e e Entrance Pupil Position � units*[Tag:s is a + or -sign]
    std::string getz() { return data.substr(49, 4); } // mmmm Normalized Zoom Setting
    std::string getS() { return data.substr(53, 9); } // xxxxxxxxx Lens Serial Number
};

}


class IdataReader
{
public:
    IdataReader(const std::string& portName);

    cooke_messages::N GetN();
    cooke_messages::D GetD();

private:
    size_t timeout;
    char c;
    boost::asio::deadline_timer timer;
    bool read_error;

    boost::asio::io_service _ioService;
    boost::asio::serial_port _serialPort;

    void read_complete(const boost::system::error_code& error, size_t bytes_transferred);
    void time_out(const boost::system::error_code& error);
    bool read_char(char& val);
    std::string GetData(const std::string& command);

};

} // hal