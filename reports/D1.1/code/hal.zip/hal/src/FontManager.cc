// (c) 2014-2016 Labo Mixedrealities AS
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#include "FontManager.h"
#include "GraphTypes.h"
#include "VideoTypes.h"
#include "Config.h"

namespace hal
{

static FT_Library GetFTLib()
{
  static FT_Library lib = nullptr;
  if (!lib) {
    FT_Error error = FT_Init_FreeType(&lib);
    if (error)
      throw std::runtime_error("Error initializing freetype");
  }
  return lib;
}

FontManager::FontManager(std::string fontname, float size, float dpi)
{
  FT_Error error;

  std::lock_guard<std::mutex> lock(_mutex);

  error = FT_New_Face(GetFTLib(), fontname.c_str(), 0, &_face);
  if (error) throw std::runtime_error("Freetype: Error creating font face");

  error = FT_Set_Char_Size(_face, size * 64, 0, dpi, 0);
  if (error) throw std::runtime_error("Freetype: Set char size.");

  _slot = _face->glyph;
}

FontManager::~FontManager()
{
  FT_Done_Face(_face);
}

void FontManager::OverlaySDIFrame(VideoFrame_ptr frame)
{
#if 0
  if (!cfg.crop_sdi_overlay)
    throw std::logic_error("FontManager::OverlaySDIFrame: overlay not enabled in config");
#endif
  
  if (frame->stream->pixel_format == AV_PIX_FMT_YUV422P) {
    for (int i = 0; i < 110; ++i) {
      memset(frame->plane[0] + i * frame->stride[0], 0, frame->stride[0]);
      memset(frame->plane[1] + i * frame->stride[1], 128, frame->stride[1]);
      memset(frame->plane[2] + i * frame->stride[2], 128, frame->stride[2]);
    }

    for (int i = frame->stream->height - 110 - 1; i < frame->stream->height; ++i) {
      memset(frame->plane[0] + i * frame->stride[0], 0, frame->stride[0]);
      memset(frame->plane[1] + i * frame->stride[1], 128, frame->stride[1]);
      memset(frame->plane[2] + i * frame->stride[2], 128, frame->stride[2]);
    }
  }
  else if (frame->stream->pixel_format == AV_PIX_FMT_YUV422P10LE) {
    for (int i = 0; i < 110; ++i) {
      memset(frame->plane[0] + i * frame->stride[0], 0, frame->stride[0]);
      for (int j = 0; j < frame->stride[1]; j += 2) {
        *(uint16_t*)&frame->plane[1][i * frame->stride[1] + j] = 512;
        *(uint16_t*)&frame->plane[2][i * frame->stride[2] + j] = 512;
      }
    }
    
    for (int i = frame->stream->height - 110 - 1; i < frame->stream->height; ++i) {
      memset(frame->plane[0] + i * frame->stride[0], 0, frame->stride[0]);
      for (int j = 0; j < frame->stride[1]; j += 2) {
        *(uint16_t*)&frame->plane[1][i * frame->stride[1] + j] = 512;
        *(uint16_t*)&frame->plane[2][i * frame->stride[2] + j] = 512;
      }
    }
  }

  DrawText(frame->stream->width - 290, frame->stream->height - 50, to_string(frame->timecode), frame);
  DrawText(15, frame->stream->height - 50, frame->filename, frame);
}

void FontManager::OverlayWCFrame(VideoFrame_ptr frame)
{
#if 0
  if (!cfg.burn_metadata)
    throw std::logic_error("FontManager::OverlayWCFrame: overlay not enabled in config");
#endif
  
  if (frame->stream->pixel_format == AV_PIX_FMT_GRAY8) {
    // Well, since burn_metadata is a big hack, let's hack in some black borders.
    for (int i = 55; i < 110; ++i)
      memset(frame->plane[0] + 20 + i * frame->stride[0], 0, 400);
    for (int i = frame->stream->height-150; i < frame->stream->height-65; ++i)
      memset(frame->plane[0] + i * frame->stride[0], 0, frame->stream->width);
  }

  DrawText(50, 100, to_string(frame->timecode), frame);

  std::stringstream ss;
  // FIX: ss << ClipManager::get().getBaseFilename() << "_" << _name;
  DrawText(50, frame->stream->height - 100, frame->filename, frame);

#if 0 // TODO: read out parsed_metadata
  {
    std::stringstream ss2;
    ss2 << (int)frame->_gain;
    ss2 << std::setprecision(6) << " dB  1/" << frame->_shutter_inv;
    _fontmgr->drawText(frame->stream->width - 500, frame->stream->height - 100, ss2.str(), frame);
  }
#endif
}


void FontManager::DrawText(int x, int y, std::string text, VideoFrame_ptr videoframe)
{
  // We draw white text on the luma plane.

  std::lock_guard<std::mutex> lock(_mutex);

  FT_Error error;

  FT_Vector pen;

  // Set position
  pen.x = pen.y = 0;

  for (unsigned i = 0; i < text.length(); ++i) {
    FT_Set_Transform(_face, 0, &pen);

    error = FT_Load_Char(_face, text[i], FT_LOAD_RENDER);

    if (error) throw std::runtime_error("Freetype: Load character.");

    DrawGlyph(x + _slot->bitmap_left, y - _slot->bitmap_top, &_slot->bitmap, videoframe);

    pen.x += _slot->advance.x;
    pen.y += _slot->advance.y;
  }
}

void FontManager::DrawGlyph(int x, int y, FT_Bitmap* glyph, VideoFrame_ptr videoframe)
{
  FT_Int i, j, p, q;
  FT_Int x_max = x + glyph->width;
  FT_Int y_max = y + glyph->rows;

  for (i = x, p = 0; i < x_max; i++, p++) {
    for (j = y, q = 0; j < y_max; j++, q++) {
      if (i < 0 || j < 0 || i >= (int)videoframe->stream->width || j >= (int)videoframe->stream->height) continue;

      if (videoframe->stream->pixel_format == AV_PIX_FMT_YUV420P || videoframe->stream->pixel_format == AV_PIX_FMT_YUV422P)
      {
        videoframe->plane[0][j * videoframe->stride[0] + i] |= glyph->buffer[q * glyph->width + p];

        if (videoframe->stream->pixel_format == AV_PIX_FMT_YUV420P)
        {
          videoframe->plane[1][j/2 * videoframe->stride[1] + i / 2] = 128;
          videoframe->plane[2][j/2 * videoframe->stride[2] + i / 2] = 128;
        }
      }

      else if (videoframe->stream->pixel_format == AV_PIX_FMT_YUV422P10LE)
      {
        *(uint16_t*)&videoframe->plane[0][j * videoframe->stride[0] + i * 2] |= glyph->buffer[q * glyph->width + p] << 2;
      }
    }
  }
}

};
