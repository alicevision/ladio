// (c) 2017 Simula Research Laboratory
// This Source Code Form is subject to the terms of the Mozilla Public
// License, v. 2.0. If a copy of the MPL was not distributed with this
// file, You can obtain one at http://mozilla.org/MPL/2.0/.
//
#pragma once

#include "VideoTypes.h"
#include "Logger.h"
#include "DTAPI.h"
#include "V210Decoder.h"

#include <memory>

namespace hal
{

class DekTecReader : public VideoStream
{
public:
    class NullParser {
    protected:
        hal_logger_t _logger;
        unsigned framecount = 0;
    public:
        NullParser(const std::string& parserName = std::string("NullCameraParser"));
        virtual ~NullParser() {}
        virtual bool operator()(DtMxFrame* frame, VideoFrame* vf);
    protected:
        bool TryReadSMPTE12MTC(DtMxFrame* frame, VideoFrame* vf);
        bool flag(unsigned short s, uint8_t bit);
        uint8_t binGrp(unsigned short s);
        uint8_t p1s(unsigned short bits);
        uint8_t p10(unsigned short s1, unsigned short s10);
        uint8_t p100(unsigned short s1, unsigned short s10, unsigned short s100);
    };

    class ArriParser : public NullParser {
    public:
        ArriParser() :
            NullParser("ArriParser")
        {}
        bool operator()(DtMxFrame* frame, VideoFrame* vf) override;

    private:
        uint8_t metadata[4140]; //18x230
        const char* arriKey = "\x06\x0E\x2B\x34\x02\x05\x01\x0D\x0E\x17\x00\x00\x00\x11\x01\x01\x83\x00\x10\x00";
        struct vancEntry {
            uint32_t start;
            uint32_t stop;
        };
        uint8_t* GetMetadataBlob();
        
        enum ArriMetaContent {
            clipnameStart = 0x0698,
            clipnameStop = 0x06B0
        };

    };

    class RedParser : public NullParser
    {
    public:
        RedParser()
            : NullParser("RedParser"),
            wild1(' '),
            wild2(' '),
            lrc(0),
            dayn(0),
            camletter(' '),
            roll(0),
            mon(0)
        {
        }

        bool operator()(DtMxFrame* frame, VideoFrame* vf) override;

    private:
        uint8_t clip;
        char wild1;
        char wild2;
        uint8_t lrc;
        uint8_t dayn;
        char camletter;
        uint8_t roll;
        uint8_t mon;
        int recording_length;
    };

    DekTecReader(RecordingObserver&, const config::Camera& camera, std::unique_ptr<NullParser> parser);

protected:
    // Inherited via VideoStream
    virtual void StartExternalSource() override;
    virtual void StopExternalSource() override;

private:
    void Initialize();

    bool InitCard(DtDevice&  TheCard);
    bool PrepCard(DtDevice&  TheCard);
    void ProcessNewFrame(DtMxData* pData);
    //Callback from m_TheMatrix
    static void OnNewFrame(DtMxData* pData, void* pOpaque);

    DtMxProcess  m_TheMatrix;
    std::unique_ptr<V210Decoder> _v210dec;
    std::unique_ptr<NullParser> metaParser;
    bool hasSignal;
    bool vidInfoPrinted;

    static const int DEF_CARD_TYPE = 351;
    static const int DEF_CARD_NO = 0;
    static const int DEF_IN_PORT = 1;
#define DTAPI_VIDSTD_AUTO  -2   // Extra helper for auto detection of video standard
    static const int  DEF_IN_VIDSTD = DTAPI_VIDSTD_AUTO;

    static const int  IN_ROW = 0;

    int  CARD_TYPE() const { return DEF_CARD_TYPE; }
    int  CARD_NO() const { return DEF_CARD_NO; }
    int  IN_PORT() const { return DEF_IN_PORT; }
    int  IN_VIDSTD() const { return DEF_IN_VIDSTD; }
};

}
