#!/bin/bash
find ./src -type f -iname \*.cc -or -iname \*.h | xargs -n1 clang-format-3.5 -i
