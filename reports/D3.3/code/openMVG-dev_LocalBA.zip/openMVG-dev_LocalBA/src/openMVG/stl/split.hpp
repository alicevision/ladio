#ifndef SPLIT_HPP
#define SPLIT_HPP

#include <vector>
#include <string>

namespace stl
{
/**
 * Split an input string with a delimiter and fill a string vector
 */
static bool split ( const std::string src, const std::string& delim, std::vector<std::string>& vec_value )
{
  bool bDelimiterExist = false;
  if ( !delim.empty() )
  {
    vec_value.clear();
    std::string::size_type start = 0;
    std::string::size_type end = std::string::npos -1;
    while ( end != std::string::npos )
    {
      end = src.find ( delim, start );
      vec_value.push_back ( src.substr ( start, end - start ) );
      start = end + delim.size();
    }
    if ( vec_value.size() >= 2 )
      bDelimiterExist = true;
  }
  return bDelimiterExist;
}
} // namespace stl
#endif // SPLIT_HPP
