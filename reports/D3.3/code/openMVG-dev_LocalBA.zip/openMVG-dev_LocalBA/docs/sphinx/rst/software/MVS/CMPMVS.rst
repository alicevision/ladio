Export to CMPMVS
========================

OpenMVG exports [CMPMVS]_ ready to use project (images, projection matrices and ini configuration file).

.. code-block:: c++

  $ openMVG_main_openMVG2CMPMVS -i Dataset/outReconstruction/sfm_data.json -o Dataset/outReconstruction
