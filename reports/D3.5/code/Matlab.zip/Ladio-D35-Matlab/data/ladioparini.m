% ladio.m - LADIO Experiments
% T. Pajdla, pajdla@cvut.cz
% (c) 2016 - 2017
%
% Eperiments
pc.doc.ExpDir = 'Experiment directory';
pc.ExpDir = fullfile(pc.DataPath,ps.Data);
%% General settings
pc.doc.Settings = 'General settings';
pc.Settings.TitleStyle = {'FontSize',9,'FontWeight','normal','interpreter','none'};
%% P4f
pc.K0 = [1 0 2734;
         0 1 1548;
         0   0   1];
pc.f0 = 3722.068; % tru focal langth?
pc.P4fThr = 3; % Ransac threshold
pc.P5frThr = 3;
