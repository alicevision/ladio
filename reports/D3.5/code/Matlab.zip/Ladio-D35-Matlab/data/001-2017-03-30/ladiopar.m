% ladio.m - LADIO Experiments
% T. Pajdla, pajdla@cvut.cz
% (c) 2016 - 2017
%
