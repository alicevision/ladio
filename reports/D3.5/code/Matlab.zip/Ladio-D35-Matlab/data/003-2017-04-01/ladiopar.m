% ladio.m - LADIO Experiments
% T. Pajdla, pajdla@cvut.cz
% (c) 2016 - 2017

pc.K0 = [1 0 1972.7;
         0 1 1513.7;
         0   0   1];
pc.f0 = 3722.068; % tru focal langth?
pc.P4fThr = 3;
pc.P5frThr = 3;